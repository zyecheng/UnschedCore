﻿#include "stdafx.h"
#include "TPCCSet.h"
#include "Util.h"
#include <algorithm>
#include <assert.h>

extern void my_assert(bool bCondition, char axInfo[]);

TPCCSet::TPCCSet()
{
	m_ptagLinkTPCCArray = NULL;
	m_ptagTaskTPCCArray = NULL;
	m_pcTargetTaskSet = NULL;
}


TPCCSet::~TPCCSet()
{

}

void TPCCSet::Initialize(TaskSet & rcTaskSet)
{
	m_pcTargetTaskSet = &rcTaskSet;
	int iTaskNum = rcTaskSet.getTaskNum();
	m_iTaskNum = iTaskNum;
	CreateTaskTPCCArray(iTaskNum);
	Task * pcTaskArray = m_pcTargetTaskSet->getTaskArrayPtr();
	m_iLinkNum = 0;
	for (int i = 0; i < iTaskNum; i++)
		m_iLinkNum += pcTaskArray[i].getSuccessorSet().size();
	CreateLinkTPCCArray(m_iLinkNum);
	int iLinkIndex = 0;
	for (int i = 0; i < iTaskNum; i++)
	{
		set<Task::CommunicationLink> & rsetSuccessor = pcTaskArray[i].getSuccessorSet();
		for (set<Task::CommunicationLink>::iterator iter = rsetSuccessor.begin();
			iter != rsetSuccessor.end(); iter++)
		{
			m_ptagLinkTPCCArray[iLinkIndex].iDestTask = iter->m_iTargetTask;
			m_ptagLinkTPCCArray[iLinkIndex].iSourceTask = i;
			iLinkIndex++;
		}
	}
}

void TPCCSet::GenRawCritiChanges()
{
	//for Task
	Task * pcTaskArray = m_pcTargetTaskSet->getTaskArrayPtr();
	int iTaskNum = m_pcTargetTaskSet->getTaskNum();
	for (int i = 0; i < iTaskNum; i++)
	{
		GenRawCritiChangesSingle(i, pcTaskArray[i].getDeadline(), m_ptagTaskTPCCArray[i].setCritiChanges);
	}

	//for Link
	for (int i = 0; i < m_iLinkNum; i++)
	{
		int iSource = m_ptagLinkTPCCArray[i].iSourceTask;
		int iDest = m_ptagLinkTPCCArray[i].iDestTask;
		if ((pcTaskArray[iSource].getPeriod() < pcTaskArray[iDest].getPeriod()) && (pcTaskArray[iSource].getCriticality()))
		GenRawCritiChangesSingle(iDest, pcTaskArray[iSource].getPeriod(), m_ptagLinkTPCCArray[i].setCritiChanges);
	}
}

void TPCCSet::GenRawCritiChangesSingle(int iTaskIndex, double dTotalTime, set<double> & rsetStore)
{	
	Task * pcTaskArray = m_pcTargetTaskSet->getTaskArrayPtr();
	int iTaskNum = m_pcTargetTaskSet->getTaskNum();
	if (!pcTaskArray[iTaskIndex].getCriticality())
		return;
#if 0
	rsetStore.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
			continue;		
		if (!pcTaskArray[i].getCriticality())	
		{
			double dCritiChange = pcTaskArray[i].getPeriod();
			while ((dCritiChange - dTotalTime) < -1e-9)
			{
				rsetStore.insert(dCritiChange);
				dCritiChange += pcTaskArray[i].getPeriod();
			}
		}
	}
#endif
	rsetStore.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (!pcTaskArray[i].getCriticality())
		{
			double dCritiChange = pcTaskArray[i].getPeriod();
			while (dCritiChange < dTotalTime)
			{
				rsetStore.insert(dCritiChange);
				dCritiChange += pcTaskArray[i].getPeriod();
			}
		}
	}
}

void TPCCSet::GenRawTestPoints()
{
	//Task
	int iTaskNum = m_pcTargetTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTargetTaskSet->getTaskArrayPtr();
	Task ** pcTaskArrayByPeriod = m_pcTargetTaskSet->getTaskArrayByPeriosPtr();	
	CSpaceTestPoint(pcTaskArrayByPeriod[0]->getTaskIndex(), pcTaskArrayByPeriod[0]->getDeadline(),
		m_ptagTaskTPCCArray[pcTaskArrayByPeriod[0]->getTaskIndex()].setTestPoints);
	for (int i = 1; i < iTaskNum; i++)
	{		
		if (abs(pcTaskArrayByPeriod[i]->getPeriod() - pcTaskArrayByPeriod[i - 1]->getPeriod()) < 1e-9)
		{
			m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i]->getTaskIndex()].setTestPoints = 
				m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i - 1]->getTaskIndex()].setTestPoints;
		}
		else
		{
			CSpaceTestPoint(pcTaskArrayByPeriod[i]->getTaskIndex(), pcTaskArrayByPeriod[i]->getDeadline(),
				m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i]->getTaskIndex()].setTestPoints);
		}
	}
	//Link
	for (int i = 0; i < m_iLinkNum; i++)
	{
		int iSourceIndex = m_ptagLinkTPCCArray[i].iSourceTask;
		int iDestIndex = m_ptagLinkTPCCArray[i].iDestTask;
		if (pcTaskArray[iSourceIndex].getPeriod() < pcTaskArray[iDestIndex].getPeriod())
		{
			m_ptagLinkTPCCArray[i].setTestPoints = m_ptagTaskTPCCArray[iSourceIndex].setTestPoints;
		}			
		else
		{			
			m_ptagLinkTPCCArray[i].setTestPoints = m_ptagTaskTPCCArray[iDestIndex].setTestPoints;			
		}
	}
}

void TPCCSet::GenCompleteTestPoints()
{
	//Task
	int iTaskNum = m_pcTargetTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTargetTaskSet->getTaskArrayPtr();
	Task ** pcTaskArrayByPeriod = m_pcTargetTaskSet->getTaskArrayByPeriosPtr();
	CSpaceTestPoint(pcTaskArrayByPeriod[0]->getTaskIndex(), pcTaskArrayByPeriod[0]->getDeadline(),
		m_ptagTaskTPCCArray[pcTaskArrayByPeriod[0]->getTaskIndex()].setTestPoints);
	for (int i = 1; i < iTaskNum; i++)
	{
		if (pcTaskArrayByPeriod[i]->getCriticality())
		{
			bool bNeedGen = true;
			for (int j = i - 1; j >= 0; j--)
			{
				if ((abs(pcTaskArrayByPeriod[i]->getPeriod() - pcTaskArrayByPeriod[j]->getPeriod()) < 1e-9))
				{
					if ((pcTaskArrayByPeriod[j]->getCriticality()))
					{
						if (!m_ptagTaskTPCCArray[pcTaskArrayByPeriod[j]->getTaskIndex()].setTestPoints.empty())
						{
							m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i]->getTaskIndex()].setTestPoints =
								m_ptagTaskTPCCArray[pcTaskArrayByPeriod[j]->getTaskIndex()].setTestPoints;
							bNeedGen = false;
						}
						break;
					}
				}
				else
				{
					break;
				}
			}

			if (bNeedGen)
			{
				HICompleteTestPointPerTask(pcTaskArrayByPeriod[i]->getTaskIndex(),
					pcTaskArrayByPeriod[i]->getDeadline(),
					m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i]->getTaskIndex()].setTestPoints);
			}			
		}
		else
		{
			bool bNeedCSpace = true;
			for (int j = i - 1; j >= 0; j--)
			{
				if ((abs(pcTaskArrayByPeriod[i]->getPeriod() - pcTaskArrayByPeriod[j]->getPeriod()) < 1e-9) )
				{
					if ((!pcTaskArrayByPeriod[j]->getCriticality()))
					{
						if (!m_ptagTaskTPCCArray[pcTaskArrayByPeriod[j]->getTaskIndex()].setTestPoints.empty())
						{
							m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i]->getTaskIndex()].setTestPoints =
								m_ptagTaskTPCCArray[pcTaskArrayByPeriod[j]->getTaskIndex()].setTestPoints;
							bNeedCSpace = false;
						}						
						break;
					}					
				}
				else
				{
					break;
				}
			}		

			if (bNeedCSpace)
			{
				CSpaceTestPoint(pcTaskArrayByPeriod[i]->getTaskIndex(), pcTaskArrayByPeriod[i]->getDeadline(),
					m_ptagTaskTPCCArray[pcTaskArrayByPeriod[i]->getTaskIndex()].setTestPoints);
			}
		}	
	}
	//Link
	for (int i = 0; i < m_iLinkNum; i++)
	{
		int iSourceIndex = m_ptagLinkTPCCArray[i].iSourceTask;
		int iDestIndex = m_ptagLinkTPCCArray[i].iDestTask;
		if (pcTaskArray[iSourceIndex].getPeriod() < pcTaskArray[iDestIndex].getPeriod())
		{
			if (pcTaskArray[iSourceIndex].getCriticality() && !(pcTaskArray[iDestIndex].getCriticality()))
			{
				CSpaceTestPoint(iSourceIndex, pcTaskArray[iSourceIndex].getDeadline(),
					m_ptagLinkTPCCArray[i].setTestPoints);
			}
			else
			{
				m_ptagLinkTPCCArray[i].setTestPoints = m_ptagTaskTPCCArray[iSourceIndex].setTestPoints;
			}
		}			
	}	
}

void TPCCSet::CSpaceTestPoint(int iTaskIndex, double dTotalTime, set<double> & rsetStore)
{
	Task ** pcTaskArrayByPeriod = m_pcTargetTaskSet->getTaskArrayByPeriosPtr();
	int iTaskNum = m_pcTargetTaskSet->getTaskNum();
	int iIndex = 0;
	for (; iIndex < iTaskNum; iIndex++)
	{
		if (pcTaskArrayByPeriod[iIndex]->getTaskIndex() == iTaskIndex)
		{
			//iIndex--;
			break;
		}		
	}

	set<CSpaceRecurEntry> cRecurEntry;
	CSpaceTestPointRecur(iIndex - 1, dTotalTime, rsetStore, cRecurEntry);
}

void TPCCSet::CSpaceTestPointRecur(int iCurrentIndex, 
	double dTotalTime, set<double> & rsetStore, set<CSpaceRecurEntry> & rsetRecurEntry)
{
	//cout << iCurrentIndex << " " << dTotalTime << endl;
	if (abs(dTotalTime - 0.0) < 1e-9)
	{
		return;
	}

	if (rsetRecurEntry.find(CSpaceRecurEntry(iCurrentIndex, dTotalTime)) != rsetRecurEntry.end())
	{		
		return;
	}
	rsetRecurEntry.insert(CSpaceRecurEntry(iCurrentIndex, dTotalTime));
	Task ** pcTaskByPeriod = m_pcTargetTaskSet->getTaskArrayByPeriosPtr();
	if (iCurrentIndex == -1)
	{
		//cout << "Insert:" << dTotalTime << endl;
		rsetStore.insert(dTotalTime);
	}
	else
	{
		//find the next greatest
		double fNextT = floor(dTotalTime / pcTaskByPeriod[iCurrentIndex]->getPeriod()) * pcTaskByPeriod[iCurrentIndex]->getPeriod();
		if (fNextT != 0)
			CSpaceTestPointRecur(iCurrentIndex - 1, fNextT, rsetStore, rsetRecurEntry);
		CSpaceTestPointRecur(iCurrentIndex - 1, dTotalTime, rsetStore, rsetRecurEntry);
	}
	return;
}

void TPCCSet::CSpaceTestPoint(int iTaskIndex, double dTotalTime, TaskSet & rcTaskSet, set<double> & rsetStore)
{
	Task ** pcTaskArrayByPeriod = rcTaskSet.getTaskArrayByPeriosPtr();
	int iTaskNum = rcTaskSet.getTaskNum();
	int iIndex = 0;
	for (; iIndex < iTaskNum; iIndex++)
	{
		if (pcTaskArrayByPeriod[iIndex]->getTaskIndex() == iTaskIndex)
		{
			//iIndex--;
			break;
		}
	}

	set<CSpaceRecurEntry> cRecurEntry;
	CSpaceTestPointRecur(iIndex - 1, dTotalTime, rcTaskSet, rsetStore, cRecurEntry);
}

void TPCCSet::CSpaceTestPointRecur(int iCurrentIndex, double dTotalTime, 
	TaskSet & rcTaskSet, set<double> & rsetStore, set<CSpaceRecurEntry> & rsetRecurEntry)
{
	//cout << iCurrentIndex << " " << dTotalTime << endl;
	if (abs(dTotalTime - 0.0) < 1e-9)
	{
		return;
	}

	if (rsetRecurEntry.find(CSpaceRecurEntry(iCurrentIndex, dTotalTime)) != rsetRecurEntry.end())
	{
		return;
	}
	rsetRecurEntry.insert(CSpaceRecurEntry(iCurrentIndex, dTotalTime));
	Task ** pcTaskByPeriod = rcTaskSet.getTaskArrayByPeriosPtr();
	if (iCurrentIndex == -1)
	{
		//cout << "Insert:" << dTotalTime << endl;
		rsetStore.insert(dTotalTime);
	}
	else
	{
		//find the next greatest
		double fNextT = floor(dTotalTime / pcTaskByPeriod[iCurrentIndex]->getPeriod()) * pcTaskByPeriod[iCurrentIndex]->getPeriod();
		if (fNextT != 0)
			CSpaceTestPointRecur(iCurrentIndex - 1, fNextT, rcTaskSet, rsetStore, rsetRecurEntry);
		CSpaceTestPointRecur(iCurrentIndex - 1, dTotalTime, rcTaskSet, rsetStore, rsetRecurEntry);
	}
	return;
}

void TPCCSet::HICompleteTestPointPerTask(int iTaskIndex, double dTotalTime, set<double> & rsetStore)
{
	int iTaskNum = m_pcTargetTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTargetTaskSet->getTaskArrayPtr();
	Task ** pcTaskArrayByPeriod = m_pcTargetTaskSet->getTaskArrayByPeriosPtr();
	my_assert(pcTaskArray[iTaskIndex].getCriticality(), "Method only used on HI-crit Task");
	for (int i = 0; i < iTaskNum; i++)
	{
		if (pcTaskArrayByPeriod[i]->getPeriod() > pcTaskArray[iTaskIndex].getPeriod())
			break;

//		if (!(pcTaskArrayByPeriod[i]->getCriticality()))
			//continue;

		double dPeriod = pcTaskArrayByPeriod[i]->getPeriod();
		double dTestPoint = dPeriod;
		while (dTestPoint <= dTotalTime)
		{
			rsetStore.insert(dTestPoint);
			dTestPoint += dPeriod;
		}

				
	}
}

void TPCCSet::GenRawTPCC()
{
	//generate for Task First
	my_assert(m_pcTargetTaskSet, "Need a correlation with TaskSet First");
	GenRawTestPoints();
	GenRawCritiChanges();
}

void TPCCSet::GenCompleteTPCC()
{
	my_assert(m_pcTargetTaskSet, "Need a correlation with TaskSet First");
	GenCompleteTestPoints();
	GenRawCritiChanges();
}

set<double> & TPCCSet::getTestPoints(int iTaskIndex)
{
	return m_ptagTaskTPCCArray[iTaskIndex].setTestPoints;
}

set<double> & TPCCSet::getTestPoints(int iSource, int iDest)
{
	for (int i = 0; i < m_iLinkNum; i++)
	{
		if ((m_ptagLinkTPCCArray[i].iSourceTask == iSource) &&
			(m_ptagLinkTPCCArray[i].iDestTask == iDest))
		{
			return m_ptagLinkTPCCArray[i].setTestPoints;
		}			
	}
	my_assert(false, "Illegal Access to Link Test Set");
	return m_ptagLinkTPCCArray[0].setTestPoints;
}

set<double> & TPCCSet::getCritiChanges(int iTaskIndex)
{
	return m_ptagTaskTPCCArray[iTaskIndex].setCritiChanges;
}

set<double> & TPCCSet::getCritiChanges(int iSource, int iDest)
{
	for (int i = 0; i < m_iLinkNum; i++)
	{
		if ((m_ptagLinkTPCCArray[i].iSourceTask == iSource) &&
			(m_ptagLinkTPCCArray[i].iDestTask == iDest))
		{
			return m_ptagLinkTPCCArray[i].setCritiChanges;
		}
	}
	my_assert(false, "Illegal Access to Link Test Set");
	return m_ptagLinkTPCCArray[0].setCritiChanges;
}

void TPCCSet::DisplayTestPoint(int iTaskIndex)
{
	cout << "Task " << iTaskIndex << " TP: ";
	DisplaySetContent(m_ptagTaskTPCCArray[iTaskIndex].setTestPoints);
}

void TPCCSet::DisplayTestPoint(int iSource, int iDest)
{
	for (int i = 0; i < m_iLinkNum; i++)
	{
		if ((m_ptagLinkTPCCArray[i].iSourceTask == iSource) && 
			(m_ptagLinkTPCCArray[i].iDestTask == iDest))
		{ 
			printf_s("Link(%d,%d) TP: ", iSource, iDest);
			DisplaySetContent(m_ptagLinkTPCCArray[i].setTestPoints);
			return;
		}
	}
	my_assert(false, "Illegal Access to Test Set");
	return;
}

void TPCCSet::DisplayCritiChange(int iTaskIndex)
{
	cout << "Task " << iTaskIndex << " CC: ";
	DisplaySetContent(m_ptagTaskTPCCArray[iTaskIndex].setCritiChanges);
}

void TPCCSet::DisplayCritiChange(int iSource, int iDest)
{
	for (int i = 0; i < m_iLinkNum; i++)
	{
		if ((m_ptagLinkTPCCArray[i].iSourceTask == iSource) &&
			(m_ptagLinkTPCCArray[i].iDestTask == iDest))
		{
			printf_s("Link(%d,%d) CC: ", iSource, iDest);
			DisplaySetContent(m_ptagLinkTPCCArray[i].setCritiChanges);
			return;
		}
	}
	my_assert(false, "Illegal Access to Test Set");
	return;
}

void TPCCSet::DisplaySetContent(set<double> & rsetSet)
{
	if (rsetSet.empty())
		return;
	cout << "(";
	for (set<double>::iterator iter = rsetSet.begin();
		iter != rsetSet.end(); iter++)
	{
		cout << *iter << ",";
	}
	cout << "\b)";
}

void TPCCSet::WriteTPCCImage(char axFileName[])
{
	ofstream ofstreamWriteFile(axFileName, ios::out | ios::binary);
	//Write the Task TPCC first
	ofstreamWriteFile.write((const char *)&m_iTaskNum, sizeof(int));
	for (int i = 0; i < m_iTaskNum; i++)
	{
		WriteSetContentImage(m_ptagTaskTPCCArray[i].setTestPoints,ofstreamWriteFile);
		WriteSetContentImage(m_ptagTaskTPCCArray[i].setCritiChanges, ofstreamWriteFile);
	}

	//Write the Link TPCC then
	ofstreamWriteFile.write((const char *)& m_iLinkNum, sizeof(int));
	for (int i = 0; i < m_iLinkNum; i++)
	{
		ofstreamWriteFile.write((const char *)&m_ptagLinkTPCCArray[i].iSourceTask,sizeof(int));
		ofstreamWriteFile.write((const char *)&m_ptagLinkTPCCArray[i].iDestTask, sizeof(int));
		WriteSetContentImage(m_ptagLinkTPCCArray[i].setTestPoints, ofstreamWriteFile);
		WriteSetContentImage(m_ptagLinkTPCCArray[i].setCritiChanges, ofstreamWriteFile);
	}
	ofstreamWriteFile.close();
}

void TPCCSet::WriteSetContentImage(set<double> & rsetSet, ofstream & ofstreamWriteFile)
{
	int iSize = rsetSet.size();
	ofstreamWriteFile.write((const char *)&iSize, sizeof(int));
	for (set<double>::iterator iter = rsetSet.begin();
		iter != rsetSet.end(); iter++)
	{
		double dValue = *iter;
		ofstreamWriteFile.write((const char *)&dValue, sizeof(double));
	}
	return;
}

void TPCCSet::ReadTPCCImage(char axFileName[])
{
	ifstream ifstreamReadFile(axFileName, ios::in | ios::binary);
	my_assert(ifstreamReadFile.is_open(), "Cannot Find File");
	//As a rule, Read the Task TPCC First
	int iTaskSize = 0;		
	ifstreamReadFile.read((char *)&iTaskSize, sizeof(int));
	m_iTaskNum = iTaskSize;
	CreateTaskTPCCArray(iTaskSize);
	for (int i = 0; i < iTaskSize; i++)
	{
		ReadSetContentImage(m_ptagTaskTPCCArray[i].setTestPoints, ifstreamReadFile);
		ReadSetContentImage(m_ptagTaskTPCCArray[i].setCritiChanges, ifstreamReadFile);
	}

	//Then Read The Link TPCC.
	ifstreamReadFile.read((char *)&m_iLinkNum, sizeof(int));
	CreateLinkTPCCArray(m_iLinkNum);
	for (int i = 0; i < m_iLinkNum; i++)
	{
		ifstreamReadFile.read((char *)&m_ptagLinkTPCCArray[i].iSourceTask, sizeof(int));
		ifstreamReadFile.read((char *)&m_ptagLinkTPCCArray[i].iDestTask, sizeof(int));
		ReadSetContentImage(m_ptagLinkTPCCArray[i].setTestPoints, ifstreamReadFile);
		ReadSetContentImage(m_ptagLinkTPCCArray[i].setCritiChanges, ifstreamReadFile);
	}
	ifstreamReadFile.close();
}

void TPCCSet::ReadSetContentImage(set<double> & rsetSet, ifstream & ifstreamReadFile)
{
	int iSize = 0;
	ifstreamReadFile.read((char *)& iSize, sizeof(int));
	for (int i = 0; i < iSize; i++)
	{
		double dValue = 0;
		ifstreamReadFile.read((char *)&dValue, sizeof(double));
		rsetSet.insert(dValue);
	}
}

void TPCCSet::CreateLinkTPCCArray(int iSize)
{
	DestroyLinkTPCCArray();
	m_ptagLinkTPCCArray = new TPCCStructLink[iSize];
}

void TPCCSet::DestroyLinkTPCCArray()
{
	if (m_ptagLinkTPCCArray)
	{
		delete[] m_ptagLinkTPCCArray;
	}
	m_ptagLinkTPCCArray = NULL;
}

void TPCCSet::CreateTaskTPCCArray(int iSize)
{
	DestroyTaskTPCCArray();
	m_ptagTaskTPCCArray = new TPCCStructTask[iSize];
}

void TPCCSet::DestroyTaskTPCCArray()
{
	if (m_ptagTaskTPCCArray)
	{
		delete[] m_ptagTaskTPCCArray;
	}
	m_ptagTaskTPCCArray = NULL;
}

void TPCCSet::CopyFrom(TPCCSet & rcTPCCSet)
{
	m_pcTargetTaskSet = rcTPCCSet.getHostTaskSet();
	m_iLinkNum = rcTPCCSet.getLinkNum();
	m_iTaskNum = rcTPCCSet.getTaskNum();
	CreateTaskTPCCArray(m_iTaskNum);
	CreateLinkTPCCArray(m_iLinkNum);
	TPCCStructTask * ptagTaskTPCCArray = rcTPCCSet.getTaskTPCCArray();
	TPCCStructLink * ptagLinkTPCCArray = rcTPCCSet.getLinkTPCCArray();
	for (int i = 0; i < m_iTaskNum; i++)
	{
		m_ptagTaskTPCCArray[i].setTestPoints = ptagTaskTPCCArray[i].setTestPoints;
		m_ptagTaskTPCCArray[i].setCritiChanges = ptagTaskTPCCArray[i].setCritiChanges;
	}
	for (int i = 0; i < m_iLinkNum; i++)
	{
		m_ptagLinkTPCCArray[i].iDestTask = ptagLinkTPCCArray[i].iDestTask;
		m_ptagLinkTPCCArray[i].iSourceTask = ptagLinkTPCCArray[i].iSourceTask;
		m_ptagLinkTPCCArray[i].setTestPoints = ptagLinkTPCCArray[i].setTestPoints;
		m_ptagLinkTPCCArray[i].setCritiChanges = ptagLinkTPCCArray[i].setCritiChanges;
	}
}

void TPCCSet::WriteTPCCText(char axFileName[], bool bAppend, char * pcTitle)
{
	std::ios_base::openmode Mode;
	if (bAppend)
	{
		Mode = ios::out | ios::app;
	}
	else
	{
		Mode = ios::out;
	}
	ofstream ofstreamOutputFile(axFileName, Mode);
	if (pcTitle)
		ofstreamOutputFile << pcTitle << endl;
	//Write Task First 
	char axBuffer[256] = { 0 };
	for (int i = 0; i < m_iTaskNum; i++)
	{
		sprintf_s(axBuffer, "---------------------Task %d---------------------", i); ofstreamOutputFile << axBuffer << endl;
		ofstreamOutputFile << "TT(Size: " << m_ptagTaskTPCCArray[i].setTestPoints.size() << "): ";
		WriteSetContentText(m_ptagTaskTPCCArray[i].setTestPoints, ofstreamOutputFile); ofstreamOutputFile << endl;
		ofstreamOutputFile << "CC(Size: " << m_ptagTaskTPCCArray[i].setCritiChanges.size() << "): ";
		WriteSetContentText(m_ptagTaskTPCCArray[i].setCritiChanges, ofstreamOutputFile); ofstreamOutputFile << endl;
	}
	ofstreamOutputFile << endl;
	//Then Write Link
	for (int i = 0; i < m_iLinkNum; i++)
	{
		sprintf_s(axBuffer, "---------------------Link(%d,%d)---------------------",m_ptagLinkTPCCArray[i].iSourceTask,m_ptagLinkTPCCArray[i].iDestTask);
		ofstreamOutputFile << axBuffer << endl;
		ofstreamOutputFile << "TT(Size: " << m_ptagLinkTPCCArray[i].setTestPoints.size() << "): ";
		WriteSetContentText(m_ptagLinkTPCCArray[i].setTestPoints, ofstreamOutputFile); ofstreamOutputFile << endl;
		ofstreamOutputFile << "CC(Size: " << m_ptagLinkTPCCArray[i].setCritiChanges.size() << "): ";
		WriteSetContentText(m_ptagLinkTPCCArray[i].setCritiChanges, ofstreamOutputFile); ofstreamOutputFile << endl;
	}
	ofstreamOutputFile.close();
}

void TPCCSet::WriteSetContentText(set<double> & rsetSet, ofstream & ofstreamWriteFile)
{
	for (set<double>::iterator iter = rsetSet.begin();
		iter != rsetSet.end(); iter++)
	{
		ofstreamWriteFile << *iter << ", ";
	}
}

int TPCCSet::getTPNumTask(int iTaskIndex)
{
	return m_ptagTaskTPCCArray[iTaskIndex].setTestPoints.size();
}

int TPCCSet::getTPNumLink(int iSource, int iDest)
{
	for (int i = 0; i < m_iLinkNum;i++)
	{
		if ((m_ptagLinkTPCCArray[i].iSourceTask == iSource) && (m_ptagLinkTPCCArray[i].iDestTask == iDest))
		{
			return m_ptagLinkTPCCArray[i].setTestPoints.size();
		}
	}
	my_assert(false, "Cannot Find The Specified Link");
	return -1;
}

int TPCCSet::getTPNumTotal()
{
	int iTPNumTotal = 0;
	for (int i = 0; i < m_iLinkNum; i++)
	{
		iTPNumTotal += m_ptagLinkTPCCArray[i].setTestPoints.size();		
	}

	for (int i = 0; i < m_iTaskNum; i++)
	{
		iTPNumTotal += m_ptagTaskTPCCArray[i].setTestPoints.size();
	}

	return iTPNumTotal;
}

int TPCCSet::getHITPNumTotal()
{
	int iTPNumTotal = 0;
	for (int i = 0; i < m_iLinkNum; i++)
	{
		if (m_ptagLinkTPCCArray[i].setCritiChanges.size())
			iTPNumTotal += m_ptagLinkTPCCArray[i].setTestPoints.size();
	}

	for (int i = 0; i < m_iTaskNum; i++)
	{
		if (m_ptagTaskTPCCArray[i].setCritiChanges.size())
			iTPNumTotal += m_ptagTaskTPCCArray[i].setTestPoints.size();
	}

	return iTPNumTotal;
}

void TPCCSet::TaskTPNumStatistic(std::map<int, int> & rmapStat)
{
	for (int i = 0; i < m_iTaskNum; i++)
	{
		int iTPNum = getTPNumTask(i);
		if (rmapStat.count(iTPNum) == 1)
		{
			rmapStat[iTPNum]++;
		}
		else
		{
			rmapStat[iTPNum] = 1;
		}
	}
}

//class TPCCSet_PerDeadlines

TPCCSet_PerDeadlines::TPCCSet_PerDeadlines()
{

}

TPCCSet_PerDeadlines::~TPCCSet_PerDeadlines()
{

}

TPCCSet_PerDeadlines::TPCCSet_PerDeadlines(TaskSet & rcTaskSet)
{

}

void TPCCSet_PerDeadlines::Initialize(TaskSet & rcTaskSet)
{
	GET_TASKSET_NUM_PTR(&rcTaskSet, iTaskNum, pcTaskArray);
	m_pcTargetTaskSet = &rcTaskSet;
	m_vectorTPCCs.reserve(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		TaskTPCCData cNewData;		
		m_vectorTPCCs.push_back(cNewData);
		m_vectorTPCCs.back().push_back(DeadlineTPCCTuple(pcTaskArray[i].getDeadline()));
	}
}

void TPCCSet_PerDeadlines::Clear()
{
	m_vectorTPCCs.clear();
}

void TPCCSet_PerDeadlines::GenAllTPCC()
{
	GenAllCritiChanges();
	GenAllRawTestPoint();
}

void TPCCSet_PerDeadlines::GenAllCritiChanges()
{
	GET_TASKSET_NUM_PTR(m_pcTargetTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (TaskTPCCData::iterator iter = m_vectorTPCCs[i].begin();
			iter != m_vectorTPCCs[i].end(); iter++)
		{
			GenRawCritiChangesSingle(i, iter->dDeadline, iter->tagTPCCStruct.setCritiChanges);
		}
	}
}

void TPCCSet_PerDeadlines::GenAllRawTestPoint()
{
	GET_TASKSET_NUM_PTR(m_pcTargetTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (TaskTPCCData::iterator iter = m_vectorTPCCs[i].begin();
			iter != m_vectorTPCCs[i].end(); iter++)
		{
			CSpaceTestPoint(i, iter->dDeadline, iter->tagTPCCStruct.setTestPoints);
		}
	}
}

void TPCCSet_PerDeadlines::AddDeadline(int iTaskIndex, double dDeadline)
{
	assert(iTaskIndex < m_vectorTPCCs.size());
	for (TaskTPCCData::iterator iter = m_vectorTPCCs[iTaskIndex].begin();
		iter != m_vectorTPCCs[iTaskIndex].end(); iter++)
	{
		if (DOUBLE_EQUAL(iter->dDeadline, dDeadline, 1e-7))
		{
			return;
		}
	}
	m_vectorTPCCs[iTaskIndex].push_back(DeadlineTPCCTuple(dDeadline));
}

set<double> & TPCCSet_PerDeadlines::getTestPoints(int iTaskIndex, double dDeadline)
{
	assert(iTaskIndex < m_vectorTPCCs.size());
	for (TaskTPCCData::iterator iter = m_vectorTPCCs[iTaskIndex].begin();
		iter != m_vectorTPCCs[iTaskIndex].end(); iter++)
	{
		if (DOUBLE_EQUAL(iter->dDeadline, dDeadline, 1e-7))
		{
			return iter->tagTPCCStruct.setTestPoints;
		}
	}

	cout << "No such deadline " << dDeadline << endl;
	while (1);
	return m_setDummy;
}

set<double> & TPCCSet_PerDeadlines::getCritChanges(int iTaskIndex, double dDeadline)
{
	assert(iTaskIndex < m_vectorTPCCs.size());
	for (TaskTPCCData::iterator iter = m_vectorTPCCs[iTaskIndex].begin();
		iter != m_vectorTPCCs[iTaskIndex].end(); iter++)
	{
		if (DOUBLE_EQUAL(iter->dDeadline, dDeadline, 1e-7))
		{
			return iter->tagTPCCStruct.setCritiChanges;
		}
	}

	cout << "No such deadline " << dDeadline << endl;
	while (1);
	return m_setDummy;
}

void TPCCSet_PerDeadlines::WriteTPCCText(const char axFileName[])
{
	ofstream ofstreamOutputFile(axFileName, ios::out);
	int iSize = m_vectorTPCCs.size();
	for (int i = 0; i < iSize; i++)
	{
		ofstreamOutputFile << "----------------------Task " << i << "----------------------" << endl;
		for (TaskTPCCData::iterator iter = m_vectorTPCCs[i].begin();
			iter != m_vectorTPCCs[i].end(); iter++)
		{			
			ofstreamOutputFile << "Deadline: " << iter->dDeadline << endl;
			ofstreamOutputFile << "Test Points: ";
			WriteSetContentText(iter->tagTPCCStruct.setTestPoints, ofstreamOutputFile);
			ofstreamOutputFile << endl;
			ofstreamOutputFile << "Criti Changes: ";
			WriteSetContentText(iter->tagTPCCStruct.setCritiChanges, ofstreamOutputFile);
			ofstreamOutputFile << endl;
			ofstreamOutputFile << "**********" << endl;
		}		 
	}
	ofstreamOutputFile.close();
}

void TPCCSet_PerDeadlines::WriteTPCCImage(const char axFileName[])
{
	ofstream ofstreamOutputFile(axFileName, ios::out | ios::binary);
	int iSize = m_vectorTPCCs.size();
	ofstreamOutputFile.write((const char *)&iSize, sizeof(int));
	for (int i = 0; i < iSize; i++)
	{		
		int iDeadlinesNum = m_vectorTPCCs[i].size();
		ofstreamOutputFile.write((const char *)&iDeadlinesNum, sizeof(int));
		for (TaskTPCCData::iterator iter = m_vectorTPCCs[i].begin();
			iter != m_vectorTPCCs[i].end(); iter++)
		{
			double dDeadline = iter->dDeadline;
			ofstreamOutputFile.write((const char *)&dDeadline, sizeof(double));
			WriteSetContentImage(iter->tagTPCCStruct.setTestPoints, ofstreamOutputFile);
			WriteSetContentImage(iter->tagTPCCStruct.setCritiChanges, ofstreamOutputFile);
		}
	}
	ofstreamOutputFile.close();
}

void TPCCSet_PerDeadlines::ReadTPCCImage(const char axFileName[])
{
	ifstream ifstreamInputFile(axFileName, ios::in | ios::binary);
	int iSize = 0;
	ifstreamInputFile.read((char *)&iSize, sizeof(int));
	m_vectorTPCCs.reserve(iSize);
	for (int i = 0; i < iSize; i++)
	{
		m_vectorTPCCs.push_back(TaskTPCCData());
		TaskTPCCData & rcNewData = m_vectorTPCCs.back();
		int iDeadlineNum = 0;
		ifstreamInputFile.read((char *)&iDeadlineNum, sizeof(int));
		for (int j = 0; j < iDeadlineNum; j++)
		{
			double dDeadline = 0;
			ifstreamInputFile.read((char *)&dDeadline, sizeof(double));
			rcNewData.push_back(DeadlineTPCCTuple(dDeadline));
			ReadSetContentImage(rcNewData.back().tagTPCCStruct.setTestPoints, ifstreamInputFile);
			ReadSetContentImage(rcNewData.back().tagTPCCStruct.setCritiChanges, ifstreamInputFile);
		}
	}
	ifstreamInputFile.close();
}

TPCCSet_PerDeadlines::TaskTPCCData TPCCSet_PerDeadlines::getTaskTPCCData(int iTaskIndex)
{
	assert(iTaskIndex < m_vectorTPCCs.size());
	return m_vectorTPCCs[iTaskIndex];
}