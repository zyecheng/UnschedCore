#pragma once
//#include "AudsleyEngine.h"
#include "TaskSet.h"
#include <deque>
#include <vector>
#include "MySet.h"
#include "RTSchedPTree.h"
#include "PartialOrderSet.hpp"
#include "BitMask.h"
#include "SetTrie.h"
#include "BitMaskStorage_N_LowestSet.h"


class UnschedCoreComputer
{
public:

	class PriorityPOElement
	{
	public:
		int m_iHPTask;
		int m_iLPTask;
	public:
		PriorityPOElement();
		PriorityPOElement(int iHPTask, int iLPTask)
		{
			m_iHPTask = iHPTask;
			m_iLPTask = iLPTask;
		}

		~PriorityPOElement()	{}
		friend inline bool operator < (const PriorityPOElement & rcLHS, const PriorityPOElement & rcRHS)
		{
			if (rcLHS.m_iHPTask == rcRHS.m_iHPTask)
			{
				return rcLHS.m_iLPTask < rcRHS.m_iLPTask;
			}
			else
			{
				return rcLHS.m_iHPTask < rcRHS.m_iHPTask;
			}
		}
		friend ostream & operator << (ostream & os, const PriorityPOElement & rcEle)
		{
			os << "(" << rcEle.m_iLPTask << ", " << rcEle.m_iHPTask << ")";
			return os;
		}
	};

	//typedef RTSchedPTree::PriorityPOElement PriorityPOElement;
	typedef map<int, set<int> > PriorityPOMap;
	typedef MySet<PriorityPOElement> PriorityPOSet;
	typedef vector<PriorityPOElement> PriorityPOVec;
	typedef deque<PriorityPOSet>	UnschedCores;				
	class PriorityPOOccurrenceComp
	{
	private:
		int ** m_ppiPOOccurrence;
	public:
		PriorityPOOccurrenceComp()	{}

		PriorityPOOccurrenceComp(int ** ppiPOOccurrence);

		inline bool operator() (const PriorityPOElement & rcLHS, const PriorityPOElement & rcRHS)
		{
			if (m_ppiPOOccurrence == NULL)
			{
				cout << "Please give the occurrence statistic table!" << endl;
				assert(0);
			}
			int iOccurLHS = m_ppiPOOccurrence[rcLHS.m_iHPTask][rcLHS.m_iLPTask];
			int iOccurRHS = m_ppiPOOccurrence[rcRHS.m_iHPTask][rcRHS.m_iLPTask];
			if (iOccurLHS == iOccurRHS)
			{
				if (rcLHS.m_iHPTask == rcRHS.m_iHPTask)
				{
					return rcLHS.m_iLPTask < rcRHS.m_iLPTask;
				}
				else
				{
					return rcLHS.m_iHPTask < rcRHS.m_iHPTask;
				}
			}
			else
			{
				return iOccurLHS > iOccurRHS;
			}
		}
	};
	typedef MySet<PriorityPOElement, PriorityPOOccurrenceComp> PriorityPOSetOccurSort;

	class PriorityPOSetComp
	{
	public:
		inline bool operator () (const PriorityPOSet & rcLHS, const PriorityPOSet & rcRHS)
		{
			if (rcLHS.size() == rcRHS.size())
			{
				PriorityPOSet::iterator iterLHS = rcLHS.begin();
				PriorityPOSet::iterator iterRHS = rcRHS.begin();
				for (; iterLHS != rcLHS.end(); iterLHS++, iterRHS++)
				{										
					if (*iterLHS < *iterRHS)
					{
						return true;
					}
					else if (*iterRHS < *iterLHS)
					{
						return false;
					}
				}
			}
			else
			{
				return rcLHS.size() < rcRHS.size();
			}
			return false;
		}		
	};

	enum SchedulabilityTestOption
	{
		SchedTest_Original,
		SchedTest_LookUpTable
	};

	enum SortingOption
	{
		None,
		ByOccurence
	};

	enum UnschedCoreCompOpt
	{
		UCOpt_Original,
		UCOpt_HinderingPPO,
		UCOpt_BinGrouping,
		UCOpt_QuickPPOSched,
		UCOpt_ReusedLowestAssigned
	};

public:
	TaskSet * m_pcTaskSet;
	UnschedCores m_cCollectedCores;
	int ** m_ppiPOOccurrence;
	PriorityPOSetOccurSort m_cPOOccurrenceSort;
	void * m_pvSchedTestData;
	vector<int> m_vectorLowestFeasiblePriority;

	SchedulabilityTestOption m_enumSchedTestOption;
	SortingOption m_enumSortingOption;
	UnschedCoreCompOpt m_enumUnschedCoreOption;

#if 0
	//An Implementation Trick to Speedup
	typedef deque<BitMask> HPSetsEncoding;
	typedef vector<HPSetsEncoding> HPSetsEncodings;	
	HPSetsEncodings m_cFeasibleHPSets;
	HPSetsEncodings m_cInfeasibleHPSets;	
#endif

	//Trick based on bitmask with finer partition
	typedef vector<BitMaskStorage_N_LowestSet> SystemHPBitMaskTableNLH;
	SystemHPBitMaskTableNLH m_vectorSystemFeaHPBitMaskNLH;
	SystemHPBitMaskTableNLH m_vectorSystemInfeaHPBitMaskNLH;
	



	//Some statistic
public:
	double m_dTimeOnSchedTest;
	double m_dTimeOnIsSchedulable;
	double m_dTimeOnQuickSchedTest;
	double m_dTimeOnQuickSchedTest_Hit;
	double m_dTimeOnQuickSchedTest_Miss;
	int m_iQuickSchedTestInsertions;	
	deque<std::pair<unsigned int, unsigned int> > m_dequeQuickSchedTestSubSetSearchHitNAttempts;	
	deque<std::pair<unsigned int, unsigned int> > m_dequeQuickSchedTestSupSetSearchHitNAttempts;

	double m_dTimeOnSchedulable;
	double m_dTimeOnUnschedulable;
	int m_iSchedTestCall;
public:
	UnschedCoreComputer();
	UnschedCoreComputer(TaskSet & rcTaskSet);
	~UnschedCoreComputer();
	void Initialize(TaskSet & rcTaskSet);
	void setLowestPriority(int iTaskIndex, int iPriority);
	int getLowestPriority(int iTaskIndex);
	const UnschedCores & getUnschedCores()	 { return m_cCollectedCores; }	
	void setSchedTestOption(SchedulabilityTestOption enumOption)	{ m_enumSchedTestOption = enumOption; }
	void setSortingOption(SortingOption enumOption)	{ m_enumSortingOption = enumOption; }
	void setUnschedCoreCompOption(UnschedCoreCompOpt enumOption)	{ m_enumUnschedCoreOption = enumOption; }
	SchedulabilityTestOption getSchedTestOption()	{ return m_enumSchedTestOption; }
	bool IsSchedulable();
	bool IsSchedulable(TaskSetPriorityStruct & rcPriorityAssignment);
	bool IsSchedulable(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment);
	bool IsSchedulable(TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet);
	int ComputeUnschedCores(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, UnschedCores & rcUnschedCores, int iLimit, double dTimeout = 1e74);
	void ComputeAllCores(UnschedCores & rcUnschedCores);
	static void WriteUnschedCoreToFile(char axFileName[], UnschedCores & rcUnschedCores);
	static void ReadUnschedCoreFromFile(char axFileName[], UnschedCores & rcUnschedCores);
	void PrintStatistic(const char axFileName[]);
	
	typedef deque<MySet<int> > IntSetDeque;
	static void CondenseCores(UnschedCores & rcOrginalCores, UnschedCores & rcCondensedCores, IntSetDeque & rdequeMapping, MySet<int> & rsetIndices, int iCondensedDegree = -1);
	static void FindLimitingCore(PriorityPOSet & rcPPOSet, UnschedCores & rcCores, MySet<int> & rsetIndices);
	void RemoveRedundantPPO(PriorityPOSet & rcPPOSet);	
protected:
	//Fast General Unsched Core
	bool ConvertToUC(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore);	
	bool doConvertToUC_v0(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore);
	bool doConvertToUC_v1(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore);
	int IsPOBurden(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPriorityPOSet);
	virtual bool IsSchedulable(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
		TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs);
	bool doIsSchedulable_v1(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
		TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs);	
	bool doIsSchedulable_v2(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
		TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs);
	bool doIsSchedulable_v3(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
		TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs);
	bool doIsSchedulable_v4(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
		TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs);

	inline virtual bool PreInsertPAEncoding(int iTaskIndex, bool SchedStatus, BitMask & rcEncoding)	{ return true; }
	int Recur(int iLevel, int iLimit, PriorityPOSet & rcPriorityPOSet,
		PriorityPOSet & rcFixedPOSet, UnschedCores & rdequeCollectedCores, double dTimeStart, double dTimeout);

	void IncPOOccurrence(int iHPTask, int iLPTask);
	void UpdateOccurStat(PriorityPOSet & rcCores);
	void RemoveHighFreqPO(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedSet);
	void ConvertToOccurSort(PriorityPOSet & rcPriorityPOSet, PriorityPOSetOccurSort & rcPOByOccurrence);		
	void ConvertToOriginal(PriorityPOSetOccurSort & rcPOByOccurrence, PriorityPOSet & rcPriorityPOSet);
	PriorityPOSetOccurSort CreatePOOccurSort();

	virtual void PreSchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet)	{}
	bool SchedTestWrapper(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData);
	virtual bool SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData);

	//Hopefully Quick UnschedCoreComp
	bool doConvertToUC_v2(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore);	
	bool ConvertToUC_Primitive(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet);
	bool ConvertToUC_VarSizeGrouping(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet, int iBlockSize, TaskSetPriorityStruct & rcPA);

public:
	double getTimeOnIsSchedulableCalls()	{ return m_dTimeOnIsSchedulable; }
	double getTimeOnSchedTestCalls()	{ return m_dTimeOnSchedTest; }
	double getTimeOnQuickSchedTestCalls()	{ return m_dTimeOnQuickSchedTest; }
	double getTimeOnQuickSchedTestCallsHit()	{ return m_dTimeOnQuickSchedTest_Hit; }
	double getTimeOnQuickSchedTestCallsMiss()	{ return m_dTimeOnQuickSchedTest_Miss; }

protected:
	BitMask HPSetsToBitMask(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment);
	void getHPSet(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, MySet<int> & rcHPSet);		
	virtual int QuickSchedTest_Forv4(int iTaskIndex, BitMask & rcHPSets);	
	//void DetermineDominancy(BitMask & rcNewEncoding, HPSetsEncoding & rcEncoding, bool bType);



protected:
	//PPO level Quick Sched Test
	PriorityPOSet m_cPPORange;
	map<PriorityPOElement, int> m_mapPPOToIndex;
	vector<PriorityPOElement> m_vectorPPORangeSequence;
	BitMaskStorage_N_LowestSet m_cPPOSchedEncoding;
	BitMaskStorage_N_LowestSet m_cPPOUnschedEncoding;
	BitMask EncodePPOtoBitMask(PriorityPOSet & rcPPOSet);
	void DecodeBitMasktoPPO(BitMask & rcBitMask, PriorityPOSet & rcPPOSet);
	void ConvertPAToPPOInRange(TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet);
	int QuickPPOSchedTest(BitMask & rcPPOSetEncoding);
	bool ConvertToUC_QuickPPOSchedTest(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet);
	bool doConvertToUC_v3(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore);
	bool doConvertToUC_v4(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore);//Reused Lowest Assigned
public:
	void setPPORange(PriorityPOSet & rcRange);
};

class UnschedCoreComputer_AMCMax : public UnschedCoreComputer
{
public:
	UnschedCoreComputer_AMCMax();
	UnschedCoreComputer_AMCMax(TaskSet & rcTaskSet);
	~UnschedCoreComputer_AMCMax();
private:
	virtual bool SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData);
};

class UnschedCoreComputer_AMCRtb : public UnschedCoreComputer
{
public:
	UnschedCoreComputer_AMCRtb();
	UnschedCoreComputer_AMCRtb(TaskSet & rcTaskSet);
	~UnschedCoreComputer_AMCRtb();
private:
	virtual bool SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData);
};


//response time based unschedulability core
//based on the assumption that all response times are integers

