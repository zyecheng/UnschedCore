#pragma once
#include "RTSchedMILP_rbf_P.h"
#include "FocusRefinement.h"
#include <windows.h>
class SimuLinkMiniDelay_Link
{
public:
	int m_iSource;
	int m_iDestination;
public:
	SimuLinkMiniDelay_Link(int iSource, int iDestination)	{ m_iSource = iSource; m_iDestination = iDestination; }
	~SimuLinkMiniDelay_Link()	{}
	friend bool operator < (const SimuLinkMiniDelay_Link & rcLHS, const SimuLinkMiniDelay_Link & rcRHS);
};

class SimuLinkMiniDelay_LinkData
{
#define SIMULINK_LINKTYPE_HL	0
#define SIMULINK_LINKTYPE_EQ	1
#define SIMULINK_LINKTYPE_LH	2
public: 
	int m_iSource;
	int m_iDestination;
	double m_dDelayCost;
	double m_dMemoryCost;
	int m_iType;			
public:
	SimuLinkMiniDelay_LinkData();
	SimuLinkMiniDelay_LinkData(int iSource, int iDestination, double dMemoryCost, double dDelayCost, int iType);
	~SimuLinkMiniDelay_LinkData()	{}
};

class SimuLinkMiniDelay_LinkData_Comp
{
public:
	bool operator () (const SimuLinkMiniDelay_LinkData & rcLHS, const SimuLinkMiniDelay_LinkData & rcRHS)
	{

	}
};

class SimuLinkMiniDelay: public RTSchedMILP_rbf_P
{
public:
	typedef UnschedCoreComputer::UnschedCores UnschedCores;
protected:
	IloNumVarArray m_cLinkFBVar;
	typedef map<SimuLinkMiniDelay_Link, SimuLinkMiniDelay_LinkData> LinkMap;
	LinkMap m_cLinkObj;	
	double m_dMemoryCost;
	double m_dBestCost;	

	//Temp Data
	//set<SimuLinkMiniDelay_Link> m_setLinkInObj;
	typedef map<int, SimuLinkMiniDelay_LinkData> Index2LinkData;
	typedef map<SimuLinkMiniDelay_Link, int> Link2Index;
	map<SimuLinkMiniDelay_Link, int> m_mapLink2Index;
	map<int, SimuLinkMiniDelay_LinkData> m_mapIndex2LinkData;

	//Enhance with unschedulability core
	UnschedCores m_cUnschedCores;
public:
	SimuLinkMiniDelay();
	SimuLinkMiniDelay(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet);
	~SimuLinkMiniDelay();
	void PrintLHLinkStat();
	int Solve(int iModelType, int iDisplay, double dTimeout = 1e74);
	UnschedCores & getUnschedCores()	{ return m_cUnschedCores; }
protected:
	void InitializeLinkObj();
	void CreateFBVars(IloNumVarArray & rcFBVars);
	void CreateLinkEncoders(IloEnv & rcEnv, deque<DisjunctionEncoder> & rdequeEncoders);
	void GenRTLinkLOConst(SimuLinkMiniDelay_LinkData & rcLinkKey, IloNumVarArray & rcPVars, 
		IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void GenRTLinkLOConst(SimuLinkMiniDelay_LinkData & rcLinkKey, set<double> & rsetTP, IloNumVarArray & rcPVars,
		IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void GenRTLinkHIConst(SimuLinkMiniDelay_LinkData & rcLinkKey,
		IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void GenRTLinkHIConst(SimuLinkMiniDelay_LinkData & rcLinkKey, set<double> & rsetTP, set<double> & rsetCC,
		IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void BuildRTLinkHIConst(IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, deque<DisjunctionEncoder> & rdequeEncoder, IloRangeArray & rcRangeArray);
	void BuildRTLinkLOConst(IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, deque<DisjunctionEncoder> & rdequeEncoder, IloRangeArray & rcRangeArray);
	void GenMemoryConst(double dMemory, IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, IloRangeArray & rcRangeArray);
	void GenGenUCConst(IloNumVarArray & rcPVars, UnschedCores & rcGenUC, IloRangeArray & rcRangeArray);
	IloObjective GenObjective(IloNumVarArray & rcPVars);
	IloNumVar & getFBVar(int iSrc, int iDst, IloNumVarArray & rcFBVar);	
	void AnalyzePODET();	
	int getFBResult(int iSrc, int iDst, IloNumVarArray & rcFBVars, IloCplex & rcSolver);
	double ComputeMemory();
	double ComputeDelay();
	bool VerifyFB(IloNumVarArray & rcFBVars, IloCplex & rcSolver);
	bool VerifyMemory();
	bool VerifyDelayCost();	

	//Some Experimental Stuff
	void GenObjConst(double dObjValue, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray, int iBoundDir = 0);
};

class SimulinkMiniDelay_NoMemLH : public SimuLinkMiniDelay
{

public:
	SimulinkMiniDelay_NoMemLH();
	SimulinkMiniDelay_NoMemLH(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet);
	~SimulinkMiniDelay_NoMemLH();
	int Solve(int iModelType, int iDisplay, double dTimeout = 1e74);
protected:
	IloObjective GenObjective(IloNumVarArray & rcPVars);	
};

class SimuLinkMiniDelay_FR : public FocusRefinement
{
protected:
	typedef map<SimuLinkMiniDelay_Link, SimuLinkMiniDelay_LinkData> LinkMap;
	map<SimuLinkMiniDelay_Link, int> m_mapLink2Index;
	map<int, SimuLinkMiniDelay_LinkData> m_mapIndex2LinkData;
public:
	UnschedCoreComputer m_cUnschedCoreComputer;
public:
	SimuLinkMiniDelay_FR();
	SimuLinkMiniDelay_FR(TaskSet & rcTaskSet);
	~SimuLinkMiniDelay_FR();	
	virtual bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
protected:
	void InitializeLinkObj();
	virtual void GenFixedPPOSet(PriorityPOSet & rcFixedSet);
	virtual IloExpr ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO = NULL);
	virtual double getObjUB();
	bool VerifyDelay(double dDelay, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual bool VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment);
	virtual bool VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
};

class SimuLinkMiniDelay_FR_AMCMax: public SimuLinkMiniDelay_FR
{
public:
	UnschedCoreComputer_AMCMax m_cUnschedCoreComputer_AMCMax;	
public:
	SimuLinkMiniDelay_FR_AMCMax();
	SimuLinkMiniDelay_FR_AMCMax(TaskSet & rcTaskSet);
	~SimuLinkMiniDelay_FR_AMCMax();	
	virtual bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
private:		
	virtual bool VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment);	
};

class SimuLinkMiniDelay_FR_AMCRtb : public SimuLinkMiniDelay_FR
{
public:
	UnschedCoreComputer_AMCRtb m_cUnschedCoreComputer_AMCRtb;
public:
	SimuLinkMiniDelay_FR_AMCRtb();
	SimuLinkMiniDelay_FR_AMCRtb(TaskSet & rcTaskSet);
	~SimuLinkMiniDelay_FR_AMCRtb();	
	virtual bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
private:		
	virtual bool VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment);	
};

