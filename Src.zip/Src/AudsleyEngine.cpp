#include "stdafx.h"
#include "AudsleyEngine.h"
#include "Util.h"
#include <algorithm>
extern void my_assert(bool bCondition, char axInfo[]);

void SchedTest_AMCMax::Initialize(TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize)
{
	m_cRtCalculator.Initialize(*pcTaskSet);
	for (int i = 0; i < iSize; i++)
	{
		m_cRtCalculator.setPrioirty(i, piPrioirtyTable[i]);
	}
}

bool SchedTest_AMCMax::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	Initialize(pcTaskSet,piPrioirtyTable,iSize);
	return m_cRtCalculator.CalcResponseTimeTask(iTaskIndex,RTCALC_AMCMAX) <= pcTaskSet->getTaskArrayPtr()[iTaskIndex].getDeadline();
}

bool SchedTest_AMCRTB::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	Initialize(pcTaskSet, piPrioirtyTable, iSize);
	//m_cRtCalculator.Calculate(RTCALC_AMCRTB);
	return m_cRtCalculator.CalcResponseTimeTask(iTaskIndex,RTCALC_AMCRTB) <= pcTaskSet->getTaskArrayPtr()[iTaskIndex].getDeadline();
}

bool SchedTest_LO::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	Initialize(pcTaskSet, piPrioirtyTable, iSize);
	//m_cRtCalculator.Calculate(RTCALC_LO);
	return m_cRtCalculator.LOResponseTime(iTaskIndex) <= pcTaskSet->getTaskArrayPtr()[iTaskIndex].getDeadline();
}

void SchedTest_RbfLUB::Initialize(TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	m_cCalculator.Initialize(*pcTaskSet, *(TPCCSet *)pvExtraArg);
	for (int i = 0; i < iSize; i++)
	{
		m_cCalculator.setPriority(i, piPrioirtyTable[i]);
	}
}

bool SchedTest_RbfLUB::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	return m_cCalculator.bIsSchedulableTask(iTaskIndex,UBTYPE_LUB);
}

bool SchedTest_RbfPLUB::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	return m_cCalculator.bIsSchedulableTask(iTaskIndex, UBTYPE_PLUB);
}

SchedTest_AMCSepRbf::SchedTest_AMCSepRbf()
{

}

SchedTest_AMCSepRbf::~SchedTest_AMCSepRbf()
{

}

void SchedTest_AMCSepRbf::Initialize(TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	m_cRbfCalculator.Initialize(*pcTaskSet, *(TPCCSet *)pvExtraArg);
	m_cRTCalculator.Initialize(*pcTaskSet);
	for (int i = 0; i < iSize; i++)
	{
		m_cRbfCalculator.setPriority(i, piPrioirtyTable[i]);
		m_cRTCalculator.setPrioirty(i, piPrioirtyTable[i]);
	}
}

bool SchedTest_AMCSepRbf::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	//For all s < RT_LO, there exist a t s.t. rbf_sep(t,s) <= t
	//gather all the s first. 
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	int iTaskNum = pcTaskSet->getTaskNum();
	Task * pcTaskArray = pcTaskSet->getTaskArrayPtr();
	TPCCSet & rcTPCC = *(TPCCSet *)pvExtraArg;
	double dLOResponseTime = m_cRTCalculator.CalcResponseTimeTask(iTaskIndex, RTCALC_LO);
	if (dLOResponseTime > pcTaskArray[iTaskIndex].getPeriod())
	{
		return false;
	}

	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		return true;
	}

	//Build Criticality Change Set;
	set<double> setCritiChange;
#if 1	
	setCritiChange.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (piPrioirtyTable[i] < piPrioirtyTable[iTaskIndex])
		{
			if (!pcTaskArray[i].getCriticality())
			{
				double dCritiChange = pcTaskArray[i].getPeriod();
				while (dCritiChange < dLOResponseTime)
				{
					setCritiChange.insert(dCritiChange);
					dCritiChange += pcTaskArray[i].getPeriod();
				}
			}
		}
	}
#endif
	//For all s < RT_LO, there exist a t s.t. rbf_sep(t,s) <= t
	//set<double> setSufficientTestSet = pcTaskArray[iTaskIndex].getSufficientTestSet();
	set<double> setSufficientTestSet = rcTPCC.getTestPoints(iTaskIndex);
	for (set<double>::iterator iter = setCritiChange.begin();
		iter != setCritiChange.end(); iter++)
	{
		bool bIsExist = false;
		if (*iter >= dLOResponseTime)
		{
			break;
		}

		for (set<double>::iterator iterPoint = setSufficientTestSet.begin();
			iterPoint != setSufficientTestSet.end(); iterPoint++)
		{
			if (m_cRbfCalculator.AMCSepRbfCalculator_Point(iTaskIndex, *iterPoint, *iter) <= *iterPoint)
			{
				bIsExist = true;
				break;
			}
		}

		if (!bIsExist)
		{
			return false;
		}
	}
	return true;
}

bool SchedTest_AMCSepRbf_Switched::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	//there exist a t s.t. For all s, rbf(t,s) <= t
	//gather all the s first. 
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	int iTaskNum = pcTaskSet->getTaskNum();
	Task * pcTaskArray = pcTaskSet->getTaskArrayPtr();
	TPCCSet & rcTPCCSet = *(TPCCSet *)pvExtraArg;
	double dLOResponseTime = m_cRTCalculator.CalcResponseTimeTask(iTaskIndex, RTCALC_LO);
	if (dLOResponseTime > pcTaskArray[iTaskIndex].getPeriod())
	{
		return false;
	}

	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		return true;
	}

	//Build Criticality Change Set;	
	//set<double> setCritiChange = rcTPCCSet.getCritiChanges(iTaskIndex);
	set<double> setCritiChange;
#if 1	
	setCritiChange.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (piPrioirtyTable[i] < piPrioirtyTable[iTaskIndex])
		{
			if (!pcTaskArray[i].getCriticality())
			{
				double dCritiChange = pcTaskArray[i].getPeriod();
				while (dCritiChange < dLOResponseTime)
				{
					setCritiChange.insert(dCritiChange);
					dCritiChange += pcTaskArray[i].getPeriod();
				}
			}
		}
	}
#endif

	//set<double> setSufficientTestSet = pcTaskArray[iTaskIndex].getSufficientTestSet();
	set<double> setSufficientTestSet = rcTPCCSet.getTestPoints(iTaskIndex);
	//there exist a t s.t. For all s < RT_LO, rbf_sep(t,s) <= t
	for (set<double>::iterator iterPoint = setSufficientTestSet.begin();
		iterPoint != setSufficientTestSet.end(); iterPoint++)
	{
		bool bStatus = true;
		for (set<double>::iterator iter = setCritiChange.begin();
			iter != setCritiChange.end(); iter++)
		{
			if (*iter >= dLOResponseTime)
			{
				break;
			}
			if (m_cRbfCalculator.AMCSepRbfCalculator_Point(iTaskIndex, *iterPoint, *iter) - *iterPoint > 0)
			{				
				bStatus = false;
				break;
			}
		}
		if (bStatus)
		{
			return true;
		}
	}


	return false;
}

bool SchedTest_MILPRbf::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	//gather all the s first. 
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	int iTaskNum = pcTaskSet->getTaskNum();
	Task * pcTaskArray = pcTaskSet->getTaskArrayPtr();
	TPCCSet & rcTPCCSet = *(TPCCSet *)pvExtraArg;
	double dLOResponseTime = m_cRTCalculator.CalcResponseTimeTask(iTaskIndex, RTCALC_LO);
	if (dLOResponseTime > pcTaskArray[iTaskIndex].getDeadline())//Is it really needed ?
	{
		return false;
	}

	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		return true;
	}
	set<double> setSufficientTestSet = rcTPCCSet.getTestPoints(iTaskIndex);
	
#if 1
	set<double> setCritiChange = rcTPCCSet.getCritiChanges(iTaskIndex);
#else
	set<double> setCritiChange = rcTPCCSet.getCritiChanges(iTaskIndex);
	setCritiChange.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (piPrioirtyTable[i] < piPrioirtyTable[iTaskIndex])
		{
			if (!pcTaskArray[i].getCriticality())
			{
				double dCritiChange = pcTaskArray[i].getPeriod();
				while (dCritiChange < dLOResponseTime)
				{
					setCritiChange.insert(dCritiChange);
					dCritiChange += pcTaskArray[i].getPeriod();
				}
			}
		}
	}
#endif
	//there exist a t s.t. For all s < t, rbf_sep(t,s) <= t
	for (set<double>::iterator iterPoint = setSufficientTestSet.begin();
		iterPoint != setSufficientTestSet.end(); iterPoint++)
	{
		bool bStatus = true;
		for (set<double>::iterator iter = setCritiChange.begin();
			iter != setCritiChange.end(); iter++)
		{
			if (*iter >= *iterPoint)
				continue;			
			double dRbf = m_cRbfCalculator.AMCSepRbfCalculator_Point(iTaskIndex, *iterPoint, *iter);
			if (dRbf - *iterPoint > 0)
			{
				bStatus = false;
				break;
			}
		}
		if (bStatus)
		{
			return true;
		}
	}
	return false;
}

bool SchedTest_MILPRbf_RTLOBound::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	//gather all the s first. 
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	int iTaskNum = pcTaskSet->getTaskNum();
	Task * pcTaskArray = pcTaskSet->getTaskArrayPtr();
	TPCCSet & rcTPCCSet = *(TPCCSet *)pvExtraArg;
	double dLOResponseTime = m_cRTCalculator.CalcResponseTimeTask(iTaskIndex, RTCALC_LO);
	if (dLOResponseTime > pcTaskArray[iTaskIndex].getDeadline())//Is it really needed ?
	{
		return false;
	}

	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		return true;
	}
	set<double> setSufficientTestSet = rcTPCCSet.getTestPoints(iTaskIndex);

#if 0
	set<double> setCritiChange = rcTPCCSet.getCritiChanges(iTaskIndex);
#else
	set<double> setCritiChange = rcTPCCSet.getCritiChanges(iTaskIndex);
	setCritiChange.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (piPrioirtyTable[i] < piPrioirtyTable[iTaskIndex])
		{
			if (!pcTaskArray[i].getCriticality())
			{
				double dCritiChange = pcTaskArray[i].getPeriod();
				while (dCritiChange < dLOResponseTime)
				{
					setCritiChange.insert(dCritiChange);
					dCritiChange += pcTaskArray[i].getPeriod();
				}
			}
		}
	}
#endif

	//there exist a t s.t. For all s < min(t, RT_LO), rbf(t,s) <= t
	for (set<double>::iterator iterPoint = setSufficientTestSet.begin();
		iterPoint != setSufficientTestSet.end(); iterPoint++)
	{
		bool bStatus = true;
		for (set<double>::iterator iter = setCritiChange.begin();
			iter != setCritiChange.end(); iter++)
		{
			if (*iter >= *iterPoint)
				continue;

			if (*iter < dLOResponseTime)
			{
				double dRbf = m_cRbfCalculator.AMCSepRbfCalculator_Point(iTaskIndex, *iterPoint, *iter);
				if (dRbf - *iterPoint > 0)
				{
					bStatus = false;
					break;
				}
			}
			
		}

		if (bStatus)
		{
			return true;
		}
	}
	return false;
}

bool SchedTest_MILPRbf_WCBound::operator()(int iTaskIndex, TaskSet * pcTaskSet, int * piPrioirtyTable, int iSize, void * pvExtraArg)
{
	//For all s < RT_LO, there exist a t s.t. rbf_AMCMx(t,s) + WCBound(t) <= t
	//gather all the s first. 
	Initialize(pcTaskSet, piPrioirtyTable, iSize, pvExtraArg);
	int iTaskNum = pcTaskSet->getTaskNum();
	Task * pcTaskArray = pcTaskSet->getTaskArrayPtr();
	TPCCSet & rcTPCC = *(TPCCSet *)pvExtraArg;
	double dLOResponseTime = m_cRTCalculator.CalcResponseTimeTask(iTaskIndex, RTCALC_LO);
	if (dLOResponseTime > pcTaskArray[iTaskIndex].getDeadline())
	{
		return false;
	}

	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		return true;
	}

	//Build Criticality Change Set;
	set<double> setCritiChange;
#if 1	
	setCritiChange.insert(0);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (piPrioirtyTable[i] < piPrioirtyTable[iTaskIndex])
		{
			if (!pcTaskArray[i].getCriticality())
			{
				double dCritiChange = pcTaskArray[i].getPeriod();
				while (dCritiChange < dLOResponseTime)
				{
					setCritiChange.insert(dCritiChange);
					dCritiChange += pcTaskArray[i].getPeriod();
				}
			}
		}
	}
#endif
	//For all s < RT_LO, there exist a t s.t. rbf_AMCMax(t,s) + WCBound(t) <= t
	//set<double> setSufficientTestSet = pcTaskArray[iTaskIndex].getSufficientTestSet();
	set<double> setSufficientTestSet = rcTPCC.getTestPoints(iTaskIndex);
	for (set<double>::iterator iter = setCritiChange.begin();
		iter != setCritiChange.end(); iter++)
	{
		bool bIsExist = false;
		if (*iter >= dLOResponseTime)
		{
			break;
		}

		for (set<double>::iterator iterPoint = setSufficientTestSet.begin();
			iterPoint != setSufficientTestSet.end(); iterPoint++)
		{
			double dRbf = m_cRbfCalculator.AMCMaxRbfCalculator_Point(iTaskIndex, *iterPoint, *iter);
			double dWCBound = WorstCaseBound(iTaskIndex, pcTaskSet, piPrioirtyTable, *iterPoint, dLOResponseTime);
			if (dRbf + dWCBound <= *iterPoint)
			{
				bIsExist = true;
				break;
			}
		}

		if (!bIsExist)
		{
			return false;
		}
	}
	return true;
}

double SchedTest_MILPRbf_WCBound::WorstCaseBound(int iTaskIndex, TaskSet * pcTaskSet, int * piPriorityTable, double dTotalTime, double dLOResponseTime)
{	

	if (dTotalTime < dLOResponseTime)
		return 0;

	int iTaskNum = pcTaskSet->getTaskNum();
	Task * pcTaskArray = pcTaskSet->getTaskArrayPtr();
	Task & rcTask = pcTaskArray[iTaskIndex];
	double dUtilDiff = 0;
	double dConstantA = 0;
	double dConstantB = 0;
	double dConstantC = 0;
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
			continue;
		
		if (piPriorityTable[i] < piPriorityTable[iTaskIndex])
		{			
			

			if (pcTaskArray[i].getCriticality())
			{				
				dUtilDiff -= pcTaskArray[i].getCHI() / pcTaskArray[i].getPeriod();
				dConstantB += pcTaskArray[i].getCHI() + pcTaskArray[i].getCLO();
				dConstantC += (pcTaskArray[i].getDeadline() / pcTaskArray[i].getPeriod() + 1) * pcTaskArray[i].getCHI() - pcTaskArray[i].getCLO();
			}
			else
			{
				dUtilDiff += pcTaskArray[i].getCLO() / pcTaskArray[i].getPeriod();	
				dConstantB += pcTaskArray[i].getCLO();
			}
		}
	}
	dConstantA = (dUtilDiff <= 0) ? dLOResponseTime : (dTotalTime - dLOResponseTime);
	double dWCBound = MY_MAX(0, dConstantA * dUtilDiff + dConstantB) + dConstantC;
	return dWCBound;

}