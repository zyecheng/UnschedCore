#include "stdafx.h"
#include <fstream>
#include "MainFunction.h"
#include "Util.h"
#include "TaskSet.h"
#include "RunTimeTester.h"
#include "StatisticSet.h"
#include <direct.h>
#include <string>
#include <set>
#include "Timer.h"
#include "SimuLinkMiniDelay.h"
#include "RTSchedPTree.h"
#include "MinimizeMemory_PFR.h"
#include "FSMCaseStudy.h"

typedef int(*MainFunc)(int, char *[]);
#define BUFFERLEN 1024
#define TPCCREDTHRESHOLD 20

struct FunctionEntry
{
	char axFuncName[BUFFERLEN];
	MainFunc pfuncFunction;
};

FunctionEntry ptagAllFunction[] = {	
	{ "SimulinkFR", SimulinkFR },
	{ "DummyTemp", DummyTemp },		
	{ "MinimizeAUTOSTARMemory_FR", MinimizeAUTOSTARMemory_FR },
	{ "SimulinkFSMBnB", SimulinkFSMBnB},
	{"SimulinkMILP", SimulinkMILP}
	
}; 

int iFunctionNum = sizeof(ptagAllFunction) / sizeof(FunctionEntry);

extern void my_assert(bool bCondition, char axInfo[]);

int ExtractArgument(int argc, char * argv[], ArgName2Arg & rmapName2Arg)
{
	char axBuffer[256] = { 0 };
	int iDefaultIndex = 0;
	for (int i = 0; i < argc; i++)
	{
		string stringCommmand = string(argv[i]);
		if (argv[i][0] == '-')
		{
			//name specified
			int iEqualityIndex = stringCommmand.find('=', 1);
			if (iEqualityIndex == -1)
			{
				cout << "I don't recognize this: " << stringCommmand.data() << endl;
				my_assert(0, "");
			}
			string stringArgName = stringCommmand.substr(1, iEqualityIndex - 2 + 1);
			string stringArg = stringCommmand.substr(iEqualityIndex + 1, stringCommmand.size() - iEqualityIndex - 1 + 1);
			rmapName2Arg[stringArgName] = stringArg;
		}
		else
		{
			sprintf_s(axBuffer, "arg%d", iDefaultIndex);
			iDefaultIndex++;
			string stringArgName(axBuffer);
			rmapName2Arg[stringArgName] = stringCommmand;
		}
	}	

	for (ArgName2Arg::iterator iter = rmapName2Arg.begin(); iter != rmapName2Arg.end(); iter++)
	{
	//	cout << iter->first << " " << iter->second << endl;		
	}
	return 0;
}

int DispatchFunction(int argc, char * argv[])
{
	if (argc < 2)
	{
		return 0;
	}

	for (int i = 0; i < iFunctionNum; i++)
	{
		if (strcmp(argv[1], ptagAllFunction[i].axFuncName) == 0)
		{
			return ptagAllFunction[i].pfuncFunction(argc, argv);			
		}
	}
	my_assert(false, "Unknown Function Option");
	return 0;
}

int SimulinkFR(int argc, char * argv[])
{
	//Usage: Exec SimulinkFR type .tskst Weighted CoresPerIter Timeout Display -strategy=Lazy/Eager
	/*
	Optional Argument:
	-LoadUC=[UnschedCoreFile]
	-ILPTimeout=[timeout]
	-ILPOptGap=[Optimality Gap Tol]
	-TermOnFeas=[1/0]
	-LowerBound=[value]
	-FSMFile=[File]
	-LogFileSuffix=[Suffix]
	-ResultFileSuffix=[Suffix]
	-UnschedCoreFileSuffix[Suffix]
	*/
	//type: LO, AMCMax
	ArgName2Arg mapName2Arg;
	ExtractArgument(argc, argv, mapName2Arg);
	if (argc < 8)
	{
		my_assert(0, "Illegal Numbers of Argument");
	}
	int iCorePerIter = atoi(argv[5]);
	double dTimeout = atof(argv[6]);
	int iDisplay = atoi(argv[7]);
	char axBuffer[256] = { 0 };

	FSMTaskSet cTaskSet;
	cTaskSet.ReadImageFile(argv[3]);

	if (strcmp(argv[4], "unweighted") == 0)
	{
		cTaskSet.RemoveLinkWeight();
	}
	else if (strcmp(argv[4], "weighted") == 0)
	{

	}
	else
	{
		my_assert(0, "weighted or unweighted?");
	}

	SimuLinkMiniDelay_FR::enumAlgConfig enumStrategy = SimuLinkMiniDelay_FR::enumAlgConfig::Lazy;
	if (mapName2Arg.count("strategy"))
	{
		if (mapName2Arg["strategy"].compare("Eager") == 0)
		{
			enumStrategy = SimuLinkMiniDelay_FR::enumAlgConfig::Eager;
		}
	}

	if (strcmp(argv[2], "AMCMax") == 0)
	{
		SimuLinkMiniDelay_FR_AMCMax cModel(cTaskSet);

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCMax_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCMax_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCMax_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "LO") == 0)
	{
		SimuLinkMiniDelay_FR cModel(cTaskSet);

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_LO_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_LO_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_LO_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "AMCRtb") == 0)
	{
		SimuLinkMiniDelay_FR_AMCRtb cModel(cTaskSet);

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCRtb_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCRtb_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCRtb_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "FSMPeriodicTaskApprox") == 0)
	{
		int iFSMDataBuildTime = 0;
		double dCPUTime = 0;
		Timer cTimer;

		if (mapName2Arg.count("FSMFile"))
		{
			if (iDisplay)
				cout << "Analyzing FSM....";
			iFSMDataBuildTime = clock();
			cTimer.Start();
			cTaskSet.ReadRawStateflow((char *)mapName2Arg["FSMFile"].data());
			cTimer.Stop();
			iFSMDataBuildTime = clock() - iFSMDataBuildTime;
			iFSMDataBuildTime = cTimer.getElapsedTime_ms();
			if (iDisplay)	cout << "Done " << iFSMDataBuildTime << endl;
		}
		else
		{
			cout << "Must provided the FSM implementation file" << endl;
			while (1);
		}

		SimuLinkMiniDelay_FR_FSM_SingleTaskImple cModel(cTaskSet);
		//cModel.m_cUnschedCoreComputer_FSM_SingleTaskImple.m_cImpleTaskSet.WriteTextFile("Temp.tskst.txt");

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_%s_Log.txt", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMPeriodicTaskApprox_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("ILPOptGap"))	cModel.setSubILPOptGap(atof(mapName2Arg["ILPOptGap"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		//cModel.m_cUnschedCoreComputer_FSM_RBFSO.setSchedTestOption(UnschedCoreComputer::SchedulabilityTestOption::LookUpTable);
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMPeriodicTaskApprox_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);
		//cModel.m_cUnschedCoreComputer_FSM_RBFSO.PrintStatistic((string(axBuffer) + string("_CoreStat.txt")).data());
		StatisticSet cStat;
		cStat.ReadStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.setItem("FSM Pre-analysis Time", (double)iFSMDataBuildTime / (double)CLOCKS_PER_SEC);
		cStat.WriteStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.WriteStatisticText((char *)(string(axBuffer) + string(".txt")).data());

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_UnschedCore.uc", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMPeriodicTaskApprox_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "FSMPeriodicTaskApproxILP") == 0)
	{
		int iFSMDataBuildTime = 0;
		double dCPUTime = 0;
		Timer cTimer;

		if (mapName2Arg.count("FSMFile"))
		{
			if (iDisplay)
				cout << "Analyzing FSM....";
			iFSMDataBuildTime = clock();
			cTimer.Start();
			cTaskSet.ReadStateflow((char *)mapName2Arg["FSMFile"].data());
			cTimer.Stop();
			iFSMDataBuildTime = clock() - iFSMDataBuildTime;
			iFSMDataBuildTime = cTimer.getElapsedTime_ms();
			if (iDisplay)	cout << "Done " << iFSMDataBuildTime << endl;
		}
		else
		{
			cout << "Must provided the FSM implementation file" << endl;
			while (1);
		}

		TPCCSet cTPCC;
		if (mapName2Arg.count("TPCCFile"))
		{
			cTPCC.ReadTPCCImage((char *)mapName2Arg["TPCCFile"].data());
		}
		else
		{
			cout << "Must Provide the TPCC File" << endl;
			while (1);
		}

		double dTimeout = 1e74;
		if (mapName2Arg.count("Timeout"))
		{
			dTimeout = atof(mapName2Arg["Timeout"].data());
		}

		int iDisplay = 0;
		if (mapName2Arg.count("Display"))
		{
			iDisplay = atoi(mapName2Arg["Display"].data());
		}

		UnschedCoreComputer_FSM_SingleTaskImple cUCComp(cTaskSet);
		TaskSet & rcPeriodicApproxTaskSet = cUCComp.m_cImpleTaskSet;

		SimuLinkMiniDelay cModel(rcPeriodicApproxTaskSet, cTPCC);
		int iStatus = cModel.Solve(MODELTYPE_LO, iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMPeriodicTaskApproxILP_Result", argv[3]);
		}
		string stirngResultFile(axBuffer);
		StatisticSet cStat;
		cStat.ReadStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.setItem("FSM Pre-analysis Time", (double)iFSMDataBuildTime / (double)CLOCKS_PER_SEC);

		double dDelay = rcPeriodicApproxTaskSet.getWorstDelay();
		if (iStatus == 1)
		{
			cStat.setItem("Status", "Optimal");
			dDelay = cModel.getObjective();
		}
		else if (iStatus == 0)
		{
			cStat.setItem("Status", "Infeasible");
		}
		else if (iStatus == -1)
		{
			cStat.setItem("Status", "Timeout");
		}

		cStat.setItem("Delay", dDelay);
		cStat.setItem("Worst Delay", rcPeriodicApproxTaskSet.getWorstDelay());
		cStat.setItem("Wall Time", cModel.getWallTime());
		cStat.setItem("CPU Time", cModel.getCPUTime());
		cStat.WriteStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.WriteStatisticText((char *)(string(axBuffer) + string(".txt")).data());

	}
	else if (strcmp(argv[2], "FSMRBFSO") == 0)
	{
		int iFSMDataBuildTime = 0;
		double dCPUTime = 0;
		Timer cTimer;

		if (mapName2Arg.count("FSMFile"))
		{
			if (iDisplay)
				cout << "Analyzing FSM....";
			iFSMDataBuildTime = clock();
			cTimer.Start();
			cTaskSet.ReadStateflow((char *)mapName2Arg["FSMFile"].data());
			cTimer.Stop();
			iFSMDataBuildTime = clock() - iFSMDataBuildTime;
			iFSMDataBuildTime = cTimer.getElapsedTime_ms();
			if (iDisplay)	cout << "Done " << iFSMDataBuildTime << endl;
		}
		else
		{
			cout << "Must provided the FSM implementation file" << endl;
			while (1);
		}

		SimuLinkMiniDelay_FR_FSM_RBFSO cModel(cTaskSet);

		if (mapName2Arg.count("SchedTestOption"))
		{
			cModel.SchedTestOption(mapName2Arg["SchedTestOption"].data());
		}

		if (mapName2Arg.count("UnschedCoreCompOption"))
		{
			cModel.UnschedCoreCompOption(mapName2Arg["UnschedCoreCompOption"].data());
		}

		if (mapName2Arg.count("InstanceApproximation"))
		{
			int iInstanceOption = atoi(mapName2Arg["InstanceApproximation"].data());
			cModel.InstanceApproximationOption(iInstanceOption);
		}

		if (mapName2Arg.count("BusyStartApproximation"))
		{
			int iOption = atoi(mapName2Arg["BusyStartApproximation"].data());
			cModel.BusyStartApproximation(iOption);
		}


		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_%s_Log.txt", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMRBFSO_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("ILPOptGap"))	cModel.setSubILPOptGap(atof(mapName2Arg["ILPOptGap"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		//cModel.m_cUnschedCoreComputer_FSM_RBFSO.setSchedTestOption(UnschedCoreComputer::SchedulabilityTestOption::LookUpTable);
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMRBFSO_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);
		//cModel.m_cUnschedCoreComputer_FSM_RBFSO.PrintStatistic((string(axBuffer) + string("_CoreStat.txt")).data());
		StatisticSet cStat;
		cStat.ReadStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.setItem("FSM Pre-analysis Time", (double)iFSMDataBuildTime / (double)CLOCKS_PER_SEC);
		cStat.WriteStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.WriteStatisticText((char *)(string(axBuffer) + string(".txt")).data());

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_UnschedCore.uc", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMRBFSO_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);
		cModel.PrintCoreTimeDistributionToLog(cModel.m_cUnschedCoreComputer_FSM_RBFSO);
	}
	else
	{
		cout << "Unknown system type" << endl;
		my_assert(0, "");
	}

	return 0;

}

#if 0
int SimulinkFR(int argc, char * argv[])
{
	//Usage: Exec SimulinkFR type .tskst Weighted CoresPerIter Timeout Display -strategy=Lazy/Eager
	/*
	Optional Argument:
	-LoadUC=[UnschedCoreFile]
	-ILPTimeout=[timeout]
	-ILPOptGap=[Optimality Gap Tol]
	-TermOnFeas=[1/0]
	-LowerBound=[value]
	-FSMFile=[File]
	-LogFileSuffix=[Suffix]
	-ResultFileSuffix=[Suffix]
	-UnschedCoreFileSuffix[Suffix]
	*/
	//type: LO, AMCMax
	ArgName2Arg mapName2Arg;
	ExtractArgument(argc, argv, mapName2Arg);
	if (argc < 8)
	{
		my_assert(0, "Illegal Numbers of Argument");
	}
	int iCorePerIter = atoi(argv[5]);
	double dTimeout = atof(argv[6]);
	int iDisplay = atoi(argv[7]);
	char axBuffer[256] = { 0 };

	FSMTaskSet cTaskSet;
	cTaskSet.ReadImageFile(argv[3]);

	if (strcmp(argv[4], "unweighted") == 0)
	{
		cTaskSet.RemoveLinkWeight();
	}
	else if (strcmp(argv[4], "weighted") == 0)
	{

	}
	else
	{
		my_assert(0, "weighted or unweighted?");
	}

	SimuLinkMiniDelay_FR::enumAlgConfig enumStrategy = SimuLinkMiniDelay_FR::enumAlgConfig::Lazy;
	if (mapName2Arg.count("strategy"))
	{
		if (mapName2Arg["strategy"].compare("Eager") == 0)
		{			
			enumStrategy = SimuLinkMiniDelay_FR::enumAlgConfig::Eager;
		}
	}
	
	if (strcmp(argv[2], "AMCMax") == 0)
	{
		SimuLinkMiniDelay_FR_AMCMax cModel(cTaskSet);

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCMax_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCMax_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCMax_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "LO") == 0)
	{
		SimuLinkMiniDelay_FR cModel(cTaskSet);
		sprintf_s(axBuffer, "%s_FR_LO_Log.txt", argv[3]);
		cModel.setLogFile(axBuffer);
		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));		
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);
		sprintf_s(axBuffer, "%s_FR_LO_Result", argv[3]);
		cModel.GenerateStatisticFile(axBuffer);
		sprintf_s(axBuffer, "%s_FR_LO_UnschedCore.uc", argv[3]);
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "AMCRtb") == 0)
	{
		SimuLinkMiniDelay_FR_AMCRtb cModel(cTaskSet);

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCRtb_Log.txt", argv[3]);
		}		
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));		
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);

		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCRtb_Result", argv[3]);
		}		
		cModel.GenerateStatisticFile(axBuffer);

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_AMCRtb_UnschedCore.uc", argv[3]);
		}		
		cModel.WriteUnschedCoreToFile(axBuffer);
	}
	else if (strcmp(argv[2], "FSMRBFSO") == 0)
	{	

		int iFSMDataBuildTime = 0;
		double dCPUTime = 0;
		Timer cTimer;
		if (mapName2Arg.count("FSMFile"))
		{
			if (iDisplay)
				cout << "Analyzing FSM....";
			iFSMDataBuildTime = clock();
			cTimer.Start();
			cTaskSet.ReadStateflow((char *)mapName2Arg["FSMFile"].data());
			cTimer.Stop();
			iFSMDataBuildTime = clock() - iFSMDataBuildTime;
			iFSMDataBuildTime = cTimer.getElapsedTime_ms();
			if (iDisplay)	cout << "Done " << iFSMDataBuildTime << endl;
		}
		else
		{
			cout << "Must provided the FSM implementation file" << endl;
			while (1);
		}
		SimuLinkMiniDelay_FR_FSM_RBFSO cModel(cTaskSet);

		if (mapName2Arg.count("LookUpTableSchedTest") == 0)
		{			
			int iOpt = atoi(mapName2Arg["LookUpTableSchedTest"].data());
			cModel.UseBitMaskLookUpTable(iOpt);
		}

		if (mapName2Arg.count("LogFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_%s_Log.txt", argv[3], mapName2Arg["LogFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_%s_Log.txt", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMRBFSO_Log.txt", argv[3]);
		}
		cModel.setLogFile(axBuffer);

		cModel.setAlgorithm(enumStrategy);
		cModel.setCorePerIter(iCorePerIter);
		if (mapName2Arg.count("LoadUC"))	cModel.ReadUnschedCoreFromFile((char *)mapName2Arg["LoadUC"].data());
		if (mapName2Arg.count("ILPTimeout"))	cModel.setILPTimeout(atof(mapName2Arg["ILPTimeout"].data()));
		if (mapName2Arg.count("ILPDisplay"))	cModel.setSubILPDisplay(atoi(mapName2Arg["ILPDisplay"].data()));
		if (mapName2Arg.count("ILPOptGap"))	cModel.setSubILPOptGap(atof(mapName2Arg["ILPOptGap"].data()));
		if (mapName2Arg.count("LowerBound"))	cModel.setLB(atof(mapName2Arg["LowerBound"].data()));
		cModel.FocusRefinementFast(iDisplay, dTimeout);
		
		if (mapName2Arg.count("ResultFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["ResultFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_Result", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMRBFSO_Result", argv[3]);
		}
		cModel.GenerateStatisticFile(axBuffer);		
		StatisticSet cStat;
		cStat.ReadStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.setItem("FSM Pre-analysis Time", (double)iFSMDataBuildTime / (double)CLOCKS_PER_SEC);
		cStat.WriteStatisticImage((char *)(string(axBuffer) + string(".rslt")).data());
		cStat.WriteStatisticText((char *)(string(axBuffer) + string(".txt")).data());

		if (mapName2Arg.count("UnschedCoreFileSuffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_UnschedCore.uc", argv[3], mapName2Arg["UnschedCoreFileSuffix"].data());
		}
		else if (mapName2Arg.count("Suffix"))
		{
			sprintf_s(axBuffer, "%s_FR_%s_UnschedCore.uc", argv[3], mapName2Arg["Suffix"].data());
		}
		else
		{
			sprintf_s(axBuffer, "%s_FR_FSMRBFSO_UnschedCore.uc", argv[3]);
		}
		cModel.WriteUnschedCoreToFile(axBuffer);		
	}
	else
	{
		cout << "Unknown system type" << endl;
		my_assert(0, "");
	}

	return 0;

}

#endif

int MinimizeAUTOSTARMemory_FR(int argc, char * argv[])
{
	ArgName2Arg mapName2Arg;
	ExtractArgument(argc, argv, mapName2Arg);

	//Usage: Exec MinimizeAUTOSTARMemory_ILPRBF
	/*
	-TaskSet=.tskst
	-Timeout=[seconds]
	-Display=[Level]
	*/

	TaskSetExt_LinkCritialSection cTaskSet;
	if (mapName2Arg.count("TaskSet") == 0)
	{
		cout << "Must provide a taskset file ! " << endl;
		while (1);
	}
	cTaskSet.ReadImageFile((char *)mapName2Arg["TaskSet"].data());

	int iDisplay = 0;
	if (mapName2Arg.count("Display") == 1)
	{
		iDisplay = atoi(mapName2Arg["Display"].data());
	}

	double dTimeout = 1e74;
	if (mapName2Arg.count("Timeout") == 1)
	{
		dTimeout = atof(mapName2Arg["Timeout"].data());
	}

	char axBuffer[512] = { 0 };
	MinimizeMemory_PFR cModel(cTaskSet);
	sprintf_s(axBuffer, "%s_AUTOSTARMinMem_FR_Log.txt", mapName2Arg["TaskSet"].data());
	cModel.setLogFile(axBuffer);
	cModel.setCorePerIter(5);
	cModel.FocusRefinementFast(iDisplay, dTimeout);
		
	sprintf_s(axBuffer, "%s_AUTOSTARMinMem_FR_Result", mapName2Arg["TaskSet"].data());
	cModel.GenerateStatisticFile(axBuffer);	

	return 0;
}


extern void Perofrmance_WRK_K_LabServerLinux();
int DummyTemp(int argc, char * argv[])
{
	ArgName2Arg mapName2Arg;
	ExtractArgument(argc, argv, mapName2Arg);	
	Perofrmance_WRK_K_LabServerLinux(); return 0;
#if 0
	//UnschedCoreOptExampleDemo(); return 0;
	//UnschedCoreSmallExampleDemo(); return 0;
	//TestMCMCMapDCDU(); return 0;
	TestSimuLinkFR(); return 0;
	//cout.rdbuf(pccoutBuf);
	//ofstreamFile.close();
	//MCMCMapTest::RunTest(argc, argv);
	TestMCMCMapFR(argc, argv);
#endif

//	TestFocusRefinementAMCRtbUSweep("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/USweep");
//      TestFocusRefinementAMCMaxUSweep("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/USweep");
//	TestFocusRefinementAMCRtbKSweep("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/KSweep/U0.70_N70");
//	TestFocusRefinementAMCMaxKSweep("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/KSweep/U0.70_N70");
#if 1
	int iThreadNum = 0;
	if(mapName2Arg.count("ThreadNum") == 1)
	{
		iThreadNum = atoi(mapName2Arg["ThreadNum"].data());
	}
	TestBnbFSMRBFSONSweep_MT(
                "/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/FSMExperiment/FSMNSweep",
                "/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/FSMExperiment/FSMNSweep",
		iThreadNum, 1, 1);
	return 0;
#endif

#if 0
	TestFocusRefinementFSMRBFSOUSweep(
		"/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/FSMExperiment/FSMUSweep", 
		"/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/FSMExperiment/FSMUSweep");
#endif

#if 1
        TestFocusRefinementFSMRBFSONoBitMaskUSweep(
                "/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/FSMExperiment/FSMUSweep",
                "/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/FSMExperiment/FSMUSweep");
#endif

	//TestFocusRefinementAMCRtbNKSweep("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/AMCNSweep");
//	TestFocusRefinementAMCMaxUKSweep("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/USweep");
//	TestMinimizeMemoryFR("/home/zyecheng/VirginiaTech/Research/UnschedCore/MCMILPPact/ExpSpace/AUTOSTARMinMemNSweep");
	return 0;
}


int SimulinkFSMBnB(int argc, char * argv[])
{
	ArgName2Arg mapName2Arg;
	ExtractArgument(argc, argv, mapName2Arg);
	FSMTaskSet cTaskSet;
	assert(mapName2Arg.count("TaskSetFile"));
	cTaskSet.ReadImageFile((char *)mapName2Arg["TaskSetFile"].data());
	assert(mapName2Arg.count("FSMFile"));
	cTaskSet.ReadStateflow((char *)mapName2Arg["FSMFile"].data());

	SimulinkMiniDelayBnB_FSMRBFSO cModel(cTaskSet);
	int iLookUpTable = 0;
	if (mapName2Arg.count("UseLookUpTable"))
	{
		iLookUpTable = atoi(mapName2Arg["UseLookUpTable"].data());		
	}
	if (iLookUpTable)
	{
		cModel.m_cUnschedCore.setSchedTestOption(UnschedCoreComputer::SchedTest_LookUpTable);
	}
	else
	{
		iLookUpTable = 0;
		cModel.m_cUnschedCore.setSchedTestOption(UnschedCoreComputer::SchedTest_Original);
	}

	int iDisplay = 0;
	if (mapName2Arg.count("Display"))
	{
		iDisplay = atoi(mapName2Arg["Display"].data());
	}

	double dTimeout = 1e74;
	if (mapName2Arg.count("Timeout"))
	{
		dTimeout = atof(mapName2Arg["Timeout"].data());
	}
	Timer cTimer;
	cTimer.Start();
	cModel.Run(iDisplay, dTimeout);
	cTimer.Stop();
	string stringResultFile(mapName2Arg["TaskSetFile"]);
	char axBuffer[512] = { 0 };
	sprintf_s(axBuffer, "%s_BnB_FSMRBFSO_LookUpTable_%d", mapName2Arg["TaskSetFile"].data(), iLookUpTable);
	cModel.WriteStatisticFile(axBuffer);
	return 0;
}

int SimulinkMILP(int argc, char * argv[])
{
	//Usage: Exec SimulinkMILP type .tskst 
	/*
	Optional Argument:
	-display=[level]
	-unschedcore=[unsched core file]
	-tpcc=[tpcc file]
	-memory=[memory ratio]
	*/
	//type: LO, AMCMax
	ArgName2Arg mapName2Arg;
	ExtractArgument(argc, argv, mapName2Arg);
	if (argc < 4)
	{
		my_assert(0, "Illegal Numbers of Argument");
	}

	TaskSet cTaskSet;
	cTaskSet.ReadImageFile(argv[3]);

	TPCCSet cTPCCSet;
	if (mapName2Arg.count("tpcc"))
	{
		cTPCCSet.ReadTPCCImage((char *)mapName2Arg["tpcc"].data());
	}
	else
	{
		cTPCCSet.Initialize(cTaskSet);
		cTPCCSet.GenRawTPCC();
	}

	if (mapName2Arg.count("memory"))
	{
		double dMemoryRatio = atof(mapName2Arg["memory"].data());
		cout << "Available memory change from " << cTaskSet.getAvailableMemory() << " to " << dMemoryRatio * cTaskSet.getAvailableMemory() << endl;
		cTaskSet.setAvailableMemory(cTaskSet.getAvailableMemory() * dMemoryRatio);
	}

	double dTimeout = 1e74;
	if (mapName2Arg.count("Timeout"))
	{
		dTimeout = atof(mapName2Arg["Timeout"].data());
	}

	int iDisplay = 0;
	if (mapName2Arg.count("display"))
		iDisplay = atoi(mapName2Arg["display"].data());
	if (strcmp(argv[2], "LO") == 0)
	{
		StatisticSet cStat;
		SimuLinkMiniDelay cModel(cTaskSet, cTPCCSet);
		if (mapName2Arg.count("unschedcore"))
			UnschedCoreComputer().ReadUnschedCoreFromFile((char *)mapName2Arg["unschedcore"].data(), cModel.getUnschedCores());
		if (iDisplay)	cout << "About to Solve" << endl;
		int iStatus = cModel.Solve(MODELTYPE_LO, iDisplay, dTimeout);
		if (iStatus == 1)
		{
			cStat.setItem("Feasibility", "Feasible");
			cStat.setItem("Best Delay", cModel.getObjective());
		}
		else if (iStatus == 0)
		{
			cStat.setItem("Feasibility", "Infeasible");
			cStat.setItem("Best Delay", cTaskSet.getWorstDelay());
		}

		cStat.setItem("Worst Delay", cTaskSet.getWorstDelay());
		cStat.setItem("Time Elapsed", cModel.getWallTime());
		cStat.setItem("CPU Time", cModel.getCPUTime());
		string stringName(argv[3]);
		stringName += "_LO.rslt";
		cStat.WriteStatisticImage((char *)stringName.data());
		stringName.append(".txt");
		cStat.WriteStatisticText((char *)stringName.data());
	}
	else if (strcmp(argv[2], "NoMemLnkTypeLO") == 0)
	{
		StatisticSet cStat;
		SimulinkMiniDelay_NoMemLH cModel(cTaskSet, cTPCCSet);
		if (mapName2Arg.count("unschedcore"))
			UnschedCoreComputer().ReadUnschedCoreFromFile((char *)mapName2Arg["unschedcore"].data(), cModel.getUnschedCores());
		if (iDisplay)	cout << "About to Solve" << endl;
		int iStatus = cModel.Solve(MODELTYPE_LO, iDisplay, dTimeout);
		if (iStatus == 1)
		{
			cStat.setItem("Feasibility", "Feasible");
			cStat.setItem("Best Delay", cModel.getObjective());
		}
		else if (iStatus == 0)
		{
			cStat.setItem("Feasibility", "Infeasible");
			cStat.setItem("Best Delay", cTaskSet.getSumDelayCost());
		}
		else
		{
			cStat.setItem("Feasibility", "Feasible");
			cStat.setItem("Best Delay", cModel.getObjective());
		}

		cStat.setItem("Worst Delay", cTaskSet.getSumDelayCost());
		cStat.setItem("Sum Delay", cTaskSet.getSumDelayCost());
		cStat.setItem("Time Elapsed", cModel.getWallTime());
		cStat.setItem("CPU Time", cModel.getCPUTime());
		string stringName(argv[3]);
		stringName += "_LO.rslt";
		cStat.WriteStatisticImage((char *)stringName.data());
		stringName.append(".txt");
		cStat.WriteStatisticText((char *)stringName.data());

	}
	else
	{

		my_assert(false, "Unknown Method");
	}
	return 0;
}
