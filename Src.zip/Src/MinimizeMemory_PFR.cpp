#include "stdafx.h"
#include "MinimizeMemory_PFR.h"
#include "ResponseTimeCalculator.h"
#include "Util.h"

UnschedCoreComputer_MiniMem::UnschedCoreComputer_MiniMem()
{

}

UnschedCoreComputer_MiniMem::UnschedCoreComputer_MiniMem(TaskSet & rcTaskSet)
	:UnschedCoreComputer(rcTaskSet)
{	
}

UnschedCoreComputer_MiniMem::~UnschedCoreComputer_MiniMem()
{

}

void UnschedCoreComputer_MiniMem::CorrelatePCPModelTask(int iSource, int iDestination, int iTaskIndex)
{
	m_mapLink2PCPModelTask[iSource][iDestination] = iTaskIndex;	
	m_setModelTask.insert(iTaskIndex);
}

void UnschedCoreComputer_MiniMem::CorrelateRTBModelTask(int iSource, int iDestination, int iTaskIndex)
{
	m_mapLink2RTBModelTask[iSource][iDestination] = iTaskIndex;
	m_setModelTask.insert(iTaskIndex);
}

void UnschedCoreComputer_MiniMem::setLinkModelBaseTask(int iBaseTask)
{
	m_iLinkModelBaseTask = iBaseTask;
	m_setModelTask.insert(iBaseTask);
}

void UnschedCoreComputer_MiniMem::PreSchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet)
{
	m_pcPPOSetForSchedTest = &rcPPOSet;
	m_pcFixedSetForSchedTest = &rcFixedSet;
}

bool UnschedCoreComputer_MiniMem::SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (m_setModelTask.count(iTaskIndex) == 1)
		return true;
	double dBlocking = ComputeBlocking(iTaskIndex, rcPriorityAssignment, *m_pcPPOSetForSchedTest, *m_pcFixedSetForSchedTest);
	double dDeadline = pcTaskArray[iTaskIndex].getDeadline();
	int iTaskPriority = rcPriorityAssignment.getPriorityByTask(iTaskIndex);
	_LORTCalculator cRTCalc(*m_pcTaskSet);
	bool bGenericDeadlineSchedulable = false;
	double dResponseTime = cRTCalc.CalculateRTTaskWithBlocking(iTaskIndex, dBlocking, rcPriorityAssignment);
	for (Task::CommIter iter = pcTaskArray[iTaskIndex].SuccessorBegin(); iter != pcTaskArray[iTaskIndex].SuccessorEnd(); iter++)
	{
		int iSource = iTaskIndex;
		int iDestination = iter->m_iTargetTask;
		if (IsRTBDet(iSource, iDestination, *m_pcPPOSetForSchedTest, *m_pcFixedSetForSchedTest)) continue;
		int iOtherPriority = rcPriorityAssignment.getPriorityByTask(iDestination);
		if (iTaskPriority < iOtherPriority)	continue;

		double dDeadline = m_pcTaskSet->SmallestOffset(iSource, iDestination);		
		if (dResponseTime > dDeadline)
			return false;
		else
			bGenericDeadlineSchedulable = true;

	}
	
	for (Task::CommIter iter = pcTaskArray[iTaskIndex].PredecessorBegin(); iter != pcTaskArray[iTaskIndex].PredecessorEnd(); iter++)
	{
		int iSource = iter->m_iTargetTask;
		int iDestination = iTaskIndex;
		if (IsRTBDet(iSource, iDestination, *m_pcPPOSetForSchedTest, *m_pcFixedSetForSchedTest)) continue;
		int iOtherPriority = rcPriorityAssignment.getPriorityByTask(iSource);
		if (iTaskPriority < iOtherPriority)	continue;

		double dDeadline = m_pcTaskSet->SmallestOffset(iDestination, iSource);		
		if (dResponseTime > dDeadline)
			return false;
		else
			bGenericDeadlineSchedulable = true;
	}
	
	if (!bGenericDeadlineSchedulable)
	{
		bGenericDeadlineSchedulable = cRTCalc.CalculateRTTaskWithBlocking(iTaskIndex, dBlocking, rcPriorityAssignment) <= pcTaskArray[iTaskIndex].getDeadline();
	}
	return bGenericDeadlineSchedulable;
}

double UnschedCoreComputer_MiniMem::ComputeBlocking(int iTaskIndex, TaskSetPriorityStruct & rcPirorityAssignment, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iTaskPriority = rcPirorityAssignment.getPriorityByTask(iTaskIndex);
	assert(iTaskPriority != -1);
	double dBlocking = 0;
	for (Task::CommIter iter = pcTaskArray[iTaskIndex].SuccessorBegin(); iter != pcTaskArray[iTaskIndex].SuccessorEnd(); iter++)
	{		
		int iSource = iTaskIndex;
		int iDestination = iter->m_iTargetTask;
		if (!IsPCPDet(iSource, iDestination, rcPPOSet, rcFixedSet))	continue;
		TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = ((TaskSetExt_LinkCritialSection*)m_pcTaskSet)->getLinkCriticalSectionInfo(iSource, iDestination);
		int iThisPriority = rcPirorityAssignment.getPriorityByTask(iDestination);
		if (iTaskPriority < iThisPriority)
		{
			dBlocking = max(dBlocking, cLinkCSInfo.dReadCSLen);
		}
	}

	for (Task::CommIter iter = pcTaskArray[iTaskIndex].PredecessorBegin(); iter != pcTaskArray[iTaskIndex].PredecessorEnd(); iter++)
	{
		int iSource = iter->m_iTargetTask;
		int iDestination = iTaskIndex;
		if (!IsPCPDet(iSource, iDestination, rcPPOSet, rcFixedSet))	continue;
		TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = ((TaskSetExt_LinkCritialSection*)m_pcTaskSet)->getLinkCriticalSectionInfo(iSource, iDestination);
		int iThisPriority = rcPirorityAssignment.getPriorityByTask(iSource);
		if (iTaskPriority < iThisPriority)
		{
			dBlocking = max(dBlocking, cLinkCSInfo.dWriteCSLen);
		}
	}
	return dBlocking;
}

bool UnschedCoreComputer_MiniMem::IsRTBDet(int iSource, int iDestination, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet)
{
	assert(m_mapLink2RTBModelTask.count(iSource));
	assert(m_mapLink2RTBModelTask[iSource].count(iDestination));
	int iRTBModelTask = m_mapLink2RTBModelTask[iSource][iDestination];
	if((rcPPOSet.count({ iRTBModelTask, m_iLinkModelBaseTask }) == 1) || (rcFixedSet.count({ iRTBModelTask, m_iLinkModelBaseTask }) == 1))
	{		
		return false;
	}
	else
	{
		return true;
	}

}

bool UnschedCoreComputer_MiniMem::IsPCPDet(int iSource, int iDestination, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet)
{
	//cout << iSource << " " << iDestination << endl;
	assert(m_mapLink2PCPModelTask.count(iSource));
	assert(m_mapLink2PCPModelTask[iSource].count(iDestination));
	int iPCPModelTask = m_mapLink2PCPModelTask[iSource][iDestination];
	//cout << "end" << endl;
	return (rcPPOSet.count({ m_iLinkModelBaseTask, iPCPModelTask }) == 1) || (rcFixedSet.count({ m_iLinkModelBaseTask, iPCPModelTask }) == 1);
}

void UnschedCoreComputer_MiniMem::ConvertToNormalPA(TaskSetPriorityStruct & rcPriorityAssignmentOriginal, TaskSetPriorityStruct & rcConverted)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	rcConverted.Clear();
	rcConverted = TaskSetPriorityStruct(*m_pcTaskSet);
	int iPriorityLevel = 0;
	for (int i = 0; i < iTaskNum; i++)
	{
		int iTaskIndex = rcPriorityAssignmentOriginal.getTaskByPriority(i);
		if (m_setModelTask.count(iTaskIndex))
			continue;
		rcConverted.setPriority(iTaskIndex, iPriorityLevel);
		iPriorityLevel++;
	}
}

void UnschedCoreComputer_MiniMem::ConvertToExtendedTaskSet(TaskSetExt_LinkCritialSection & rcOriginalTaskSet, 
	TaskSetExt_LinkCritialSection & rcConvertedTaskSet, Link2LinkModelTask & rcRTBModelTask, Link2LinkModelTask & rcPCPMOdelTask, set<int> & rsetModelTaskSet, int & iBaseTask)
{
	GET_TASKSET_NUM_PTR(&rcOriginalTaskSet, iTaskNum, pcTaskArray);
	rcConvertedTaskSet.ClearAll();
	rcPCPMOdelTask.clear();
	rcRTBModelTask.clear();
	deque<Task> dequeModelTasks;	
	double dLCMPeriod = 1;
	for (int i = 0; i < iTaskNum; i++)
	{
		dLCMPeriod = lcm(dLCMPeriod, pcTaskArray[i].getPeriod());
	}

	for (int i = 0; i < iTaskNum; i++)
	{
		rcConvertedTaskSet.AddTask(pcTaskArray[i]);
	}

	int iIndex = iTaskNum;
	rcConvertedTaskSet.AddTask(dLCMPeriod, dLCMPeriod, 0.0, 0.0, false, iIndex++);//Base Task;
	iBaseTask = iIndex - 1;
	rsetModelTaskSet.insert(iIndex - 1);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].SuccessorBegin(); iter != pcTaskArray[i].SuccessorEnd(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			rcConvertedTaskSet.AddTask(dLCMPeriod, dLCMPeriod, 0.0, 0.0, false, iIndex++);//PCP Model Task
			rcPCPMOdelTask[iSource][iDestination] = iIndex - 1;
			rsetModelTaskSet.insert(iIndex - 1);
			rcConvertedTaskSet.AddTask(dLCMPeriod, dLCMPeriod, 0.0, 0.0, false, iIndex++);
			rcRTBModelTask[iSource][iDestination] = iIndex - 1;
			rsetModelTaskSet.insert(iIndex - 1);
		}
	}
	rcConvertedTaskSet.ConstructTaskArray();	
}

bool UnschedCoreComputer_MiniMem::IsSchedulable(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs)
{		
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	Task ** ppcTaskArrayByPeriod = m_pcTaskSet->getTaskArrayByPeriosPtr();
	TaskSetPriorityStruct & cPriorityAssignment = rcPriorityAssignment;
	int iPriority = iTaskNum - 1;
	int iPreAssignedSize = cPriorityAssignment.getSize();
	rcHinderingPOs = rcPriorityPOSet;
	m_pcPPOSetForSchedTest = &rcPriorityPOSet;
	m_pcFixedSetForSchedTest = &rcFixedPOSet;
	for (; iPriority >= 0; iPriority--)
	{		
		bool bAssigned = false;		
		if (rcPriorityAssignment.getTaskByPriority(iPriority) != -1)
		{
			continue;
		}
		for (int i = 0; i < iTaskNum; i++)
		{
			int iCand = ppcTaskArrayByPeriod[iTaskNum - i - 1]->getTaskIndex();

			if ((cPriorityAssignment.getPriorityByTask(iCand) != -1))
				continue;

			int iLPTask = IsPOBurden(iCand, cPriorityAssignment, rcFixedPOSet);
			if (iLPTask != -1)	continue;

			iLPTask = IsPOBurden(iCand, cPriorityAssignment, rcPriorityPOSet);
			if (iLPTask != -1)
			{				
				continue;
			}

			cPriorityAssignment.setPriority(iCand, iPriority);			
			if (SchedTestWrapper(iCand, cPriorityAssignment, m_pvSchedTestData))
			{
				bAssigned = true;
				break;
			}
			else
			{
				bAssigned = false;
				cPriorityAssignment.unset(iCand);
			}
		}

		if (!bAssigned)
		{
			return false;
		}
	}
	return true;
}

bool UnschedCoreComputer_MiniMem::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	PriorityPOSet cDummyFixed;
	PriorityPOSet cDummyHindering;
	return IsSchedulable(rcPPOSet, cDummyFixed, rcPriorityAssignment, cDummyHindering);
}


MinimizeMemory_PFR::MinimizeMemory_PFR()
{
}


MinimizeMemory_PFR::~MinimizeMemory_PFR()
{
}

MinimizeMemory_PFR::MinimizeMemory_PFR(TaskSet & rcTaskSet)		
{
	ConvertToExtendedTaskSet(*(TaskSetExt_LinkCritialSection *)&rcTaskSet);
	m_cPriorityAssignmentSol = TaskSetPriorityStruct(m_cExtendedTaskSet);
	m_pcTaskSet = &m_cExtendedTaskSet;
	m_enumAlgConfig = enumAlgConfig::Lazy;
	m_dILPTimeout = 1e74;
	m_iSubILPDisplay = 0;
	m_dILPOptGap = 100;
	m_iTerminateOnFeasible = 0;
	m_iCorePerIter = 5;
	m_dObjUB = 1e74;
	m_dObjLB = -1e74;
}

void MinimizeMemory_PFR::ConvertToExtendedTaskSet(TaskSetExt_LinkCritialSection & rcTaskSet)
{	
	UnschedCoreComputer_MiniMem::Link2LinkModelTask rcLink2PCPModelTask;
	UnschedCoreComputer_MiniMem::Link2LinkModelTask rcLink2RTBModelTask;
	set<int> setModelTaskSet;
	int iBaseTask = 0;
	m_cUnschedCoreComputer.ConvertToExtendedTaskSet(rcTaskSet, m_cExtendedTaskSet, rcLink2RTBModelTask, rcLink2PCPModelTask, setModelTaskSet, iBaseTask);		
	m_cExtendedTaskSet.m_dequeLinkCriticalSectionInfo = rcTaskSet.m_dequeLinkCriticalSectionInfo;	
	
	//m_cUnschedCoreComputer = UnschedCoreComputer_MiniMem(m_cExtendedTaskSet);
	m_cUnschedCoreComputer.Initialize(m_cExtendedTaskSet);
	m_cUnschedCoreComputer.getModelTaskSet() = setModelTaskSet;
	m_cUnschedCoreComputer.getPCPModelTask() = rcLink2PCPModelTask;
	m_cUnschedCoreComputer.getRTBModelTask() = rcLink2RTBModelTask;
	m_cUnschedCoreComputer.setBaseTask(iBaseTask);
}

int MinimizeMemory_PFR::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{	
	return m_cUnschedCoreComputer.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
}

bool MinimizeMemory_PFR::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	return m_cUnschedCoreComputer.IsSchedulable(rcPPOSet, rcPriorityAssignment);
}

IloExpr MinimizeMemory_PFR::ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPVars.getEnv();
	UnschedCoreComputer_MiniMem::Link2LinkModelTask & rcLink2PCPModelTask = m_cUnschedCoreComputer.getPCPModelTask();
	UnschedCoreComputer_MiniMem::Link2LinkModelTask & rcLink2RTBModelTask = m_cUnschedCoreComputer.getRTBModelTask();
	int iBaseTask = m_cUnschedCoreComputer.getBaseTask();
	IloExpr cExpr(rcEnv);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].SuccessorBegin(); iter != pcTaskArray[i].SuccessorEnd(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			int iPCPModelTask = rcLink2PCPModelTask[iSource][iDestination];
			int iRTBModelTask = rcLink2RTBModelTask[iSource][iDestination];
			TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = m_cExtendedTaskSet.getLinkCriticalSectionInfo(iSource, iDestination);
			cExpr += (getPriorityVariable(iBaseTask, iRTBModelTask, rcPVars) - getPriorityVariable(iBaseTask, iPCPModelTask, rcPVars)) * iter->m_dMemoryCost + getPriorityVariable(iBaseTask, iPCPModelTask, rcPVars) * 20;
			if (pcRelevantPPO)
			{
				pcRelevantPPO->insert({ iBaseTask, iRTBModelTask });
				pcRelevantPPO->insert({ iBaseTask, iPCPModelTask });
			}
		}
	}
	return cExpr;
}

void MinimizeMemory_PFR::GenExtraConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray, void * pvExtraData)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPVars.getEnv();
	UnschedCoreComputer_MiniMem::Link2LinkModelTask & rcLink2PCPModelTask = m_cUnschedCoreComputer.getPCPModelTask();
	UnschedCoreComputer_MiniMem::Link2LinkModelTask & rcLink2RTBModelTask = m_cUnschedCoreComputer.getRTBModelTask();
	int iBaseTask = m_cUnschedCoreComputer.getBaseTask();	
	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].SuccessorBegin(); iter != pcTaskArray[i].SuccessorEnd(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			int iPCPModelTask = rcLink2PCPModelTask[iSource][iDestination];
			int iRTBModelTask = rcLink2RTBModelTask[iSource][iDestination];
			TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = m_cExtendedTaskSet.getLinkCriticalSectionInfo(iSource, iDestination);			
			rcRangeArray.add(IloRange(rcEnv, 0.0,
				getPriorityVariable(iBaseTask, iRTBModelTask, rcPVars) - getPriorityVariable(iBaseTask, iPCPModelTask, rcPVars),
				IloInfinity));
		}
	}
	return;
}

bool MinimizeMemory_PFR::VerifyMinimizeMemoryResult(double dObjective, TaskSetPriorityStruct & rcPriorityAssignment)
{
	return true;
}

void MinimizeMemory_PFR::GenFixedPPOSet(PriorityPOSet & rcFixedSet)
{
	return;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].SuccessorBegin(); iter != pcTaskArray[i].SuccessorEnd(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			if (pcTaskArray[iSource].getPeriod() < pcTaskArray[iDestination].getPeriod())
			{
				rcFixedSet.insert({ iSource, iDestination });
			}
			else
			{
				rcFixedSet.insert({ iDestination, iSource });
			}
		}
	}
}

//Based on rbf full model

MinimizeMemory_RBF::MinimizeMemory_RBF()
{

}

MinimizeMemory_RBF::MinimizeMemory_RBF(TaskSet & rcTaskSet, TPCCSet_PerDeadlines & rcTPCCSet)	
{
	m_pcTaskSet = &rcTaskSet;
	m_pcTPCCPDSet = &rcTPCCSet;
	InitializeLinkObj();
}

MinimizeMemory_RBF::~MinimizeMemory_RBF()
{

}

double MinimizeMemory_RBF::DetermineBigMLO(int iTaskIndex)
{	
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(iTaskIndex < iTaskNum);
	double dBigM = pcTaskArray[iTaskIndex].getCLO();
	double dMaxWCET = 0;
	for (int i = 0; i < iTaskNum; i++)
	{
		if (iTaskIndex == i)
			continue;
		double dN = ceil(pcTaskArray[iTaskIndex].getPeriod() / pcTaskArray[i].getPeriod());
		dBigM += dN * pcTaskArray[i].getCLO();
		dMaxWCET = max(dMaxWCET, pcTaskArray[i].getCLO());
	}

	dBigM += dMaxWCET;

	return dBigM;
}

void MinimizeMemory_RBF::GenerateTPCCPD(TaskSet & rcTaskSet, TPCCSet_PerDeadlines & rcTPCCSet)
{
	GET_TASKSET_NUM_PTR(&rcTaskSet, iTaskNum, pcTaskArray);
	rcTPCCSet.Clear();
	rcTPCCSet.Initialize(rcTaskSet);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].getSuccessorSet().begin();
			iter != pcTaskArray[i].getSuccessorSet().end(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			rcTPCCSet.AddDeadline(iSource, rcTaskSet.SmallestOffset(iSource, iDestination));
			rcTPCCSet.AddDeadline(iDestination, rcTaskSet.SmallestOffset(iDestination, iSource));
		}
	}
	rcTPCCSet.GenAllTPCC();
}

void MinimizeMemory_RBF::CreatePCPDetVars(IloNumVarArray & rcVarArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcVarArray.getEnv();
	char axBuffer[512] = { 0 };
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDest = iter->second.m_iDestination;
		sprintf_s(axBuffer, "PCPDet(%d, %d)", iSource, iDest);
		rcVarArray.add(IloNumVar(rcEnv, 0.0, 1.0, IloNumVar::Int, axBuffer));
	}

}

void MinimizeMemory_RBF::CreateRTBDetVars(IloNumVarArray & rcVarArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcVarArray.getEnv();
	char axBuffer[512] = { 0 };
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDest = iter->second.m_iDestination;
		sprintf_s(axBuffer, "RTBDet(%d, %d)", iSource, iDest);
		rcVarArray.add(IloNumVar(rcEnv, 0.0, 1.0, IloNumVar::Int, axBuffer));
	}

}

void MinimizeMemory_RBF::CreateTaskBlockVars(IloNumVarArray & rcVarArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcVarArray.getEnv();
	char axBuffer[512] = { 0 };
	for (int i = 0; i < iTaskNum; i++)
	{
		sprintf_s(axBuffer, "B(%d)", i);
		rcVarArray.add(IloNumVar(rcEnv, 0.0, IloInfinity, IloNumVar::Float));
	}
}

void MinimizeMemory_RBF::CreateLinkBlcokVars(IloNumVarArray & rcVarArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcVarArray.getEnv();
	char axBuffer[512] = { 0 };
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDest = iter->second.m_iDestination;
		sprintf_s(axBuffer, "BlockWrite(%d, %d)", iSource, iDest);		
		rcVarArray.add(IloNumVar(rcEnv, 0.0, IloInfinity, IloNumVar::Float, axBuffer));
		sprintf_s(axBuffer, "BlockRead(%d, %d)", iSource, iDest);
		rcVarArray.add(IloNumVar(rcEnv, 0.0, IloInfinity, IloNumVar::Float, axBuffer));
	}
}

IloNumVar & MinimizeMemory_RBF::getPCPDetVars(int iSource, int iDest, IloNumVarArray & rcVarArray)
{
	assert(m_mapLink2Index.count({ iSource, iDest }));
	return(rcVarArray[m_mapLink2Index[{iSource, iDest}]]);
}

IloNumVar & MinimizeMemory_RBF::getRTBDetVars(int iSource, int iDest, IloNumVarArray & rcVarArray)
{
	assert(m_mapLink2Index.count({ iSource, iDest }));
	return(rcVarArray[m_mapLink2Index[{iSource, iDest}]]);
}

IloNumVar & MinimizeMemory_RBF::getTaskBlockVars(int iTaskIndex, IloNumVarArray & rcVarArray)
{
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	return rcVarArray[iTaskIndex];
}

IloNumVar & MinimizeMemory_RBF::getLinkReadBlockVar(int iSource, int iDestination, IloNumVarArray & rcVarArray)
{
	assert(m_mapLink2Index.count({ iSource, iDestination }));
	int iAccessIndex = m_mapLink2Index[{iSource, iDestination}];
	iAccessIndex = 2 * iAccessIndex + 1;
	assert(iAccessIndex < rcVarArray.getSize());
	return rcVarArray[iAccessIndex];
}

IloNumVar & MinimizeMemory_RBF::getLinkWriteBlockVar(int iSource, int iDestination, IloNumVarArray & rcVarArray)
{
	assert(m_mapLink2Index.count({ iSource, iDestination }));
	int iAccessIndex = m_mapLink2Index[{iSource, iDestination}];
	iAccessIndex = 2 * iAccessIndex;
	assert(iAccessIndex < rcVarArray.getSize());
	return rcVarArray[iAccessIndex];
}

void MinimizeMemory_RBF::GenBlockModelConst(IloNumVarArray & rcPVars, 
	IloNumVarArray & rcPCPDetVars, IloNumVarArray & rcLinkBlcokVar, IloNumVarArray & rcTaskBlockVars, IloRangeArray & rcConst)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	TaskSetExt_LinkCritialSection rcTaskSet = *(TaskSetExt_LinkCritialSection*)m_pcTaskSet;
	const IloEnv & rcEnv = rcPVars.getEnv();
	for (int i = 0; i < iTaskNum; i++)
	{
		set<Task::CommunicationLink> & rsetSuccessors = pcTaskArray[i].getSuccessorSet();
		for (set<Task::CommunicationLink>::iterator iter = rsetSuccessors.begin();
			iter != rsetSuccessors.end(); iter++)
		{
			int iSource = i;
			int iDest = iter->m_iTargetTask;
			rcConst.add(IloRange(rcEnv, 0.0,
				getTaskBlockVars(i, rcTaskBlockVars) - getLinkReadBlockVar(iSource, iDest, rcLinkBlcokVar),
				IloInfinity
				));			
		}
		set<Task::CommunicationLink> & rsetPredecessor = pcTaskArray[i].getPredecessorSet();		
		for (set<Task::CommunicationLink>::iterator iter = rsetPredecessor.begin();
			iter != rsetPredecessor.end(); iter++)
		{
			int iDest = i;
			int iSource= iter->m_iTargetTask;
			rcConst.add(IloRange(rcEnv, 0.0,
				getTaskBlockVars(i, rcTaskBlockVars) - getLinkWriteBlockVar(iSource, iDest, rcLinkBlcokVar),
				IloInfinity
				));
		}
	}
	
	for (int i = 0; i < iTaskNum; i++)
	{
		set<Task::CommunicationLink> & rsetSuccessors = pcTaskArray[i].getSuccessorSet();
		for (set<Task::CommunicationLink>::iterator iter = rsetSuccessors.begin();
			iter != rsetSuccessors.end(); iter++)
		{			
			int iSource = i;
			int iDest = iter->m_iTargetTask;
			TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo tagLinkCSInfo = rcTaskSet.getLinkCriticalSectionInfo(iSource, iDest);
			rcConst.add(IloRange(rcEnv, -IloInfinity,
				getLinkReadBlockVar(iSource, iDest, rcLinkBlcokVar) - getPriorityVariable(iSource, iDest, rcPVars) * tagLinkCSInfo.dReadCSLen,
				0.0
				));

			rcConst.add(IloRange(rcEnv, -IloInfinity,
				getLinkReadBlockVar(iSource, iDest, rcLinkBlcokVar) - getPCPDetVars(iSource, iDest, rcPCPDetVars) * tagLinkCSInfo.dReadCSLen,
				0.0
				));

			rcConst.add(IloRange(rcEnv, -IloInfinity,
				getLinkWriteBlockVar(iSource, iDest, rcLinkBlcokVar) - getPriorityVariable(iDest, iSource, rcPVars) * tagLinkCSInfo.dWriteCSLen,
				0.0
				));

			rcConst.add(IloRange(rcEnv, -IloInfinity,
				getLinkWriteBlockVar(iSource, iDest, rcLinkBlcokVar) - getPCPDetVars(iSource, iDest, rcPCPDetVars) * tagLinkCSInfo.dWriteCSLen,
				0.0
				));

			rcConst.add(IloRange(rcEnv, 0.0,
				getLinkReadBlockVar(iSource, iDest, rcLinkBlcokVar) - 
				(getPriorityVariable(iSource, iDest, rcPVars) + getPCPDetVars(iSource, iDest, rcPCPDetVars) - 1) * tagLinkCSInfo.dReadCSLen,
				IloInfinity
				));

			rcConst.add(IloRange(rcEnv, 0.0,
				getLinkWriteBlockVar(iSource, iDest, rcLinkBlcokVar) -
				(getPriorityVariable(iDest, iSource, rcPVars) + getPCPDetVars(iSource, iDest, rcPCPDetVars) - 1) * tagLinkCSInfo.dWriteCSLen,
				IloInfinity
				));

		}
	}

}

void MinimizeMemory_RBF::GenLOSchedConst(int iTaskIndex, set<double> & rsetTestPoint, 
	IloNumVarArray & rcPVars, IloNumVarArray & rcBlcokVars, DisjunctionEncoder & rcDisjunctionEncoder, IloRangeArray & rcConst)
{
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	const IloEnv & rcEnv = rcPVars.getEnv();	
	char axBuffer[128] = { 0 };
	int iEncIndex = 0;
	double dBigM = DetermineBigMLO(iTaskIndex);
	rcDisjunctionEncoder = DisjunctionEncoder((IloEnv &)rcEnv, rsetTestPoint.size());
	for (set<double>::iterator iter = rsetTestPoint.begin();
		iter != rsetTestPoint.end(); iter++)
	{
		sprintf_s(axBuffer, "rbfLO(%d, %.2f)", iTaskIndex, *iter);
		rcConst.add(IloRange(rcEnv, -IloInfinity,
			rbfLO(iTaskIndex, *iter, rcPVars) + getTaskBlockVars(iTaskIndex, rcBlcokVars) - *iter - rcDisjunctionEncoder.getEncodingExpression(iEncIndex, dBigM),
			0.0, axBuffer));
		iEncIndex++;
	}
	rcConst.add(rcDisjunctionEncoder.getEncodingConstraint());
}

void MinimizeMemory_RBF::GenLOSchedConst(IloNumVarArray & rcPVars, IloNumVarArray & rcBlockVars, deque<DisjunctionEncoder> & rdequeDisjunctionEncoders, IloRangeArray & rcConst)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);	
	for (int i = 0; i < iTaskNum; i++)
	{
		rdequeDisjunctionEncoders.push_back(DisjunctionEncoder());
		GenLOSchedConst(i, m_pcTPCCPDSet->getTestPoints(i, pcTaskArray[i].getDeadline()), rcPVars, rcBlockVars, rdequeDisjunctionEncoders[i], rcConst);
	}
}

void MinimizeMemory_RBF::GenRTBPCPRelConst(IloNumVarArray & rcPCPDet, IloNumVarArray & rcRTBDet, IloRangeArray & rcConstraint)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPCPDet.getEnv();
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		rcConstraint.add(IloRange(rcEnv, 0.0, getRTBDetVars(iSource, iDestination, rcRTBDet) - getPCPDetVars(iSource, iDestination, rcPCPDet), IloInfinity));
	}
}

void MinimizeMemory_RBF::GenRTBDetConst(int iSource, int iDest, IloNumVarArray & rcRTBDetVar, 
	IloNumVarArray & rcPVar, IloNumVarArray & rcBlockVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcConst)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcRTBDetVar.getEnv();
	TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = ((TaskSetExt_LinkCritialSection *)m_pcTaskSet)->getLinkCriticalSectionInfo(iSource, iDest);
	
	double dOffset = m_pcTaskSet->SmallestOffset(iSource, iDest);
	set<double> & rsetTestPointsSource = m_pcTPCCPDSet->getTestPoints(iSource, dOffset);
	dOffset = m_pcTaskSet->SmallestOffset(iDest, iSource);
	set<double> & rsetTestPointDestination = m_pcTPCCPDSet->getTestPoints(iDest, dOffset);

	int iEncRange = max(rsetTestPointDestination.size(), rsetTestPointsSource.size());
	rcEncoder = DisjunctionEncoder((IloEnv &)rcEnv, iEncRange);

	double dBigM = DetermineBigMLO(iSource);
	int iEncIndex = 0;
	for (set<double>::iterator iter = rsetTestPointsSource.begin();
		iter != rsetTestPointsSource.end(); iter++)
	{
		rcConst.add(IloRange(rcEnv,
			-IloInfinity,
			rbfLO(iSource, *iter, rcPVar) + getTaskBlockVars(iSource, rcBlockVars) - *iter - rcEncoder.getEncodingExpression(iEncIndex, dBigM) - dBigM * getPriorityVariable(iSource, iDest, rcPVar)
			- getRTBDetVars(iSource, iDest, rcRTBDetVar) * dBigM,
			0.0
			));
		iEncIndex++;
	}
	rcConst.add(IloRange(rcEnv,
		-IloInfinity,
		rcEncoder.getEncodingConstExpr() - iEncIndex * getPriorityVariable(iSource, iDest, rcPVar),
		iEncIndex - 1
		));

	dBigM = DetermineBigMLO(iDest);
	iEncIndex = 0;
	for (set<double>::iterator iter = rsetTestPointDestination.begin();
		iter != rsetTestPointDestination.end(); iter++)
	{
		rcConst.add(IloRange(rcEnv,
			-IloInfinity,
			rbfLO(iDest, *iter, rcPVar) + getTaskBlockVars(iDest, rcBlockVars) - *iter - rcEncoder.getEncodingExpression(iEncIndex, dBigM) - dBigM * getPriorityVariable(iDest, iSource, rcPVar)
			- getRTBDetVars(iSource, iDest, rcRTBDetVar) * dBigM,
			0.0
			));
		iEncIndex++;
	}
	rcConst.add(IloRange(rcEnv,
		-IloInfinity,
		rcEncoder.getEncodingConstExpr() - iEncIndex * getPriorityVariable(iDest, iSource, rcPVar),
		iEncIndex - 1
		));
}

void MinimizeMemory_RBF::GenRTBDetConst(IloNumVarArray & rcRTBDetVar, IloNumVarArray & rcPVar, IloNumVarArray & rcBlockVars, deque<DisjunctionEncoder> & rdequeDisjunctionEncoders, IloRangeArray & rcConst)
{

	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		rdequeDisjunctionEncoders.push_back(DisjunctionEncoder());
		GenRTBDetConst(iSource, iDestination, rcRTBDetVar, rcPVar, rcBlockVars, rdequeDisjunctionEncoders[iter->first], rcConst);
	}
}

IloExpr MinimizeMemory_RBF::ObjExpr(IloNumVarArray & rcRTBDetVars, IloNumVarArray & rcPCPDetVars)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcRTBDetVars.getEnv();
	TaskSetExt_LinkCritialSection rcTaskSet = *(TaskSetExt_LinkCritialSection*)m_pcTaskSet;
	IloExpr cExpr(rcEnv);
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin(); iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		cExpr += (getRTBDetVars(iSource, iDestination, rcRTBDetVars) - getPCPDetVars(iSource, iDestination, rcPCPDetVars) )* iter->second.m_dMemoryCost;
		cExpr += getPCPDetVars(iSource, iDestination, rcPCPDetVars) * 20;
	}

	return cExpr;
}

void MinimizeMemory_RBF::ExtractPriorityResult(IloNumVarArray & rcPriorityVariables, IloCplex & rcSolver, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	m_mapPriorityResult.clear();
	for (int i = 0; i < iTaskNum; i++)
	{
		int iPriority = 0;
		for (int j = 0; j < iTaskNum; j++)
		{
			if (i == j) continue;
			iPriority += getPriorityResult(j, i, rcPriorityVariables, rcSolver);
		}
		rcPriorityAssignment.setPriority(i, iPriority);
	}
	m_dObjective = rcSolver.getObjValue();
}

int MinimizeMemory_RBF::Solve(int iDisplay, double dTimeout)
{

	IloEnv cSolveEnv;
	IloNumVarArray cPriorityVariables(cSolveEnv);
	IloNumVarArray cRTBDetVars(cSolveEnv);
	IloNumVarArray cPCPDetVars(cSolveEnv);
	IloNumVarArray cTaskBlockVars(cSolveEnv);
	IloNumVarArray cLinkBlockVars(cSolveEnv);
	IloRangeArray cConstraint(cSolveEnv);
	deque<DisjunctionEncoder> dequeTaskSchedEncoders;
	deque<DisjunctionEncoder> dequeRTBModelEncoders;
	CreatePriortyVariable(cPriorityVariables);	
	CreatePCPDetVars(cPCPDetVars);
	CreateRTBDetVars(cRTBDetVars);
	CreateTaskBlockVars(cTaskBlockVars);
	CreateLinkBlcokVars(cLinkBlockVars);	
	GenPriorityConst(cPriorityVariables, cConstraint);
	GenRTBPCPRelConst(cPCPDetVars, cRTBDetVars, cConstraint);	
	GenBlockModelConst(cPriorityVariables, cPCPDetVars, cLinkBlockVars, cTaskBlockVars, cConstraint);	
	GenLOSchedConst(cPriorityVariables, cTaskBlockVars, dequeTaskSchedEncoders, cConstraint);
	GenRTBDetConst(cRTBDetVars, cPriorityVariables, cTaskBlockVars, dequeRTBModelEncoders, cConstraint);

	IloObjective cObjective = IloMinimize(cSolveEnv, ObjExpr(cRTBDetVars, cPCPDetVars));


	IloModel cModel(cSolveEnv);
	cModel.add(cConstraint);
	cModel.add(cObjective);

	IloCplex cSolver(cModel);

	EnableSolverDisp(iDisplay, cSolver);
	setSolverParam(cSolver);
	cSolver.setParam(IloCplex::Param::TimeLimit, dTimeout);

	m_dSolveCPUTime = getCPUTimeStamp();
	m_dSolveWallTime = cSolver.getCplexTime();

	bool bStatus = cSolver.solve();
	m_dSolveCPUTime = getCPUTimeStamp() - m_dSolveCPUTime;
	m_dSolveWallTime = cSolver.getCplexTime() - m_dSolveWallTime;

	int iRetStatus = 0;
	m_dObjective = 1e74;
	if (bStatus)
	{
		assert(VerifyPriority(cPriorityVariables, cSolver));
		m_cResultPA = TaskSetPriorityStruct(*m_pcTaskSet);
		ExtractPriorityResult(cPriorityVariables, cSolver, m_cResultPA);
		//m_cResultPA.Print();
		assert(VerifyRTBDet(cRTBDetVars, cPCPDetVars, cPriorityVariables, cTaskBlockVars, m_cResultPA, cSolver));
		assert(VerifySchedulability(cPCPDetVars, m_cResultPA, cSolver));
		VerifyLinkBlocking(cLinkBlockVars, cPCPDetVars, m_cResultPA, cSolver);
		VerifyTaskLinkBlocking(cTaskBlockVars, cLinkBlockVars, cSolver);
		VerifyObjective(cRTBDetVars, cPCPDetVars, cTaskBlockVars, cSolver, m_cResultPA);		
		m_bIsValidSolution = true;
	}


	{
		m_bIsValidSolution = false;
		if (cSolver.getCplexStatus() == cSolver.Optimal)
			iRetStatus = 1;
		else if (cSolver.getCplexStatus() == cSolver.AbortTimeLim)
			iRetStatus = -1;
		else if (cSolver.getCplexStatus() == cSolver.Infeasible)
			iRetStatus = 0;
		else
			iRetStatus = 0;
	}
		
	cSolveEnv.end();
	return iRetStatus;
}


bool MinimizeMemory_RBF::VerifyRTBDet(IloNumVarArray & rcRTBDet, IloNumVarArray & rcPCPDet, IloNumVarArray & rcPVars, IloNumVarArray & rcBlockVars, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver)
{
	_LORTCalculator cRTCalc(*m_pcTaskSet);
	
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin(); iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		int iSol = round(rcSolver.getValue(getRTBDetVars(iSource, iDestination, rcRTBDet)));
		if (iSol == 1) continue;		
		if (rcPriorityAssignment.getPriorityByTask(iSource) < rcPriorityAssignment.getPriorityByTask(iDestination))
		{						
			double dBlocking = ComputeBlocking(iDestination, rcPCPDet, rcPriorityAssignment, rcSolver);
			double dRTDest = cRTCalc.CalculateRTTaskWithBlocking(iDestination, dBlocking, rcPriorityAssignment);
			double dDeadline = m_pcTaskSet->SmallestOffset(iDestination, iSource);
			if (dRTDest > dDeadline)
			{
				cout << "RT-Det Incorrect" << endl;
				cout << "Task " << iDestination;
				cout << "Blocking " << dBlocking << endl;
				cout << dRTDest << " " << dDeadline << endl;
				set<double> & rsetTestPoint = m_pcTPCCPDSet->getTestPoints(iDestination, dDeadline);
				for (set<double>::iterator iter = rsetTestPoint.begin(); iter != rsetTestPoint.end(); iter++)
				{
					double dRBf = rcSolver.getValue(rbfLO(iDestination, *iter, rcPVars) + getTaskBlockVars(iDestination, rcBlockVars));
					printf_s("%.2f: %.2f\n", *iter, dRBf);
				}
				
				while (1);
			}
		}
		else
		{
			double dBlocking = ComputeBlocking(iSource, rcPCPDet, rcPriorityAssignment, rcSolver);
			double dRTSource = cRTCalc.CalculateRTTaskWithBlocking(iSource, dBlocking, rcPriorityAssignment);
			double dDeadline = m_pcTaskSet->SmallestOffset(iSource, iDestination);
			if (dRTSource > dDeadline)
			{
				cout << "RT-Det Incorrect" << endl;
				cout << "Task " << iSource << endl;
				cout << "Blocking " << dBlocking << " " << rcSolver.getValue(getTaskBlockVars(iSource, rcBlockVars)) << endl;
				cout << dRTSource << " " << dDeadline << endl;
				set<double> & rsetTestPoint = m_pcTPCCPDSet->getTestPoints(iSource, dDeadline);
				for (set<double>::iterator iter = rsetTestPoint.begin(); iter != rsetTestPoint.end(); iter++)
				{
					double dRBf = rcSolver.getValue(rbfLO(iSource, *iter, rcPVars) + getTaskBlockVars(iSource, rcBlockVars));
					printf_s("%.2f: %.2f\n", *iter, dRBf);
				}
				while (1);
			}
		}
	}
	return true;
}

bool MinimizeMemory_RBF::VerifySchedulability(IloNumVarArray & rcPCPDet, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	_LORTCalculator cRTCalc(*m_pcTaskSet);
	for (int i = 0; i < iTaskNum; i++)
	{
		set<Task::CommunicationLink> & rsetSuccessors = pcTaskArray[i].getSuccessorSet();
		set<Task::CommunicationLink> & rsetPredecessors = pcTaskArray[i].getPredecessorSet();
		double dBlocking = ComputeBlocking(i, rcPCPDet, rcPriorityAssignment, rcSolver);
		double dRT = cRTCalc.CalculateRTTaskWithBlocking(i, dBlocking, rcPriorityAssignment);				
		if (dRT > pcTaskArray[i].getDeadline())
		{
			cout << "Task " << i << " schedulability failed" << endl;
			cout << "Blocking " << dBlocking << endl;
			cout << "RT " << dRT << endl;
			while (1);
		}
	}
	return true;
}

bool MinimizeMemory_RBF::VerifyObjective(IloNumVarArray & rcRTBDetVars, IloNumVarArray & rcPCPDet, IloNumVarArray & rcTaskBlockVars, IloCplex & rcSolver, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	_LORTCalculator cRTCalc(*m_pcTaskSet);
	double dObjective = 0;
	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin(); iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		int iLP = iSource;
		int iHP = iDestination;
		if (rcPriorityAssignment.getPriorityByTask(iSource) < rcPriorityAssignment.getPriorityByTask(iDestination))
		{
			iLP = iDestination;
			iHP = iSource;
		}

		double dBlockging = ComputeBlocking(iLP, rcPCPDet, rcPriorityAssignment, rcSolver);
		double dBlcokingInModel = rcSolver.getValue(getTaskBlockVars(iLP, rcTaskBlockVars));		
		//if (dBlcokingInModel < dBlockging)
		if (dBlockging - dBlcokingInModel > 1e-7)
		{
			cout << "Blocking Incorrectly Modeled" << endl;
			cout << iLP << " " << dBlcokingInModel << " " << dBlockging << endl;
			while (1);
		}
		double dRTLP = cRTCalc.CalculateRTTaskWithBlocking(iLP, dBlockging, rcPriorityAssignment);

		dBlockging = ComputeBlocking(iHP, rcPCPDet, rcPriorityAssignment, rcSolver);
		dBlcokingInModel = rcSolver.getValue(getTaskBlockVars(iHP, rcTaskBlockVars));		
		//if (dBlcokingInModel < dBlockging)
		if (dBlockging - dBlcokingInModel > 1e-7)
		{
			cout << "Blocking Incorrectly Modeled" << endl;
			cout << iHP << " " << dBlcokingInModel << " " << dBlockging << endl;
			while (1);
		}
		double dRTHP = cRTCalc.CalculateRTTaskWithBlocking(iHP, dBlockging, rcPriorityAssignment);

		int iRTBDetSol = round(rcSolver.getValue(getRTBDetVars(iSource, iDestination, rcRTBDetVars)));
		int iPCPDetSol = round(rcSolver.getValue(getPCPDetVars(iSource, iDestination, rcPCPDet)));
		if (dRTLP > m_pcTaskSet->SmallestOffset(iLP, iHP))
		{			
			if (iRTBDetSol != 1)
			{
				cout << "RTB-Det Incorrectly Modeled" << endl;
				cout << dRTLP << " " << m_pcTaskSet->SmallestOffset(iLP, iHP) << endl;
				while (1);
			}
		}		
		dObjective += (iRTBDetSol - iPCPDetSol) * iter->second.m_dMemoryCost + iPCPDetSol * 20;
	}

	if (!DOUBLE_EQUAL(dObjective, m_dObjective, 1e-6))
	{
		cout << "Incorrect Objective" << endl;
		cout << dObjective << " " << m_dObjective << endl;
		while (1);
	}

	return true;
}

double MinimizeMemory_RBF::ComputeBlocking(int iTaskIndex, IloNumVarArray & rcPCPDet, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver)
{
	int i = iTaskIndex;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	set<Task::CommunicationLink> & rsetSuccessors = pcTaskArray[i].getSuccessorSet();
	set<Task::CommunicationLink> & rsetPredecessors = pcTaskArray[i].getPredecessorSet();
	double dBlocking = 0;
	int iThisPriority = rcPriorityAssignment.getPriorityByTask(i);
	for (set<Task::CommunicationLink>::iterator iter = rsetSuccessors.begin(); iter != rsetSuccessors.end(); iter++)
	{
		int iSource = i;
		int iDestination = iter->m_iTargetTask;
		int iPCPDetSol = round(rcSolver.getValue(getPCPDetVars(iSource, iDestination, rcPCPDet)));
		if (iPCPDetSol == 1)
		{
			TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = ((TaskSetExt_LinkCritialSection*)m_pcTaskSet)->getLinkCriticalSectionInfo(iSource, iDestination);
			if (iThisPriority < rcPriorityAssignment.getPriorityByTask(iDestination))
				dBlocking = max(dBlocking, cLinkCSInfo.dReadCSLen);
		}
	}

	for (set<Task::CommunicationLink>::iterator iter = rsetPredecessors.begin(); iter != rsetPredecessors.end(); iter++)
	{
		int iSource = iter->m_iTargetTask;
		int iDestination = i;
		int iPCPDetSol = round(rcSolver.getValue(getPCPDetVars(iSource, iDestination, rcPCPDet)));
		if (iPCPDetSol == 1)
		{
			TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = ((TaskSetExt_LinkCritialSection*)m_pcTaskSet)->getLinkCriticalSectionInfo(iSource, iDestination);
			if (iThisPriority < rcPriorityAssignment.getPriorityByTask(iSource))
				dBlocking = max(dBlocking, cLinkCSInfo.dWriteCSLen);
		}
	}
	return dBlocking;
}

bool MinimizeMemory_RBF::VerifyLinkBlocking(IloNumVarArray & rcLinkBlockVars, IloNumVarArray & rcPCPDetVars, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);

	for (Index2LinkData::iterator iter = m_mapIndex2LinkData.begin(); iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		TaskSetExt_LinkCritialSection::LinkCriticalSectionInfo cLinkCSInfo = ((TaskSetExt_LinkCritialSection*)m_pcTaskSet)->getLinkCriticalSectionInfo(iSource, iDestination);
		int iLP = iSource;
		int iHP = iDestination;
		if (rcPriorityAssignment.getPriorityByTask(iSource) < rcPriorityAssignment.getPriorityByTask(iDestination))
		{
			iLP = iDestination;
			iHP = iSource;
		}
		int iPCPDetSol = round(rcSolver.getValue(getPCPDetVars(iSource, iDestination, rcPCPDetVars)));
		if (iPCPDetSol == 0)	continue;
		double dLinkReadBlockVar = rcSolver.getValue(getLinkReadBlockVar(iSource, iDestination, rcLinkBlockVars));
		double dLinkWriteBlockVar = rcSolver.getValue(getLinkWriteBlockVar(iSource, iDestination, rcLinkBlockVars));		
		if (rcPriorityAssignment.getPriorityByTask(iSource) < rcPriorityAssignment.getPriorityByTask(iDestination))
		{
			if (!DOUBLE_EQUAL(cLinkCSInfo.dReadCSLen, dLinkReadBlockVar, 1e-7))
			{
				cout << "Link Read Block Model Incorrect" << endl;
				printf_s("(%d, %d) %.2f %.2f", iSource, iDestination, dLinkReadBlockVar, cLinkCSInfo.dReadCSLen);
				while (1);
			}

			if (!DOUBLE_EQUAL(0.0, dLinkWriteBlockVar, 1e-7))
			{
				cout << "Link Write Block Model Incorrect" << endl;
				printf_s("(%d, %d) %.2f %.2f", iSource, iDestination, dLinkWriteBlockVar, 0.0);
				while (1);
			}
		}
		else
		{
			if (!DOUBLE_EQUAL(0.0, dLinkReadBlockVar, 1e-7))
			{
				cout << "Link Read Block Model Incorrect" << endl;
				printf_s("(%d, %d) %.2f %.2f", iSource, iDestination, dLinkReadBlockVar, 0.0);
				while (1);
			}

			if (!DOUBLE_EQUAL(cLinkCSInfo.dWriteCSLen, dLinkWriteBlockVar, 1e-7))
			{
				cout << "Link Write Block Model Incorrect" << endl;
				printf_s("(%d, %d) %.2f %.2f", iSource, iDestination, dLinkWriteBlockVar, cLinkCSInfo.dWriteCSLen);
				while (1);
			}
		}
	}	
	return true;
}

bool MinimizeMemory_RBF::VerifyTaskLinkBlocking(IloNumVarArray & rcTaskBlockVars, IloNumVarArray & rcLinkBlockVars, IloCplex & rcSolver)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	TaskSetExt_LinkCritialSection rcTaskSet = *(TaskSetExt_LinkCritialSection*)m_pcTaskSet;	
	for (int i = 0; i < iTaskNum; i++)
	{
		double dTaskBlock = rcSolver.getValue(getTaskBlockVars(i, rcTaskBlockVars));
		set<Task::CommunicationLink> & rsetSuccessors = pcTaskArray[i].getSuccessorSet();
		for (set<Task::CommunicationLink>::iterator iter = rsetSuccessors.begin();
			iter != rsetSuccessors.end(); iter++)
		{
			int iSource = i;
			int iDest = iter->m_iTargetTask;		
			double dLinkBlock = rcSolver.getValue(getLinkReadBlockVar(iSource, iDest, rcLinkBlockVars));
			//if (dTaskBlock < dLinkBlock)
			if (dLinkBlock - dTaskBlock > 1e-7)
			{
				cout << "Task Link Block Model Incorrect" << endl;
				printf_s("%d %.10f %.10f\n", i, dTaskBlock, dLinkBlock);
				while (1);
			}
		}
		set<Task::CommunicationLink> & rsetPredecessor = pcTaskArray[i].getPredecessorSet();
		for (set<Task::CommunicationLink>::iterator iter = rsetPredecessor.begin();
			iter != rsetPredecessor.end(); iter++)
		{
			int iDest = i;
			int iSource = iter->m_iTargetTask;		
			double dLinkBlock = rcSolver.getValue(getLinkWriteBlockVar(iSource, iDest, rcLinkBlockVars));
			if (dLinkBlock - dTaskBlock > 1e-7)
			{
				cout << "Task Link Block Model Incorrect" << endl;
				printf_s("%d %.10f %.10f\n", i, dTaskBlock, dLinkBlock);
				while (1);
			}
		}
	}
	return true;
}


void Perofrmance_WRK_K_LabServerLinux()
{
	int iTaskNum = 35;
	char axBuffer[1024] = { 0 };
	for (int k = 1; k <= 20; k+= 2)
	{
		char axPath[1024] = "";
		sprintf_s(axPath, "AUTOSTARMinMemNSweep/U0.50to0.95_CF2.00_N35");
		sprintf_s(axBuffer, "mkdir -p %s/K%d", axPath, k);
		system(axBuffer);
		for (int i = 1; i <= 1000; i++)
		{
			char axTaskSetName[1024] = { 0 };
			char axResultFileName[1024] = { 0 };
			sprintf_s(axResultFileName, "%s/K%d/TaskSet%d_Result.txt", axPath, k, i);
			sprintf_s(axTaskSetName, "%s/TaskSet%d.tskst", axPath, i);
			cout << "======================================" << endl;
			cout << "k: " << k << endl;
			cout << "Case : " << i << endl;
			if (IsFileExist(axTaskSetName) == false)
			{
				cout << "Cannot find TaskSet File " << axTaskSetName << endl;
				while (1);
			}

			if (IsFileExist(axResultFileName))
			{
				cout << "Result exists" << endl;
				continue;
			}
			cout << "Reading case ..." << endl;
			TaskSetExt_LinkCritialSection cTaskSet;
			cTaskSet.ReadImageFile(axTaskSetName);
			cout << "About to optimize..." << endl;
			MinimizeMemory_PFR cFR(cTaskSet);
			cFR.setCorePerIter(k);
			cout << "About to FR..." << endl;
			int iStatus = cFR.FocusRefinementFast(1, 1e3);
			StatisticSet cStatistic = cFR.GenerateStatisticFile("");
			ofstream ofstreamResultFile(axResultFileName);
			ofstreamResultFile << cStatistic.getItem("Total Time").getValue();
			ofstreamResultFile.close();
		}
	}

}
