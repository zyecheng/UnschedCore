#include "stdafx.h"
#include "RTSchedPTree.h"
#include <assert.h>
#include "ResponseTimeCalculator.h"
#include "Util.h"
#include <fstream>
#include <time.h>
#include <assert.h>
#include "BitMask.h"
#include "Timer.h"
#include "StatisticSet.h"
//#include <sysinfoapi.h>

//UnschedCore Computer

UnschedCoreComputer::PriorityPOOccurrenceComp::PriorityPOOccurrenceComp(int ** ppiPOOccurrence)
{
	m_ppiPOOccurrence = ppiPOOccurrence;
}

UnschedCoreComputer::UnschedCoreComputer(TaskSet & rcTaskSet)
{
	m_dTimeOnSchedTest = 0;
	m_dTimeOnIsSchedulable = 0;
	m_dTimeOnQuickSchedTest = 0;
	m_dTimeOnQuickSchedTest_Hit = 0;
	m_dTimeOnQuickSchedTest_Miss = 0;
	m_iQuickSchedTestInsertions = 0;
	m_iSchedTestCall = 0;
	m_dTimeOnSchedulable = 0;
	m_dTimeOnUnschedulable = 0;
	m_pcTaskSet = &rcTaskSet;
	int iTaskNum = rcTaskSet.getTaskNum();
	m_ppiPOOccurrence = new int *[iTaskNum];
	for (int i = 0; i < iTaskNum; i++)
	{
		m_ppiPOOccurrence[i] = new int[iTaskNum];
		memset(m_ppiPOOccurrence[i], 0, iTaskNum * sizeof(int));
	}	
	m_cPOOccurrenceSort = MySet<PriorityPOElement, PriorityPOOccurrenceComp>(PriorityPOOccurrenceComp(m_ppiPOOccurrence));	
	m_enumSchedTestOption = SchedulabilityTestOption::SchedTest_Original;
	m_enumSortingOption = ByOccurence;
	m_enumUnschedCoreOption = UCOpt_Original;
	
	m_vectorSystemFeaHPBitMaskNLH.reserve(iTaskNum);
	m_vectorSystemInfeaHPBitMaskNLH.reserve(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		//cout << "Hi" << endl;
		m_vectorSystemFeaHPBitMaskNLH.push_back(BitMaskStorage_N_LowestSet());
		m_vectorSystemInfeaHPBitMaskNLH.push_back(BitMaskStorage_N_LowestSet());		
		m_vectorSystemFeaHPBitMaskNLH.back().Initialize(iTaskNum);
		m_vectorSystemInfeaHPBitMaskNLH.back().Initialize(iTaskNum);
		//cout << "Hi" << endl;
	}	

	//cout << "Initialization Complete" << endl;;
}

UnschedCoreComputer::UnschedCoreComputer()
{
	m_pcTaskSet = NULL;
	m_ppiPOOccurrence = NULL;
}

UnschedCoreComputer::~UnschedCoreComputer()
{
	int iTaskNum = m_pcTaskSet->getTaskNum();
	if (m_ppiPOOccurrence)
	{
		for (int i = 0; i < iTaskNum; i++)
		{
			delete m_ppiPOOccurrence[i];
		}
	}
	delete m_ppiPOOccurrence;

}

void UnschedCoreComputer::Initialize(TaskSet & rcTaskSet)
{
	m_dTimeOnSchedTest = 0;
	m_dTimeOnIsSchedulable = 0;
	m_dTimeOnQuickSchedTest = 0;
	m_dTimeOnQuickSchedTest_Hit = 0;
	m_dTimeOnQuickSchedTest_Miss = 0;
	m_iQuickSchedTestInsertions = 0;
	m_pcTaskSet = &rcTaskSet;
	int iTaskNum = rcTaskSet.getTaskNum();
	m_ppiPOOccurrence = new int *[iTaskNum];
	for (int i = 0; i < iTaskNum; i++)
	{
		m_ppiPOOccurrence[i] = new int[iTaskNum];
		memset(m_ppiPOOccurrence[i], 0, iTaskNum * sizeof(int));
	}
	m_cPOOccurrenceSort = MySet<PriorityPOElement, PriorityPOOccurrenceComp>(PriorityPOOccurrenceComp(m_ppiPOOccurrence));
	m_enumSchedTestOption = SchedulabilityTestOption::SchedTest_Original;
	m_enumSortingOption = None;
	m_enumUnschedCoreOption = UCOpt_Original;

	m_vectorSystemFeaHPBitMaskNLH.reserve(iTaskNum);
	m_vectorSystemInfeaHPBitMaskNLH.reserve(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		//cout << "Hi" << endl;
		m_vectorSystemFeaHPBitMaskNLH.push_back(BitMaskStorage_N_LowestSet());
		m_vectorSystemInfeaHPBitMaskNLH.push_back(BitMaskStorage_N_LowestSet());
		m_vectorSystemFeaHPBitMaskNLH.back().Initialize(iTaskNum);
		m_vectorSystemInfeaHPBitMaskNLH.back().Initialize(iTaskNum);
		//cout << "Hi" << endl;
	}

	//cout << "Initialization Complete" << endl;;
}

void UnschedCoreComputer::setLowestPriority(int iTaskIndex, int iPriority)
{
	assert(iPriority < m_pcTaskSet->getTaskNum());
	m_vectorLowestFeasiblePriority[iTaskIndex] = iPriority;
}

bool UnschedCoreComputer::ConvertToUC(PriorityPOSet & rcPriorityPOSet,
	PriorityPOSet & rcFixedPOSet, PriorityPOSet & rcCore)
{
	bool bStatus = false;
	PriorityPOSet cHinderingPOs;
	TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	if (IsSchedulable(rcPriorityPOSet, rcFixedPOSet, cPriorityAssignment, cHinderingPOs))
		return false;		
	switch (m_enumUnschedCoreOption)
	{
	case UCOpt_Original:
		bStatus = doConvertToUC_v0(rcPriorityPOSet, rcFixedPOSet, rcCore);
		break;
	case UCOpt_HinderingPPO:
		bStatus = doConvertToUC_v1(rcPriorityPOSet, rcFixedPOSet, rcCore);
		break;
	case UCOpt_BinGrouping:
		bStatus = doConvertToUC_v2(rcPriorityPOSet, rcFixedPOSet, rcCore);
		break;
	case UCOpt_QuickPPOSched:
		bStatus = doConvertToUC_v3(rcPriorityPOSet, rcFixedPOSet, rcCore);
		break;
	case UCOpt_ReusedLowestAssigned:
		bStatus = doConvertToUC_v4(rcPriorityPOSet, rcFixedPOSet, rcCore);
		break;
	default:
		cout << "Unknown Unsched Core Computation Algorithm Option" << endl;
		while (1);
		break;
	}	
	return bStatus;
}

bool UnschedCoreComputer::doConvertToUC_v0(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore)
{
	rcCore = rcPriorityPOSet;
	TaskSetPriorityStruct rcDummyPA(*m_pcTaskSet);	
	bool bStatus = ConvertToUC_Primitive(rcCore, rcFixedPOSet);
	return bStatus;
}


bool UnschedCoreComputer::doConvertToUC_v1(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore)
{
	TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	PriorityPOSet cRefinedSet = rcPriorityPOSet;
	PriorityPOSet cHinderingPOs;
	if (IsSchedulable(rcPriorityPOSet, rcFixedPOSet, cPriorityAssignment, cHinderingPOs))
		return false;
	PriorityPOSetOccurSort cHinderingPOOccurSort = CreatePOOccurSort();
	ConvertToOccurSort(cHinderingPOs, cHinderingPOOccurSort);
	rcCore.clear();
	while (1)
	{
		bool bExit = false;
		//for (PriorityPOSet::iterator iter = cHinderingPOs.begin(); iter != cHinderingPOs.end();)
		for (PriorityPOSetOccurSort::iterator iter = cHinderingPOOccurSort.begin(); iter != cHinderingPOOccurSort.end();)
		{
			PriorityPOElement cPOElement = *iter;
			iter++;
			assert(cRefinedSet.count(cPOElement));
			cRefinedSet.erase(cPOElement);
			cHinderingPOOccurSort.erase(cPOElement);
			TaskSetPriorityStruct cPriorityAssignmentThis = cPriorityAssignment;
			PriorityPOSet cThisHinderingPOs;
			bool bStatus = IsSchedulable(cRefinedSet, rcFixedPOSet, cPriorityAssignmentThis, cThisHinderingPOs);
			if (bStatus)
			{
				cRefinedSet.insert(cPOElement);
				cHinderingPOOccurSort.insert(cPOElement);
			}
			else
			{
				//cHinderingPOs = cThisHinderingPOs;
				cHinderingPOOccurSort.clear();
				ConvertToOccurSort(cThisHinderingPOs, cHinderingPOOccurSort);
				cPriorityAssignment = cPriorityAssignmentThis;
				if (cHinderingPOOccurSort.size() == 0)
				{
					cout << "Hindering set empty" << endl;
					cout << "Algorithmic error" << endl;
					while (1);
				}
				break;
			}



			if (iter == cHinderingPOOccurSort.end())
				bExit = true;
		}
		if (bExit)
			break;
	}
	//rcCore = cHinderingPOOccurSort.getSetContent();
	rcCore.clear();
	ConvertToOriginal(cHinderingPOOccurSort, rcCore);
	return true;
}

bool UnschedCoreComputer::doIsSchedulable_v1(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
	TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	Task ** ppcTaskArrayByPeriod = m_pcTaskSet->getTaskArrayByPeriosPtr();
	TaskSetPriorityStruct & cPriorityAssignment = rcPriorityAssignment;
	int iPriority = iTaskNum - 1;
	int iPreAssignedSize = cPriorityAssignment.getSize();	
	for (; iPriority >= 0; iPriority--)
	{
		bool bAssigned = false;
		rcHinderingPOs.clear();
		if (rcPriorityAssignment.getTaskByPriority(iPriority) != -1)
		{
			continue;
		}
		for (int i = 0; i < iTaskNum; i++)
		{
			int iCand = ppcTaskArrayByPeriod[iTaskNum - i - 1]->getTaskIndex();

			if ((cPriorityAssignment.getPriorityByTask(iCand) != -1))
				continue;

			int iLPTask = IsPOBurden(iCand, cPriorityAssignment, rcFixedPOSet);
			if (iLPTask != -1)	continue;

			iLPTask = IsPOBurden(iCand, cPriorityAssignment, rcPriorityPOSet);
			if (iLPTask != -1)
			{
				rcHinderingPOs.insert(PriorityPOElement(iCand, iLPTask));
				continue;
			}

			cPriorityAssignment.setPriority(iCand, iPriority);
			PreSchedTest(iCand, rcPriorityAssignment, rcPriorityPOSet, rcFixedPOSet);
			if (SchedTestWrapper(iCand, cPriorityAssignment, m_pvSchedTestData))
			{
				bAssigned = true;
				break;
			}
			else
			{
				bAssigned = false;				
				cPriorityAssignment.unset(iCand);
			}
		}

		if (!bAssigned)
		{
			return false;
		}
	}
	return true;
}

bool UnschedCoreComputer::doIsSchedulable_v4(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
	TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs)
{
	//cout << "Schedulable Start" << endl;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	Task ** ppcTaskArrayByPeriod = m_pcTaskSet->getTaskArrayByPeriosPtr();
	TaskSetPriorityStruct & cPriorityAssignment = rcPriorityAssignment;
	int iPriority = iTaskNum - 1;
	int iPreAssignedSize = cPriorityAssignment.getSize();
	for (; iPriority >= 0; iPriority--)
	{
		bool bAssigned = false;
		rcHinderingPOs.clear();
		if (rcPriorityAssignment.getTaskByPriority(iPriority) != -1)
		{
			continue;
		}

		deque< std::pair<int, BitMask> > dequeNeedtoTest;
		for (int i = 0; i < iTaskNum; i++)
		{
			int iCand = ppcTaskArrayByPeriod[iTaskNum - i - 1]->getTaskIndex();

			if ((cPriorityAssignment.getPriorityByTask(iCand) != -1))
				continue;

			int iLPTask = IsPOBurden(iCand, cPriorityAssignment, rcFixedPOSet);
			if (iLPTask != -1)	continue;

			iLPTask = IsPOBurden(iCand, cPriorityAssignment, rcPriorityPOSet);
			if (iLPTask != -1)
			{
				rcHinderingPOs.insert(PriorityPOElement(iCand, iLPTask));
				continue;
			}

			cPriorityAssignment.setPriority(iCand, iPriority);
			Timer cTimer; cTimer.Start();
			BitMask cHPEncoding = HPSetsToBitMask(iCand, cPriorityAssignment);
			cHPEncoding.ConstructBitMaskData();		
			//cout << "quick start" << endl;
			int iQuickTestStatus = QuickSchedTest_Forv4(iCand, cHPEncoding);			
			//cout << iQuickTestStatus << endl;
			//cout << "quick end" << endl;
			cTimer.Stop();
			m_dTimeOnQuickSchedTest += cTimer.getElapsedTime_ms();

			if (iQuickTestStatus == 1)
			{
				bAssigned = true;
				m_dTimeOnQuickSchedTest_Hit += cTimer.getElapsedTime_ms();
				break;
			}
			else if (iQuickTestStatus == 0)
			{
				bAssigned = false;
				m_dTimeOnQuickSchedTest_Hit += cTimer.getElapsedTime_ms();
				cPriorityAssignment.unset(iCand);
			}
			else if (iQuickTestStatus == -1)
			{
				m_dTimeOnQuickSchedTest_Miss += cTimer.getElapsedTime_ms();
				dequeNeedtoTest.push_back({ iCand, cHPEncoding });
				cPriorityAssignment.unset(iCand);
			}
		}

		if (!bAssigned)
		{
			for (deque< std::pair<int, BitMask> >::iterator iter = dequeNeedtoTest.begin(); iter != dequeNeedtoTest.end(); iter++)
			{
				int iCand = iter->first;
				cPriorityAssignment.setPriority(iCand, iPriority);
				BitMask & cHPEncoding = iter->second;				
				if (SchedTestWrapper(iCand, cPriorityAssignment, m_pvSchedTestData))
				{					
					bAssigned = true;	
					bool bInsert = PreInsertPAEncoding(iCand, true, cHPEncoding);
					if (bInsert)
						m_vectorSystemFeaHPBitMaskNLH[iCand].Insert(cHPEncoding);
					m_iQuickSchedTestInsertions++;
					break;
				}
				else
				{					
					bAssigned = false;	
					bool bInsert = PreInsertPAEncoding(iCand, false , cHPEncoding);
					if (bInsert)
						m_vectorSystemInfeaHPBitMaskNLH[iCand].Insert(cHPEncoding);
					m_iQuickSchedTestInsertions++;
					cPriorityAssignment.unset(iCand);
				}
			}
		}

		if (!bAssigned)
		{
			//cout << "Schedulable End" << endl;
			return false;
		}
	}
	//cout << "Schedulable End" << endl;
	return true;
}

bool UnschedCoreComputer::IsSchedulable(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet,
	TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs)
{
	Timer cTimer;
	cTimer.Start();
	bool bStatus = false;
	switch (m_enumSchedTestOption)
	{
	case SchedulabilityTestOption::SchedTest_LookUpTable:
		bStatus = doIsSchedulable_v4(rcPriorityPOSet, rcFixedPOSet, rcPriorityAssignment, rcHinderingPOs);
		break;
	case SchedulabilityTestOption::SchedTest_Original:
		bStatus = doIsSchedulable_v1(rcPriorityPOSet, rcFixedPOSet, rcPriorityAssignment, rcHinderingPOs);
		break;
	default:
		assert(false);
		break;
	}	
	cTimer.Stop();
	m_dTimeOnIsSchedulable += cTimer.getElapsedTime_ms();
	return bStatus;
}

int UnschedCoreComputer::IsPOBurden(int iTaskIndex,
	TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPriorityPOSet)
{
	for (PriorityPOSet::iterator iter = rcPriorityPOSet.begin(); iter != rcPriorityPOSet.end(); iter++)
	{
		if ((iter->m_iHPTask == iTaskIndex) && (rcPriorityAssignment.getPriorityByTask(iter->m_iLPTask) == -1))
		{
			return iter->m_iLPTask;
		}
	}
	return -1;
}

int UnschedCoreComputer::Recur(int iLevel, int iLimit, PriorityPOSet & rcPriorityPOSet,
	PriorityPOSet & rcFixedPOSet, UnschedCores & rdequeCollectedCores, double dTimeStart, double dTimeout)
{
	if ((double)time(NULL) - dTimeStart >= dTimeout)
		return 0;

	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if ((iLimit != -1) && (rdequeCollectedCores.size() >= iLimit))
		return 0;

	bool bNewMiniSet = false;
	if (rdequeCollectedCores.size() <= iLevel)
	{
		MySet<PriorityPOElement> setMiniSet;
		bNewMiniSet = ConvertToUC(rcPriorityPOSet, rcFixedPOSet, setMiniSet);
		if (bNewMiniSet)
		{
			if (m_enumSortingOption == ByOccurence)
			{
				UpdateOccurStat(setMiniSet);
			}
			rdequeCollectedCores.push_back(setMiniSet);
#if 0
			cout << "Core " << rdequeCollectedCores.size() << ": ";
			PrintSetContent(rdequeCollectedCores.back().getSetContent());
#endif
		}
		else
		{
			return 0;
		}
	}

	if (bNewMiniSet || rdequeCollectedCores.size() > iLevel)
	{
		MySet<PriorityPOElement> & rsetMiniSet = rdequeCollectedCores[iLevel];
		if (!(rcPriorityPOSet >= rsetMiniSet))
			return -1;
		for (MySet<PriorityPOElement>::iterator iter = rsetMiniSet.begin(); iter != rsetMiniSet.end(); iter++)
		{
			PriorityPOElement iPOEle = *iter;
			assert(rcPriorityPOSet.count(iPOEle));
			rcPriorityPOSet.erase(iPOEle);
			int iNextLevel = iLevel + 1;
			int iStatus = Recur(iNextLevel, iLimit, rcPriorityPOSet, rcFixedPOSet, rdequeCollectedCores, dTimeStart, dTimeout);
			while (iStatus == -1)
			{
				iNextLevel++;
				iStatus = Recur(iNextLevel, iLimit, rcPriorityPOSet, rcFixedPOSet, rdequeCollectedCores, dTimeStart, dTimeout);
			}
			rcPriorityPOSet.insert(iPOEle);
		}
	}
	return 0;
}

bool UnschedCoreComputer::SchedTestWrapper(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData)
{
	m_iSchedTestCall++;
	Timer cTimer;
	cTimer.Start();	
	bool bStatus = SchedTest(iTaskIndex, rcPriorityAssignment, pvExtraData);
	cTimer.Stop();
	m_dTimeOnSchedTest += cTimer.getElapsedTime_ms();
	if (bStatus)
	{
		m_dTimeOnSchedulable += cTimer.getElapsedTime_ms();
	}
	else
	{
		m_dTimeOnUnschedulable += cTimer.getElapsedTime_ms();
	}
	return bStatus;
}

bool UnschedCoreComputer::SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
#if 1
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);	

	for (int i = 0; i < iTaskNum; i++)
	{
		int iPriority = rcPriorityAssignment.getPriorityByTask(i);
		if (iPriority == -1)
		{
			cRTCalc.setPrioirty(i, 0);
		}
		else
		{
			cRTCalc.setPrioirty(i, iPriority);
		}
	}
	return cRTCalc.CalcResponseTimeTask(iTaskIndex, RTCALC_LO) <= pcTaskArray[iTaskIndex].getDeadline();
#else
	_LORTCalculator cRTCalc(*m_pcTaskSet);
	return cRTCalc.CalculateRTTask(iTaskIndex, rcPriorityAssignment) <= pcTaskArray[iTaskIndex].getDeadline();
#endif
}

BitMask UnschedCoreComputer::HPSetsToBitMask(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iTargetTaskPriority = rcPriorityAssignment.getPriorityByTask(iTaskIndex);
	assert(iTargetTaskPriority != -1);
	BitMask cBitMask(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)	continue;
		if (rcPriorityAssignment.getPriorityByTask(i) < iTargetTaskPriority)
		{
			cBitMask.setBit(i, 1);
		}
	}
	return cBitMask;
}

void UnschedCoreComputer::getHPSet(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, MySet<int> & rcHPSet)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iTargetTaskPriority = rcPriorityAssignment.getPriorityByTask(iTaskIndex);
	assert(iTargetTaskPriority != -1);
	BitMask cBitMask(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)	continue;
		if (rcPriorityAssignment.getPriorityByTask(i) < iTargetTaskPriority)
		{
			rcHPSet.insert(i);
		}
	}
}

int UnschedCoreComputer::QuickSchedTest_Forv4(int iTaskIndex, BitMask & rcHPSets)
{	
	if (m_vectorSystemFeaHPBitMaskNLH[iTaskIndex].Find(rcHPSets))
		return 1;
	if (m_vectorSystemInfeaHPBitMaskNLH[iTaskIndex].Find(rcHPSets))
		return 0;	
	int iNAttempts = 0;
	//int iLimit = m_vectorSystemFeaHPBitMaskNLH[iTaskIndex].SupsetHeuristicLimit();
	if (m_vectorSystemFeaHPBitMaskNLH[iTaskIndex].ExistSupSet(rcHPSets, &iNAttempts))
	{
		m_dequeQuickSchedTestSupSetSearchHitNAttempts.push_back({ iNAttempts, m_vectorSystemFeaHPBitMaskNLH[iTaskIndex].getSize() });
		return 1;
	}		
	iNAttempts = 0;
	//iLimit = m_vectorSystemInfeaHPBitMaskNLH[iTaskIndex].SubsetHeuristicLimit();
	if (m_vectorSystemInfeaHPBitMaskNLH[iTaskIndex].ExistSubSet(rcHPSets, &iNAttempts))
	{	
		m_dequeQuickSchedTestSubSetSearchHitNAttempts.push_back({ iNAttempts, m_vectorSystemInfeaHPBitMaskNLH[iTaskIndex].getSize() });
		return 0;
	}	
	return -1;
}

void UnschedCoreComputer::IncPOOccurrence(int iHPTask, int iLPTask)
{
	int iPrev = m_ppiPOOccurrence[iHPTask][iLPTask];
	m_cPOOccurrenceSort.erase(PriorityPOElement(iHPTask, iLPTask));
	m_ppiPOOccurrence[iHPTask][iLPTask]++;
	m_cPOOccurrenceSort.insert(PriorityPOElement(iHPTask, iLPTask));
}

void UnschedCoreComputer::UpdateOccurStat(PriorityPOSet & rcCores)
{
	for (PriorityPOSet::iterator iter = rcCores.begin(); iter != rcCores.end(); iter++)
	{
		IncPOOccurrence(iter->m_iHPTask, iter->m_iLPTask);
	}
}

void UnschedCoreComputer::RemoveHighFreqPO(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedSet)
{
	TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	PriorityPOSet cHinderingPOs;
	bool bStatus = IsSchedulable(rcPriorityPOSet, rcFixedSet, cPriorityAssignment, cHinderingPOs);
	assert(!bStatus);
	for (PriorityPOSetOccurSort::iterator iter = m_cPOOccurrenceSort.begin(); iter != m_cPOOccurrenceSort.end(); iter++)
	{		
		if (rcPriorityPOSet.count(*iter) == 0) continue;

		TaskSetPriorityStruct cThisPriorityAssignment;
		rcPriorityPOSet.erase(*iter);

		bool bSchedStat = IsSchedulable(rcPriorityPOSet, rcFixedSet, cThisPriorityAssignment, cHinderingPOs);

		if (bSchedStat)
		{
			rcPriorityPOSet.insert(*iter);
		}
		else
		{
			cPriorityAssignment = cThisPriorityAssignment;
			rcPriorityPOSet = cHinderingPOs;
		}
	}
}

UnschedCoreComputer::PriorityPOSetOccurSort UnschedCoreComputer::CreatePOOccurSort()
{
	return PriorityPOSetOccurSort(PriorityPOOccurrenceComp(m_ppiPOOccurrence));
}

void UnschedCoreComputer::ConvertToOccurSort(PriorityPOSet & rcPriorityPOSet, PriorityPOSetOccurSort & rcPOByOccurrence)
{	
	for (PriorityPOSet::iterator iter = rcPriorityPOSet.begin(); iter != rcPriorityPOSet.end(); iter++)
	{
		rcPOByOccurrence.insert(*iter);
	}
	assert(rcPriorityPOSet.size() == rcPOByOccurrence.size());
}

void UnschedCoreComputer::ConvertToOriginal(PriorityPOSetOccurSort & rcPOByOccurrence, PriorityPOSet & rcPriorityPOSet)
{
	for (PriorityPOSetOccurSort::iterator iter = rcPOByOccurrence.begin(); iter != rcPOByOccurrence.end(); iter++)
	{
		rcPriorityPOSet.insert(*iter);
	}
	assert(rcPriorityPOSet.size() == rcPOByOccurrence.size());
}

int UnschedCoreComputer::ComputeUnschedCores(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, UnschedCores & rcUnschedCores, int iLimit, double dTimeout)
{	
	assert(m_pcTaskSet);	
#if 1
	assert(m_ppiPOOccurrence);
	for (PriorityPOSet::iterator iter = rcPriorityPOSet.begin();
		iter != rcPriorityPOSet.end(); iter++)
	{		
		m_ppiPOOccurrence[iter->m_iHPTask][iter->m_iLPTask] = 0;
	}
#endif			
	int iIniSize = rcUnschedCores.size();
	int iNextLevel = 0;	
	int iStatus = Recur(iNextLevel, iLimit, rcPriorityPOSet, rcFixedPOSet, rcUnschedCores, time(NULL), dTimeout);
	while (iStatus == -1)
	{
		iNextLevel++;
		iStatus = Recur(iNextLevel, iLimit, rcPriorityPOSet, rcFixedPOSet, rcUnschedCores, time(NULL), dTimeout);
	}		
	int iSize = rcUnschedCores.size();
	for (int i = 0; i < iSize; i++)
	{
		m_cCollectedCores.push_back(rcUnschedCores[i]);
	}		
	return rcUnschedCores.size() - iIniSize;	
}

bool UnschedCoreComputer::IsSchedulable()
{
	assert(m_pcTaskSet);
	TaskSetPriorityStruct cPriorityAssignment;
	PriorityPOSet cDummy;
	PriorityPOSet cDummyHindering;
	return IsSchedulable(cDummy, cDummy, cPriorityAssignment, cDummyHindering);
}

bool UnschedCoreComputer::IsSchedulable(TaskSetPriorityStruct & rcPriorityAssignment)
{
	assert(m_pcTaskSet);
	PriorityPOSet cDummy;
	PriorityPOSet cDummyHindering;
	return IsSchedulable(cDummy, cDummy, rcPriorityAssignment, cDummyHindering);
}

bool UnschedCoreComputer::IsSchedulable(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment)
{
	assert(m_pcTaskSet);
	if (m_enumSchedTestOption == SchedTest_LookUpTable)
	{
		BitMask cHPEncoding = HPSetsToBitMask(iTaskIndex, rcPriorityAssignment);
		cHPEncoding.ConstructBitMaskData();
		//cout << "quick start" << endl;
		int iQuickTestStatus = QuickSchedTest_Forv4(iTaskIndex, cHPEncoding);
		if (iQuickTestStatus == 1)
		{
			return true;
		}
		else if (iQuickTestStatus == 0)
		{
			return false;
		}		

		bool bSchedStatus = SchedTestWrapper(iTaskIndex, rcPriorityAssignment, m_pvSchedTestData);
		if (bSchedStatus)
		{
			m_vectorSystemFeaHPBitMaskNLH[iTaskIndex].Insert(cHPEncoding);
			m_iQuickSchedTestInsertions++;
			return true;
		}
		else
		{
			m_vectorSystemInfeaHPBitMaskNLH[iTaskIndex].Insert(cHPEncoding);
			m_iQuickSchedTestInsertions++;
			return false;
		}
	}
	else
	{
		return  SchedTestWrapper(iTaskIndex, rcPriorityAssignment, m_pvSchedTestData);
	}	
}

bool UnschedCoreComputer::IsSchedulable(TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet)
{
	assert(m_pcTaskSet);
	PriorityPOSet cDummy;
	PriorityPOSet cDummyHindering;
	return IsSchedulable(rcPPOSet, cDummy, rcPriorityAssignment, cDummyHindering);
}

void UnschedCoreComputer::ComputeAllCores(UnschedCores & rcUnschedCores)
{
	int iTaskNum = m_pcTaskSet->getTaskNum();
	PriorityPOSet cCompletePPOSet;
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = 0; j < iTaskNum; j++)
		{
			if (i == j) continue;
			cCompletePPOSet.insert(PriorityPOElement(i, j));
		}
	}
	PriorityPOSet cDummy;
	ComputeUnschedCores(cCompletePPOSet, cDummy, rcUnschedCores, -1);
}

void UnschedCoreComputer::WriteUnschedCoreToFile(char axFileName[], UnschedCores & rcUnschedCores)
{
	ofstream ofstreamOut(axFileName, ios::out | ios::binary);
	int iTotalCoreNum = rcUnschedCores.size();
	ofstreamOut.write((const char *)&iTotalCoreNum, sizeof(int));
	for (int i = 0; i < iTotalCoreNum; i++)
	{
		PriorityPOSet & rcPPOSet = rcUnschedCores[i];
		int iCoreSize = rcPPOSet.size();
		ofstreamOut.write((const char *)&iCoreSize, sizeof(int));
		for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end(); iter++)
		{
			int iHPTask = iter->m_iHPTask;
			int iLPTask = iter->m_iLPTask;
			ofstreamOut.write((const char *)&iHPTask, sizeof(int));
			ofstreamOut.write((const char *)&iLPTask, sizeof(int));
		}
	}
	ofstreamOut.close();
}

void UnschedCoreComputer::ReadUnschedCoreFromFile(char axFileName[], UnschedCores & rcUnschedCores)
{
	ifstream ifstreamIn(axFileName, ios::in | ios::binary);
	my_assert(ifstreamIn.is_open(), "Cannot Find UnschedCoer File");
	int iTotalCoreNum = 0;	
	ifstreamIn.read((char *)&iTotalCoreNum, sizeof(int));
	for (int i = 0; i < iTotalCoreNum; i++)
	{
		PriorityPOSet cPPOSet;
		int iCoreSize = 0;
		ifstreamIn.read((char *)&iCoreSize, sizeof(int));
		for (int i = 0; i < iCoreSize; i++)
		{
			int iHPTask = 0;
			int iLPTask = 0;
			ifstreamIn.read((char *)&iHPTask, sizeof(int));
			ifstreamIn.read((char *)&iLPTask, sizeof(int));
			cPPOSet.insert(PriorityPOElement(iHPTask, iLPTask));
		}
		rcUnschedCores.push_back(cPPOSet);
	}
	ifstreamIn.close();		
}

void UnschedCoreComputer::PrintStatistic(const char axFileName[])
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	StatisticSet cStatistic;
	char axBuffer[512] = { 0 };


	cStatistic.setItem("Time on SchedTest Calls", m_dTimeOnSchedTest);
	cStatistic.setItem("Time on IsSchedulable Calls", m_dTimeOnIsSchedulable);
	cStatistic.setItem("Time on QuickSchedTest Calls", m_dTimeOnQuickSchedTest);
	cStatistic.WriteStatisticText((char *)axFileName);
}

void UnschedCoreComputer::CondenseCores(UnschedCores & rcOrginalCores, 
	UnschedCores & rcCondensedCores, IntSetDeque & rdequeMapping, MySet<int> & rsetIndices, int iCondensedDegree)
{
	int iUnschedCoreSize = rcOrginalCores.size();
	int * piStatusTable = new int[iUnschedCoreSize];
	memset(piStatusTable, 0, iUnschedCoreSize * sizeof(int));
	int iLeft = rsetIndices.size();
	while (1)
	{
		rcCondensedCores.push_back(PriorityPOSet());
		rdequeMapping.push_back(MySet<int>());
		PriorityPOSet & rcThisCore = rcCondensedCores.back();
		MySet<int> & rcThisMap = rdequeMapping.back();
		//for (int i = 0; i < iUnschedCoreSize; i++)
		for (MySet<int>::iterator iter = rsetIndices.begin(); iter != rsetIndices.end(); iter++)
		{
			int i = *iter;
			if (piStatusTable[i] == 0)
			{
				rcThisCore = rcOrginalCores[i];
				rcThisMap.insert(i);
				break;
			}
		}

		//for (int i = iStart; i <= iEnd; i++)
		for (MySet<int>::iterator iter = rsetIndices.begin(); iter != rsetIndices.end(); iter++)
		{
			int i = *iter;
			if (piStatusTable[i] == 1)	continue;
		
			if (rcThisCore.IsIntersect(rcOrginalCores[i]))
			{
				rcThisCore *= rcOrginalCores[i];
				piStatusTable[i] = 1;
				rcThisMap.insert(i);
				iLeft--;
			}			

			if ((iCondensedDegree != -1) && (rcThisMap.size() >= iCondensedDegree))
			{
				break;
			}
		}

		if (iLeft == 0)
			break;
	}

	delete piStatusTable;
}

void UnschedCoreComputer::FindLimitingCore(PriorityPOSet & rcPPOSet, UnschedCores & rcCores, MySet<int> & rsetIndices)
{
	int iCoreIndex = 0;
	for (UnschedCores::iterator iter = rcCores.begin(); iter != rcCores.end(); iter++)
	{
		if ((rcPPOSet * (*iter)).size() == iter->size() - 1)
		{
			rsetIndices.insert(iter - rcCores.begin());
		}
	}
}

void UnschedCoreComputer::RemoveRedundantPPO(PriorityPOSet & rcPPOSet)
{
	TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	IsSchedulable(cPriorityAssignment, rcPPOSet);
	
	for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end();)
	{
		PriorityPOSet::iterator iterTemp = iter;
		iter++;
		int iHP = iterTemp->m_iHPTask;
		int iLP = iterTemp->m_iLPTask;
		int iHPPri = cPriorityAssignment.getPriorityByTask(iHP);
		int iLPPri = cPriorityAssignment.getPriorityByTask(iLP);
		if ((iLPPri != -1) && (iLPPri > iHPPri))
			rcPPOSet.erase(iterTemp);
	}
}

//Hopefully Fast Unsched-core Computation
bool UnschedCoreComputer::doConvertToUC_v2(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore)
{
	//int iBlockSize = max(1, ceil((double)rcPriorityPOSet.size() / 2.0));	
	int iBlockSize = max(1, rcPriorityPOSet.size() / 2);
	rcCore = rcPriorityPOSet;
	TaskSetPriorityStruct cUnschedPriorityAssignment(*m_pcTaskSet);
	for (int i = 0; i < 1; i++)
	{						
		bool bStatus = ConvertToUC_VarSizeGrouping(rcCore, rcFixedPOSet, iBlockSize, cUnschedPriorityAssignment);
		if (!bStatus)
		{
			cout << "You want a unscheulability core from a schedulable PPO set ?" << endl;
			my_assert(0, "");
		}

		if (iBlockSize == 1)
		{
			return true;
		}
		iBlockSize = iBlockSize / 2;
	}
	bool bStatus = ConvertToUC_VarSizeGrouping(rcCore, rcFixedPOSet, 1, cUnschedPriorityAssignment);
	return true;
}

bool UnschedCoreComputer::ConvertToUC_Primitive(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet)
{
	TaskSetPriorityStruct  cUnschedPA(*m_pcTaskSet);
	PriorityPOSet cHinderingPPO = rcPPOSet;
//	PrintSetContent(rcPPOSet.getSetContent());	
	for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end();)
	{		
		if (iter == rcPPOSet.end()) break;
		PriorityPOSet::iterator iterTemp = iter;
		iter++;
		PriorityPOElement cThisElement = *iterTemp;		
		rcPPOSet.erase(cThisElement);
		//cout << "-------------------------------" << endl;
		//PrintSetContent(rcPPOSet.getSetContent());
		//cUnschedPA.Print();
		if (cUnschedPA.getPriorityByTask(cThisElement.m_iLPTask) != -1)
		{
			//cout << "Quick Remove: " << cThisElement << endl;
			//cout << "LP P: " << cUnschedPA.getPriorityByTask(cThisElement.m_iLPTask) << endl;
//			continue;
		}

		TaskSetPriorityStruct cThisPA(*m_pcTaskSet);
		//cThisPA.CopyFrom_Strict(cUnschedPA);

		if (IsSchedulable(rcPPOSet, rcFixedPOSet, cThisPA, cHinderingPPO))
		{			
			//put back
			rcPPOSet.insert(cThisElement);
		}
		else
		{			
			cUnschedPA.CopyFrom_Strict(cThisPA);
		}
	}
	if (rcPPOSet.empty())
	{
		my_assert(false, "Empty unschedulability core. Shouldn't happen when system is schedulable");
	}

	return true;
}

bool UnschedCoreComputer::ConvertToUC_VarSizeGrouping(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet, int iBlockSize, TaskSetPriorityStruct & rcPA)
{
	TaskSetPriorityStruct & cUnschedPA = rcPA;	
	for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end();)
	{
		PriorityPOSet cCurrentBlock;

		for (int i = 0; i < iBlockSize; i++)
		{
			if (iter == rcPPOSet.end()) break;
			PriorityPOSet::iterator iterTemp = iter;
			iter++;
			cCurrentBlock.insert(*iterTemp);
			rcPPOSet.erase(iterTemp);
		}
		TaskSetPriorityStruct cThisPA(*m_pcTaskSet);
		cThisPA.CopyFrom_Strict(cUnschedPA);
		PriorityPOSet cDummy;
		if (IsSchedulable(rcPPOSet, rcFixedPOSet, cThisPA, cDummy))
		{
			//put back
			for (PriorityPOSet::iterator iterBlock = cCurrentBlock.begin(); iterBlock != cCurrentBlock.end(); iterBlock++)
			{
				rcPPOSet.insert(*iterBlock);
			}
		}
		else
		{
			cUnschedPA.CopyFrom_Strict(cThisPA);
		}		
	}
	if (rcPPOSet.empty())
	{
		my_assert(false, "Empty unschedulability core. Shouldn't happen when system is schedulable");
	}

	return true;
}

//PPO Level Quick Sched Test

void UnschedCoreComputer::setPPORange(PriorityPOSet & rcRange)
{
	m_cPPORange.clear();
	for (PriorityPOSet::iterator iter = rcRange.begin(); iter != rcRange.end(); iter++)
	{
		int iTaskA = iter->m_iHPTask;
		int iTaskB = iter->m_iLPTask;
		m_cPPORange.insert({ iTaskA, iTaskB });
		m_cPPORange.insert({ iTaskB, iTaskA });
	}
	m_vectorPPORangeSequence.clear();
	m_vectorPPORangeSequence.reserve(m_cPPORange.size());
	int iIndex = 0;
	for (PriorityPOSet::iterator iter = m_cPPORange.begin(); iter != m_cPPORange.end(); iter++)
	{
		m_mapPPOToIndex[*iter] = iIndex;
		m_vectorPPORangeSequence.push_back(*iter);
		iIndex++;
	}
	m_cPPOSchedEncoding.Initialize(m_cPPORange.size());
	m_cPPOUnschedEncoding.Initialize(m_cPPORange.size());
}

BitMask UnschedCoreComputer::EncodePPOtoBitMask(PriorityPOSet & rcPPOSet)
{
	int iSize = m_cPPORange.size();
	BitMask cBitMask(iSize);
	for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end(); iter++)
	{
		cBitMask.setBit(m_mapPPOToIndex[*iter], 1);
	}
	return cBitMask;
}

void UnschedCoreComputer::DecodeBitMasktoPPO(BitMask & rcBitMask, PriorityPOSet & rcPPOSet)
{
	int iIndex = 0;
	for (PriorityPOSet::iterator iter = m_cPPORange.begin(); iter != m_cPPORange.end(); iter++)
	{
		if (rcBitMask.getBit(iIndex) == 1)
		{
			rcPPOSet.insert(*iter);
		}
		iIndex++;
	}
}

void UnschedCoreComputer::ConvertPAToPPOInRange(TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet)
{
	rcPPOSet.clear();
	for (PriorityPOSet::iterator iter = m_cPPORange.begin(); iter != m_cPPORange.end(); iter++)
	{
		if (rcPriorityAssignment.getPriorityByTask(iter->m_iHPTask) < rcPriorityAssignment.getPriorityByTask(iter->m_iLPTask))
		{
			rcPPOSet.insert(*iter);
		}
	}
}

int UnschedCoreComputer::QuickPPOSchedTest(BitMask & rcPPOSetEncoding)
{
	if (m_cPPOSchedEncoding.ExistSupSet(rcPPOSetEncoding))
	{		
		return 1;
	}
	else if (m_cPPOUnschedEncoding.ExistSubSet(rcPPOSetEncoding))
	{
		return 0;
	}
	else
	{
		return -1;
	}
}

bool UnschedCoreComputer::ConvertToUC_QuickPPOSchedTest(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet)
{
	TaskSetPriorityStruct  cUnschedPA(*m_pcTaskSet);
	BitMask cPPOEncoding = EncodePPOtoBitMask(rcPPOSet);
	PriorityPOSet cHinderingPPO = rcPPOSet;
#if 0
	BitMask cSmallerUnsched;
	while (m_cPPOUnschedEncoding.ExistProperSubSet(cPPOEncoding))
	{
		cPPOEncoding = m_cPPOUnschedEncoding.m_cSupSubSetQueryCertificate;
	}
	rcPPOSet.clear();
	DecodeBitMasktoPPO(cPPOEncoding, rcPPOSet);
#endif
	for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end();)
	{		
		if (iter == rcPPOSet.end()) break;
		PriorityPOSet::iterator iterTemp = iter;
		iter++;
		PriorityPOElement cThisElement = *iterTemp;		
		rcPPOSet.erase(iterTemp);		
		cPPOEncoding.setBit(m_mapPPOToIndex[cThisElement], 0);

		TaskSetPriorityStruct cThisPA(*m_pcTaskSet);
		cThisPA.CopyFrom_Strict(cUnschedPA);
		PriorityPOSet cDummy;		
		cPPOEncoding.ConstructBitMaskData();

		if (cUnschedPA.getPriorityByTask(cThisElement.m_iLPTask) != -1)
		{			
			continue;
		}

		if (m_cPPOSchedEncoding.ExistSupSet(cPPOEncoding))
		{
			//put back
			rcPPOSet.insert(cThisElement);
			cPPOEncoding.setBit(m_mapPPOToIndex[cThisElement], 1);
		}
		else
		{
			if (IsSchedulable(rcPPOSet, rcFixedPOSet, cThisPA, cHinderingPPO))
			{
				//put back
				rcPPOSet.insert(cThisElement);
				m_cPPOSchedEncoding.Insert(cPPOEncoding);
				cPPOEncoding.setBit(m_mapPPOToIndex[cThisElement], 1);
				PriorityPOSet cSchedPPOSet;
				ConvertPAToPPOInRange(cThisPA, cSchedPPOSet);
				BitMask cNew = EncodePPOtoBitMask(cSchedPPOSet);
				m_cPPOSchedEncoding.Insert(cNew);
			}			
			else
			{
				cUnschedPA.CopyFrom_Strict(cThisPA);
			}
		}

	
	}
	if (rcPPOSet.empty())
	{
		my_assert(false, "Empty unschedulability core. Shouldn't happen when system is schedulable");
	}

	return true;
}

bool UnschedCoreComputer::doConvertToUC_v3(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore)
{
	//int iBlockSize = max(1, ceil((double)rcPriorityPOSet.size() / 2.0));	
	int iBlockSize = max(1, rcPriorityPOSet.size() / 2);
	rcCore = rcPriorityPOSet;
	bool bStatus = ConvertToUC_QuickPPOSchedTest(rcCore, rcFixedPOSet);
	return bStatus;
}

bool UnschedCoreComputer::doConvertToUC_v4(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedPOSet, MySet<PriorityPOElement> & rcCore)
{
	TaskSetPriorityStruct  cUnschedPA(*m_pcTaskSet);
	rcCore = rcPPOSet;
	PriorityPOSet cHinderingPPO = rcCore;
	for (PriorityPOSet::iterator iter = rcCore.begin(); iter != rcCore.end();)
	{
		if (iter == rcCore.end()) break;
		PriorityPOSet::iterator iterTemp = iter;
		iter++;
		PriorityPOElement cThisElement = *iterTemp;
		rcCore.erase(iterTemp);
		TaskSetPriorityStruct cThisPA(*m_pcTaskSet);
		cThisPA.CopyFrom_Strict(cUnschedPA);		

		if (IsSchedulable(rcCore, rcFixedPOSet, cThisPA, cHinderingPPO))
		{
			//put back
			rcCore.insert(cThisElement);
		}
		else
		{
			cUnschedPA.CopyFrom_Strict(cThisPA);
		}
	}
	if (rcCore.empty())
	{
		my_assert(false, "Empty unschedulability core. Shouldn't happen when system is schedulable");
	}

	return true;
}

//AMC-max Unschedulability-core Computer
UnschedCoreComputer_AMCMax::UnschedCoreComputer_AMCMax()
{

}

UnschedCoreComputer_AMCMax::UnschedCoreComputer_AMCMax(TaskSet & rcTaskSet)
	: UnschedCoreComputer(rcTaskSet)
{

}

UnschedCoreComputer_AMCMax::~UnschedCoreComputer_AMCMax()
{

}

bool UnschedCoreComputer_AMCMax::SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData)
{	
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
#if 0
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);


	for (int i = 0; i < iTaskNum; i++)
	{
		int iPriority = rcPriorityAssignment.getPriorityByTask(i);
		if (iPriority == -1)
		{
			cRTCalc.setPrioirty(i, 0);
		}
		else
		{
			cRTCalc.setPrioirty(i, iPriority);
		}
	}
	return cRTCalc.CalcResponseTimeTask(iTaskIndex, RTCALC_AMCMAX) <= pcTaskArray[iTaskIndex].getDeadline();
#else
	_AMCMaxRTCalculator cRTCalc(*m_pcTaskSet);	
	//return cRTCalc.CalculateRTTask_MT(iTaskIndex, rcPriorityAssignment, 8) <= pcTaskArray[iTaskIndex].getDeadline();
	return cRTCalc.CalculateRTTask(iTaskIndex, rcPriorityAssignment) <= pcTaskArray[iTaskIndex].getDeadline();
#endif
}

//AMC-rtb Unschedulability-core Computer

UnschedCoreComputer_AMCRtb::UnschedCoreComputer_AMCRtb()
{

}

UnschedCoreComputer_AMCRtb::UnschedCoreComputer_AMCRtb(TaskSet & rcTaskSet)
	:UnschedCoreComputer(rcTaskSet)
{

}

UnschedCoreComputer_AMCRtb::~UnschedCoreComputer_AMCRtb()
{

}

bool UnschedCoreComputer_AMCRtb::SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	_AMCRtbRTCalculator cRTCalc(*m_pcTaskSet);
	return cRTCalc.CalculateRTTask(iTaskIndex, rcPriorityAssignment) <= pcTaskArray[iTaskIndex].getDeadline();
}
