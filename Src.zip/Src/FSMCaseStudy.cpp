#include "stdafx.h"
#include "FSMCaseStudy.h"
#include "ResponseTimeCalculator.h"
#include "StatisticSet.h"
#include "Timer.h"
#include <thread>
#include <mutex>
#include <RandomGenerator.h>
#include "GraphAlgorithms.h"
#include "AudsleyEngine.h"
#define ASSISTANT 0

void FSMTaskSet::ReadStateflow(char axFileName[])
{
	int iNum = 0;
	FileReader::DotFileReader(m_ppcStateFlows, iNum, 1, axFileName);
	if (iNum != m_iTaskNum)
	{
		cout << "Number of FSM implementation doesn't match number of tasks" << endl;
		while (1);
	}	
	BuildFSMData();
#if 1
	m_setTasks.clear();
	for (int i = 0; i < m_iTaskNum; i++)
	{
		Task cNewTask = m_pcTaskArray[i];
		cNewTask.setPeriod(m_ppcStateFlows[i]->gcd);
		AddTask(cNewTask);
	}
	ConstructTaskArray();
#endif
}

void FSMTaskSet::ReadRawStateflow(char axFileName[])
{
	int iNum = 0;
	FileReader::DotFileReader(m_ppcStateFlows, iNum, 1, axFileName);
	if (iNum != m_iTaskNum)
	{
		cout << "Number of FSM implementation doesn't match number of tasks" << endl;
		while (1);
	}

	for (int i = 0; i < m_iTaskNum; i++)
	{		
		Stateflow * sf = m_ppcStateFlows[i];
		sf->calculate_gcd();
		sf->calculate_t_gcd();
		sf->calculate_hyperperiod();
		sf->set_state_number();
	}

	//for (int i = 0; i < m_iTaskNum; i++)
		//SchedulabilityAnalysis::Richie_generate_critical_action_pair(m_ppcStateFlows, m_iTaskNum, i);
	m_vectorStateFlowMaxWCET.clear();
	for (int i = 0; i < m_iTaskNum; i++)
	{
		double dMaxWcet = 0;
		for (vector<Transition*>::iterator iter = m_ppcStateFlows[i]->trans.begin(); iter != m_ppcStateFlows[i]->trans.end(); iter++)
		{
			dMaxWcet = max((double)(*iter)->wcet, dMaxWcet);
		}
		m_vectorStateFlowMaxWCET.push_back(dMaxWcet);
	}
}

void FSMTaskSet::BuildFSMData()
{
	SchedulabilityAnalysis::Richie_prepare_all_stateflows(m_ppcStateFlows, m_iTaskNum);
	m_vectorStateFlowMaxWCET.clear();
	for (int i = 0; i < m_iTaskNum; i++)
	{
		double dMaxWcet = 0;
		for (vector<Transition*>::iterator iter = m_ppcStateFlows[i]->trans.begin(); iter != m_ppcStateFlows[i]->trans.end(); iter++)
		{
			dMaxWcet = max((double)(*iter)->wcet, dMaxWcet);
		}
		m_vectorStateFlowMaxWCET.push_back(dMaxWcet);
	}
}

Stateflow * FSMTaskSet::getFSM(int iTaskIndex)
{
	assert(iTaskIndex < m_iTaskNum);
	return m_ppcStateFlows[iTaskIndex];
}

double FSMTaskSet::getFSMMaxWCET(int iTaskIndex)
{
	assert(iTaskIndex < m_vectorStateFlowMaxWCET.size());
	return m_vectorStateFlowMaxWCET[iTaskIndex];
}

_FSMRBFSORTCalculator::_FSMRBFSORTCalculator(TaskSet & rcTaskSet)
{
	m_pcTaskSet = &rcTaskSet;
}

_FSMRBFSORTCalculator::_FSMRBFSORTCalculator()
{
	m_pcTaskSet = NULL;
}

double _FSMRBFSORTCalculator::CalculateRTTrans(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, Transition * pcTrans, int iStart, int iGCD)
{
	// calculate response times
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int total = 0;
	int f = iStart;
	int iThisPriority = rcPriorityAssignment.getPriorityByTask(iTaskIndex);
	while (true) {
		total = pcTrans->wcet;
#if 0
		for (int j = 0; j < index; j++) {
			Stateflow* sfj = sfs[j];
			double rbfj = sfj->get_rbf(s, f);
			total += rbfj;
		}
		if (total <= f - s) break;
		f += gcd;
#endif
		for (int i = 0; i < iTaskNum; i++)
		{
			if (i == iTaskIndex)
				continue;
			if (rcPriorityAssignment.getPriorityByTask(i) < iThisPriority)
			{
				Stateflow * pcStateFlow = ((FSMTaskSet*)m_pcTaskSet)->getFSM(i);
				double dRBF = pcStateFlow->get_rbf(iStart, f);
				total += dRBF;
			}
		}
		if (total <= f - iStart)	break;
		f += iGCD;
	}

	return total;
}

double _FSMRBFSORTCalculator::CalculateRTTrans(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, Transition * pcTrans)
{
	// calculate hyperperiod for 0~index stateflows
	int hyperperiod = 1;
	int gcd = 0;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iThisPriority = rcPriorityAssignment.getPriorityByTask(iTaskIndex);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
			continue;
		if (rcPriorityAssignment.getPriorityByTask(i) < iThisPriority)
		{
			Stateflow* sfj = ((FSMTaskSet*)m_pcTaskSet)->getFSM(i);
			hyperperiod = Utility::math_lcm(hyperperiod, sfj->hyperperiod);
			gcd = Utility::math_gcd(gcd, sfj->gcd);
		}
	}

	// calculate the set of start times within one hyperperiod
	set<int> sSet;
	for (int s = 0; s <= hyperperiod; s += pcTrans->period)
		sSet.insert(s);

	double dMaxResponseTime = 0;
	for (set<int>::iterator iter = sSet.begin(); iter != sSet.end(); iter++) {
		int s = *iter;
		//pcTrans->responseTimeByRbfWithStaticOffsets[s] = calculate_response_time_by_rbf_with_static_offsets(sfs, index, tran, s, gcd);
		double dThisRT = CalculateRTTrans(iTaskIndex, rcPriorityAssignment, pcTrans, s, gcd);
		dMaxResponseTime = max(dMaxResponseTime, dThisRT);
	}
	return dMaxResponseTime;
}

bool _FSMRBFSORTCalculator::IsDeadlineMet(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	Stateflow * sfi = ((FSMTaskSet*)m_pcTaskSet)->getFSM(iTaskIndex);
	for (vector<Transition*>::iterator iter = sfi->trans.begin(); iter != sfi->trans.end(); iter++)
	{
		double dRT = CalculateRTTrans(iTaskIndex, rcPriorityAssignment, *iter);
		if (dRT > (*iter)->deadline)
		{
			return false;
		}
	}
	return true;
}

//FSM random generator
#include <RandomGenerator.h>
#include "FileWriter.h"


#ifdef WINDOWS 
#include "TGFFReader.h"
#include "TGFF2TaskSets.h"
#include "GenSRTaskSets.h"
void GenerateFSMImplementationSingle(char axFileName[], int maxState, double tUtil, int period_choice, double scc_probability)
{
	TaskSet cTaskSet;
	cTaskSet.ReadImageFile(axFileName);
	string stringFSMName(axFileName);
	stringFSMName.append(".fsm.txt");
	int iTaskNum = cTaskSet.getTaskNum();
	Stateflow ** ppcSystems =
		RandomGenerator::Richie_generate_stateflow_system(iTaskNum, maxState, tUtil, period_choice, scc_probability);
	FileWriter::DotFileWriter(ppcSystems, iTaskNum, stringFSMName.data());
	delete[] ppcSystems;
}

void GenerateFSMImplementationFolder(char axFolder[], char axDstFolder[], int maxState, double tUtil, int period_choice, double scc_probability)
{
	char axBuffer[512] = { 0 };
	deque<string> dequeNames;
	GetTaskSetFileName(dequeNames, axFolder);
	int iLen = strlen(axFolder);
	for (deque<string>::iterator iter = dequeNames.begin(); iter != dequeNames.end(); iter++)
	{
		TaskSet cTaskSet;
		cTaskSet.ReadImageFile((char *)iter->data());
		int iTaskNum = cTaskSet.getTaskNum();
		string stringFSMName;
		int iNameStart = iter->find(axFolder);
		assert(iNameStart != -1);
		//cout << "\rConverting " << (*iter).substr(iLen, (*iter).size()) << "...";
		stringFSMName = axDstFolder + (*iter).substr(iLen, (*iter).size()) + ".fsm.txt";
		if (IsFileExist((char *)stringFSMName.data()))	continue;
		//cout << "Begin" << endl;
		Stateflow ** ppcSystems =
			//RandomGenerator::generate_stateflow_system_for_approximate_analysis4(iTaskNum, maxState, tUtil, period_choice, scc_probability);			
			RandomGenerator::Richie_generate_stateflow_system(iTaskNum, maxState, tUtil, period_choice, scc_probability);
		//cout << "Begin Write" << endl;
		FileWriter::DotFileWriter(ppcSystems, iTaskNum, stringFSMName.data());
		//cout << "End Write" << endl;
		//cout << "end" << endl;
		delete[] ppcSystems;
	}
	cout << endl;
}

void FSMNSweepRandomU_SingleN(int iN, double dULB, double dUUB, char axDstFolder[])
{
	char axBuffer[1024] = { 0 };
	sprintf_s(axBuffer, "TaskSet_%d_1000", iN);
	GenTGFFConfigFile(iN, 1000, axBuffer);
	GenTGFFFile(axBuffer);
	TGFF2TaskSets cConverter;
	sprintf_s(axBuffer, "TaskSet_%d_1000.tgff", iN);
	TGFFReader cTGFFReader(axBuffer);
	cTGFFReader.ProcessFile();
	cConverter.Run(cTGFFReader, dULB, dUUB, 1.0, 1.0);
	deque<TaskSet> & rdequeTaskSet = cConverter.getTaskSets();
	int iIndex = 0;
	sprintf_s(axBuffer, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d", axDstFolder, dULB, dUUB, iN);
	MakePath(axBuffer);
	for (deque<TaskSet>::iterator iter = rdequeTaskSet.begin();
		iter != rdequeTaskSet.end(); iter++, iIndex++)
	{
		sprintf_s(axBuffer, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, dULB, dUUB, iN, iIndex + 1);
		//printf_s("\rNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst    ", dULB, dUUB, iN, iIndex + 1);
		iter->WriteImageFile(axBuffer);
		sprintf_s(axBuffer, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.txt", axDstFolder, dULB, dUUB, iN, iIndex + 1);
		//printf_s("\rNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.txt   ", dULB, dUUB, iN, iIndex + 1);
		iter->WriteTextFile(axBuffer);
	}
	sprintf_s(axBuffer, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d", axDstFolder, dULB, dUUB, iN);
	double dFSMUtil = dULB + (dUUB - dULB) * ((double)rand() / (double)RAND_MAX);
	//GenerateFSMImplementationFolder(axBuffer, axBuffer, 15, dFSMUtil, RandomGenerator::ApproximateAnalysis1, 0.90);	
	char axCommand[1024] = { 0 };
	sprintf_s(axCommand, "MCMILPPact GenFSMFolder -SrcFolder=%s -DstFolder=%s -Util=%.2f -MaxNState=15 -SCCProb=0.90",
		axBuffer, axBuffer, dFSMUtil);
	system(axCommand);
}

#include <windows.h>
#include <process.h>
struct FSMNSweepRandomUThreadArg
{
	HANDLE * pcLock;
	deque<int> * pcdequeNs;
	double dLB;
	double dUB;
	char * axDstFolder;
};


unsigned int __stdcall FSMNSweepRandomUThreadRoutine(void * pvArgs)
{
	FSMNSweepRandomUThreadArg & rtagArgs = *(FSMNSweepRandomUThreadArg*)pvArgs;
	bool bContinue = true;
	while (1)
	{
		WaitForSingleObject(*rtagArgs.pcLock, INFINITE);
		if (rtagArgs.pcdequeNs->empty())
		{
			ReleaseMutex(*rtagArgs.pcLock);
			break;
		}
		int iN = rtagArgs.pcdequeNs->front();
		rtagArgs.pcdequeNs->pop_front();
		ReleaseMutex(*rtagArgs.pcLock);
		FSMNSweepRandomU_SingleN(iN, rtagArgs.dLB, rtagArgs.dUB, rtagArgs.axDstFolder);
	}
	return 0;
}

void FSMNSweepRandomU(double dULB, double dUUB, int iNStart, int iNEnd, int iNStep, char axDstFolder[], int iThreadNum)
{
	char axBuffer[512] = { 0 };
	deque<int> dequeNs;
	for (int i = iNStart; i <= iNEnd; i += iNStep)
		dequeNs.push_back(i);

	//use multi-thread to speed up.
	HANDLE cLock = CreateMutex(FALSE, FALSE, NULL);
	uintptr_t * phThreadHandles = new uintptr_t[iThreadNum];
	struct FSMNSweepRandomUThreadArg *ptagArgs = new struct FSMNSweepRandomUThreadArg[iThreadNum];
	for (int i = 0; i < iThreadNum; i++)
	{
		ptagArgs[i].pcdequeNs = &dequeNs;
		ptagArgs[i].pcLock = &cLock;
		ptagArgs[i].dLB = dULB;
		ptagArgs[i].dUB = dUUB;
		ptagArgs[i].axDstFolder = axDstFolder;
		phThreadHandles[i] = _beginthreadex(0, 0, &FSMNSweepRandomUThreadRoutine, (void*)&ptagArgs[i], 0, 0);
	}

	WaitForMultipleObjects(iThreadNum, (HANDLE *)phThreadHandles, TRUE, INFINITE);
	CloseHandle(cLock);

	delete phThreadHandles;
	delete ptagArgs;
	assert(dequeNs.empty());
}


struct FSMUSweepThreadArg
{
	HANDLE * pcLock;
	deque<double> * pcdequeUs;
	int iSystemSize;
	char * axDstFolder;
};

void FSMUSweep_SingleU(double dU, int iN, double dCF, char axDstFolder[])
{
	char axBuffer[1024] = { 0 };
	TGFF2TaskSets cConverter;
	sprintf_s(axBuffer, "TaskSet_%d_1000.tgff", iN);
	TGFFReader cTGFFReader(axBuffer);
	cTGFFReader.ProcessFile();
	cConverter.Run(cTGFFReader, dU, dU, dCF, dCF);
	deque<TaskSet> & rdequeTaskSet = cConverter.getTaskSets();
	int iIndex = 0;
	sprintf_s(axBuffer, "%s\\FSMUSweep\\U%.2f_N%d", axDstFolder, dU, iN);
	MakePath(axBuffer);
	for (deque<TaskSet>::iterator iter = rdequeTaskSet.begin();
		iter != rdequeTaskSet.end(); iter++, iIndex++)
	{
		sprintf_s(axBuffer, "%s\\FSMUSweep\\U%.2f_N%d\\TaskSet%d.tskst", axDstFolder, dU, iN, iIndex + 1);
		iter->WriteImageFile(axBuffer);
		sprintf_s(axBuffer, "%s\\FSMUSweep\\U%.2f_N%d\\TaskSet%d.tskst.txt", axDstFolder, dU, iN, iIndex + 1);
		iter->WriteTextFile(axBuffer);
	}
	sprintf_s(axBuffer, "%s\\FSMUSweep\\U%.2f_N%d", axDstFolder, dU, iN);
	double dFSMUtil = dU;
	//GenerateFSMImplementationFolder(axBuffer, axBuffer, 15, dFSMUtil, RandomGenerator::ApproximateAnalysis1, 0.90);	
	char axCommand[1024] = { 0 };
	sprintf_s(axCommand, "MCMILPPact GenFSMFolder -SrcFolder=%s -DstFolder=%s -Util=%.2f -MaxNState=15 -SCCProb=0.90",
		axBuffer, axBuffer, dFSMUtil);
	system(axCommand);
}

unsigned int __stdcall FSMUSweepRoutine(void * pvArgs)
{
	FSMUSweepThreadArg & rtagArgs = *(FSMUSweepThreadArg*)pvArgs;
	bool bContinue = true;
	while (1)
	{
		WaitForSingleObject(*rtagArgs.pcLock, INFINITE);
		if (rtagArgs.pcdequeUs->empty())
		{
			ReleaseMutex(*rtagArgs.pcLock);
			break;
		}
		double dUtil = rtagArgs.pcdequeUs->front();
		rtagArgs.pcdequeUs->pop_front();
		ReleaseMutex(*rtagArgs.pcLock);
		FSMUSweep_SingleU(dUtil, rtagArgs.iSystemSize, 1.0, rtagArgs.axDstFolder);
	}
	return 0;
}

void FSMUSweep(double dULB, double dUUB, double dUStep, int iN, char axDstFolder[], int iThreadNum)
{
	char axBuffer[512] = { 0 };
	deque<double> dequeUs;
	for (double dU = dULB; dU <= dUUB; dU += dUStep)
		dequeUs.push_back(dU);

	//use multi-thread to speed up.
	HANDLE cLock = CreateMutex(FALSE, FALSE, NULL);
	uintptr_t * phThreadHandles = new uintptr_t[iThreadNum];
	struct FSMUSweepThreadArg *ptagArgs = new struct FSMUSweepThreadArg[iThreadNum];
	for (int i = 0; i < iThreadNum; i++)
	{
		ptagArgs[i].pcdequeUs = &dequeUs;
		ptagArgs[i].pcLock = &cLock;
		ptagArgs[i].axDstFolder = axDstFolder;
		ptagArgs[i].iSystemSize = iN;
		phThreadHandles[i] = _beginthreadex(0, 0, &FSMUSweepRoutine, (void*)&ptagArgs[i], 0, 0);
	}

	WaitForMultipleObjects(iThreadNum, (HANDLE *)phThreadHandles, TRUE, INFINITE);
	CloseHandle(cLock);

	delete phThreadHandles;
	delete ptagArgs;
	assert(dequeUs.empty());
}

void FSMKSweep(int iKLB, int iKUB, int iKStep, char axSourceCopyFolder[], char axDstFolder[])
{
	char axBuffer[1024] = { 0 };
	for (int i = iKLB; i <= iKUB; i += iKStep)
	{
		sprintf_s(axBuffer, "xcopy %s\\TaskSet*.tskst %s\\K%d\\",
			axSourceCopyFolder, axDstFolder, i);
		system(axBuffer);
		sprintf_s(axBuffer, "xcopy %s\\TaskSet*.txt %s\\K%d\\",
			axSourceCopyFolder, axDstFolder, i);
		system(axBuffer);
		sprintf_s(axBuffer, "xcopy %s\\TaskSet*.tskst.fsm.txt %s\\K%d\\",
			axSourceCopyFolder, axDstFolder, i);
		system(axBuffer);
	}
}
#endif
//UnschedCore Computer

UnschedCoreComputer_FSM_RBFSO::UnschedCoreComputer_FSM_RBFSO()
{

}

UnschedCoreComputer_FSM_RBFSO::UnschedCoreComputer_FSM_RBFSO(FSMTaskSet & rcTaskSet)
	:UnschedCoreComputer(rcTaskSet)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	m_iInstanceApproximate = 0;
	m_iInstanceLimit = -1;
	m_iUnschedAtTriggerTimes = 0;
	m_iUnschedNotAtTriggerTimes = 0;
	m_iBusyStartApproximation = 0;
//	ComputePairwiseDominance();
	m_vectorSystemApproxFeaHPBitMaskNLH.clear();
	m_vectorSystemApproxFeaHPBitMaskNLH.reserve(iTaskNum);
	m_vectorSystemApproxInfeaHPBitMaskNLH.clear();
	m_vectorSystemApproxInfeaHPBitMaskNLH.reserve(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		m_vectorSystemApproxFeaHPBitMaskNLH.push_back(BitMaskStorage_N_LowestSet());
		m_vectorSystemApproxFeaHPBitMaskNLH.back().Initialize(iTaskNum);
		m_vectorSystemApproxInfeaHPBitMaskNLH.push_back(BitMaskStorage_N_LowestSet());
		m_vectorSystemApproxInfeaHPBitMaskNLH.back().Initialize(iTaskNum);
	}
}

UnschedCoreComputer_FSM_RBFSO::~UnschedCoreComputer_FSM_RBFSO()
{

}

int UnschedCoreComputer_FSM_RBFSO::QuickSchedTest_Forv4(int iTaskIndex, BitMask & rcHPSets)
{
	int iStatus = UnschedCoreComputer::QuickSchedTest_Forv4(iTaskIndex, rcHPSets);
	if (iStatus != -1) return iStatus;

	if (m_iInstanceApproximate == 1)
	{
		if (m_vectorSystemApproxFeaHPBitMaskNLH[iTaskIndex].Find(rcHPSets))
			return 1;
		if (m_vectorSystemApproxFeaHPBitMaskNLH[iTaskIndex].ExistSupSet(rcHPSets))
			return 1;
	}
	
	return -1;
}

bool UnschedCoreComputer_FSM_RBFSO::SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData)
{
#if 0
	_FSMRBFSORTCalculator cRTCalc(*m_pcTaskSet);
	return cRTCalc.IsDeadlineMet(iTaskIndex, rcPriorityAssignment);
#else
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	Stateflow ** ppcSfs = new Stateflow *[iTaskNum];
	int iIndex = GenSFArrayByPriority(ppcSfs, iTaskIndex, rcPriorityAssignment);
	bool bSched = false;
	m_iResultTrulyApproximiate = 0;
	bSched = Richie_rbf_analysis_static_offset_index(ppcSfs, iIndex);			
END:
	delete ppcSfs;
	return bSched;
#endif
}

int UnschedCoreComputer_FSM_RBFSO::GenSFArrayByPriority(Stateflow ** ppcStateflows, int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (m_vectorSFArrayMapping.size() != iTaskNum)
	{
		m_vectorSFArrayMapping.clear();
		m_vectorSFArrayMapping.reserve(iTaskNum);
		for (int i = 0; i < iTaskNum; i++)
			m_vectorSFArrayMapping.push_back(-1);
	}
	int iForwardIndex = 0;
	int iBackwardIndex = iTaskNum - 1;
	int iPriority = rcPriorityAssignment.getPriorityByTask(iTaskIndex);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)	continue;
		int iThisPriority = rcPriorityAssignment.getPriorityByTask(i);
		if (iThisPriority < iPriority)
		{
			//ppcStateflows[iForwardIndex++] = ((FSMTaskSet*)m_pcTaskSet)->getFSM(i);
			m_vectorSFArrayMapping[iForwardIndex] = i;
			ppcStateflows[iForwardIndex++] = ((FSMTaskSet *)m_pcTaskSet)->getFSM(i);
		}
		else
		{
			m_vectorSFArrayMapping[iThisPriority] = i;
			ppcStateflows[iThisPriority] = ((FSMTaskSet *)m_pcTaskSet)->getFSM(i);
			iBackwardIndex--;
		}
	}
	assert(iBackwardIndex == iForwardIndex);
	m_vectorSFArrayMapping[iBackwardIndex] = iTaskIndex;
	ppcStateflows[iBackwardIndex] = ((FSMTaskSet *)m_pcTaskSet)->getFSM(iTaskIndex);
	return iBackwardIndex;
}

bool UnschedCoreComputer_FSM_RBFSO::Richie_rbf_analysis_static_offset_index(Stateflow** sfs, int i)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	Stateflow* sfi = sfs[i];
	double dBound = sfs[i]->hyperperiod;
	for (int iHP = 0; iHP <= i; iHP++)
		dBound = Utility::math_lcm(dBound, sfs[iHP]->hyperperiod);
	int iHPGCD = HPGCD(sfs, i);
	int iLastStart = 0;
	int iTestedInstances = 0;
	for (map<int, vector<ActionPair>>::iterator mIter = sfi->mCAP.begin(); mIter != sfi->mCAP.end(); mIter++)
	{
		int stime = mIter->first;
		vector<ActionPair> & vec_ap = mIter->second;
		if (stime > dBound)	continue;

		for (vector<ActionPair>::iterator apIter = vec_ap.begin(); apIter != vec_ap.end(); apIter++)
		{
			ActionPair ap = *apIter;
			//see if dominated by lower priority tasks action pair
			bool bInterDominated = IsDominateByLP(sfs, i, stime, ap);		
			if (bInterDominated)	continue;
			int tk = 0;
#if 0
			for (int align = 0; align <= ap.stime; align += sfs[i]->hyperperiod) {
				bool check = true;
				for (int j = 0; j < i; j++) {
					Stateflow* sfj = sfs[j];
					if (align % sfj->hyperperiod != 0) {
						check = false;
						break;
					}
				}
				if (check) tk = align;
			}
#endif
			tk = ap.stime - tk;		
			if (m_iBusyStartApproximation == 1)
			{
				iLastStart = tk;
			}
			bool schedulable = Richie_rbf_analysis_static_offset_index(sfs, i, ap.e, tk, ap.d, iLastStart, iHPGCD);
#if 1
			iTestedInstances++;
			if (m_iInstanceApproximate == 1)
			{
				if (iTestedInstances >= m_iInstanceLimit)
				{
					m_iResultTrulyApproximiate = 1;
					return true;
				}
			}

			if (schedulable && m_iBusyStartApproximation)
			{
				m_iResultTrulyApproximiate = 1;
			}
#endif
			if (!schedulable)
			{
				//cout << "UnSchedulbale by rbf analysis with static offset on Stateflow " << i << "\t Action Pair=>" << ap.toString() << endl;
				m_iResultTrulyApproximiate = 0;
				if (m_mapUnschedStopInstance.count(iTestedInstances) == 0)
				{
					m_mapUnschedStopInstance[iTestedInstances] = 1;
				}
				else
				{
					m_mapUnschedStopInstance[iTestedInstances]++;
				}
				return false;
			}

			iLastStart = tk;
		}
	}
	//cout << "UnSchedulbale by rbf analysis with static offset on Stateflow " << i << "\t Action Pair=>" << ap.toString() << endl;
#if 0
	if (m_mapUnschedStopInstance.count(iTestedInstances) == 0)
	{
		m_mapUnschedStopInstance[iTestedInstances] = 1;
	}
	else
	{
		m_mapUnschedStopInstance[iTestedInstances]++;
	}
#endif
	return true;
}

bool UnschedCoreComputer_FSM_RBFSO::Richie_rbf_analysis_static_offset_index(Stateflow** sfs, int i, int wcet, int stime, int deadline, int & iStartLB, int iHPGCD)
{
	if (i == 0) {
		if (wcet <= deadline) return true;
		else return false;
	}
	int gcd = iHPGCD;
	if (stime%iHPGCD != 0) {
		cerr << "stime=" << stime << " cannot be divided by gcd=" << gcd << endl;
		exit(EXIT_FAILURE);
	}

	double rt = 0;
	for (int iStart = iStartLB, *iter = &iStart; iStart <= stime; iStart += gcd)
	{
		//if (getIBF(sfs, i - 1, iStart, stime) < stime - iStart)  continue;
		int start = *iter;
		bool found = false;
		int tprim = start;
		while (tprim <= stime + deadline)
		{
			double temp = 0;
			if (tprim >= stime) temp += wcet;
			for (int j = 0; j < i; j++) {
				Stateflow* sfj = sfs[j];
				double rbfsf = sfj->get_rbf(start, tprim);
				temp += rbfsf;
			}
			if ((temp <= tprim - start) && (start < tprim))
			{
				rt = max(rt, temp + start - stime);
				found = true;
				break;
			}
			int total = ceil(1.0*(temp + start) / gcd)*gcd;
			if (total == tprim)
				tprim += gcd;
			else
				tprim = total;
		}
		if (!found)
		{
			if (start != stime)
			{
				bool bSTimeStatus = Richie_rbf_analysis_static_offset_index(sfs, i, wcet, stime, deadline, stime, iHPGCD);
				if (bSTimeStatus)
				{
					m_iUnschedNotAtTriggerTimes++;
				}	
				else
				{
					m_iUnschedAtTriggerTimes++;
				}				
			}
			else
			{
				m_iUnschedAtTriggerTimes++;
			}
			
			return false;
		}
	}
	if (rt <= deadline) return true;
	return false;
}

bool UnschedCoreComputer_FSM_RBFSO::IsDominateByLP(Stateflow** sfs, int i, int stime, ActionPair & rcAP)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	bool bInterDominated = false;
	for (int iLP = i + 1; iLP < iTaskNum; iLP++)
	{
		vector<ActionPair> & rvectorLPAP = sfs[iLP]->mCAP[stime];
		for (vector<ActionPair>::iterator iterLPAP = rvectorLPAP.begin(); iterLPAP != rvectorLPAP.end(); iterLPAP++)
		{
			if (*iterLPAP > rcAP)
			{
				bInterDominated = true;
				break;
			}
		}
		if (bInterDominated)
			break;
	}
	return bInterDominated;
}

int UnschedCoreComputer_FSM_RBFSO::HPGCD(Stateflow** sfs, int iTaskIndex)
{
	int gcd = 0;
	for (int j = 0; j <= iTaskIndex; j++) {
		Stateflow* sfj = sfs[j];
		gcd = Utility::math_gcd(gcd, sfj->gcd);
	}
	return gcd;
}

double UnschedCoreComputer_FSM_RBFSO::getIBF(Stateflow ** ppcStateflows, int iLevel, int iStart, int iFinish)
{
	double dIBF = 0;
	for (int i = 0; i <= iLevel; i++)
	{
		dIBF += ppcStateflows[i]->get_ibf(iStart, iFinish);
	}
	return dIBF;
}

bool UnschedCoreComputer_FSM_RBFSO::Richie_lub_rbf_analysis_static_offset_index(Stateflow** sfs, int i, int wcet, int stime, int deadline, int iHPGCD)
{
	if (i == 0) {
		if (wcet <= deadline) return true;
		else return false;
	}

	int gcd = iHPGCD;

	if (stime%gcd != 0) {
		cerr << "stime=" << stime << " cannot be divided by gcd=" << gcd << endl;
		exit(EXIT_FAILURE);
	}

	double tUtil = 0;
	double tCrbf = 0;
	for (int j = 0; j < i; j++) {
		Stateflow* sfj = sfs[j];
		tUtil += sfj->lfac;
		tCrbf += sfj->crbf;
		if (tUtil >= 1) return false;
	}

	double rt = (tCrbf + wcet) / (1.0 - tUtil);
	if (rt <= deadline) return true;
	return false;
}

bool UnschedCoreComputer_FSM_RBFSO::Richie_lub_rbf_analysis_static_offset_index(Stateflow** sfs, int i)
{
	int iHPGCD = HPGCD(sfs, i);
	Stateflow* sfi = sfs[i];

	double tUtil = 0;
	double tCrbf = 0;
	for (int j = 0; j < i; j++) {
		Stateflow* sfj = sfs[j];
		tUtil += sfj->lfac;
		tCrbf += sfj->crbf;
		if (tUtil >= 1) return false;
	}
	//cout << tUtil << " " << tCrbf << endl; system("pause");
	for (map<int, vector<ActionPair>>::iterator mIter = sfi->mCAP.begin(); mIter != sfi->mCAP.end(); mIter++) {
		int stime = mIter->first;
		vector<ActionPair> vec_ap = mIter->second;
		for (vector<ActionPair>::iterator apIter = vec_ap.begin(); apIter != vec_ap.end(); apIter++) {
			ActionPair ap = *apIter;

			int wcet = ap.e;
			int deadline = ap.d;
			double rt = (tCrbf + wcet) / (1.0 - tUtil);
			bool schedulable = (rt <= deadline);
			//bool schedulable = Richie_lub_rbf_analysis_static_offset_index(sfs, i, ap.e, ap.stime, ap.d, iHPGCD);
			if (!schedulable) {
				//cout << "UnSchedulbale on Stateflow " << i << "\t Action Pair=>" << ap.toString() << endl;
				return false;
			}
		}
	}
	return true;
}

bool UnschedCoreComputer_FSM_RBFSO::Richie_llb_rbf_analysis_static_offset_index(Stateflow** sfs, int i)
{
	int iHPGCD = HPGCD(sfs, i);
	Stateflow* sfi = sfs[i];

	double tUtil = 0;
	//double tCrbf = 0;
	for (int j = 0; j < i; j++) {
		Stateflow* sfj = sfs[j];
		tUtil += sfj->lfac;
		//tCrbf += sfj->crbf;
		if (tUtil >= 1) return false;
	}

	for (map<int, vector<ActionPair>>::iterator mIter = sfi->mCAP.begin(); mIter != sfi->mCAP.end(); mIter++) {
		int stime = mIter->first;
		vector<ActionPair> vec_ap = mIter->second;
		for (vector<ActionPair>::iterator apIter = vec_ap.begin(); apIter != vec_ap.end(); apIter++) {
			ActionPair ap = *apIter;

			int wcet = ap.e;
			int deadline = ap.d;
			//double rt = (tCrbf + wcet) / (1.0 - tUtil);
			double rt = (wcet) / (1.0 - tUtil);
			bool schedulable = (rt <= deadline);
			//bool schedulable = Richie_lub_rbf_analysis_static_offset_index(sfs, i, ap.e, ap.stime, ap.d, iHPGCD);
			if (!schedulable) {
				//cout << "UnSchedulbale on Stateflow " << i << "\t Action Pair=>" << ap.toString() << endl;
				return false;
			}
		}
	}
	return true;
}

void UnschedCoreComputer_FSM_RBFSO::ComputePairwiseDominance()
{
	FSMTaskSet & rcFSMTaskSet = *(FSMTaskSet *)m_pcTaskSet;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iGCD = HPGCD(rcFSMTaskSet.getFSMArray(), iTaskNum - 1);
	int iHyperPeriod = 1;
	cout << "Hello" << endl;
	for (int i = 0; i < iTaskNum; i++)
	{
		iHyperPeriod = lcm(iHyperPeriod, rcFSMTaskSet.getFSMArray()[i]->hyperperiod);
	}
	int iDetectedNum = 0;	
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = i + 1; j < iTaskNum; j++)
		{
			if (i == j) continue;
			cout << "\rTesting " << "(" << i << " " << j << ")  " << "Detected: " << iDetectedNum << "     ";;
			int iStatus = TestDominance(i, j, -1);			
			if (iStatus == 2)
			{
				m_mapPairwiseDominance[i][j] = 1;
				m_mapPairwiseDominance[j][i] = 1;
				iDetectedNum += 2;
			}
			else if (iStatus == 1)
			{
				m_mapPairwiseDominance[i][j] = 1;
				m_mapPairwiseDominance[j][i] = 0;
				iDetectedNum += 1;
			}
			else if (iStatus == 0)
			{
				m_mapPairwiseDominance[i][j] = 0;
				m_mapPairwiseDominance[j][i] = 1;
				iDetectedNum += 1;
			}
			else
			{
				m_mapPairwiseDominance[i][j] = -1;
				m_mapPairwiseDominance[j][i] = -1;
			}			
		}
	}
}

int UnschedCoreComputer_FSM_RBFSO::TestDominance(int iTaskA, int iTaskB, int iSTDistance)
{	
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	FSMTaskSet & rcFSMTaskSet = *(FSMTaskSet *)m_pcTaskSet;
	Stateflow ** ppcSFs = rcFSMTaskSet.getFSMArray();
	int iHyperPeriod = lcm(ppcSFs[iTaskA]->hyperperiod, ppcSFs[iTaskB]->hyperperiod);
	int iGCD = gcd(ppcSFs[iTaskA]->gcd, ppcSFs[iTaskB]->gcd);
	if (iSTDistance < 0)
	{		
		for (int i = 0; i < iTaskNum; i++)
		{
			for (int j = 0; j < ppcSFs[i]->trans.size(); j++)
			{
				
				iSTDistance = max(ppcSFs[i]->trans[j]->period + ppcSFs[i]->gcd, iSTDistance);
			}			
		}
	}
	int iADomB = 1;
	int iBDomA = 1;	
	for (int iStart = 0; iStart <= iHyperPeriod; iStart += iGCD)
	{
		for (int iEnd = iStart + iGCD; iEnd <= iHyperPeriod; iEnd += iGCD)
		{
			if (iEnd - iStart > iSTDistance)	break;
			int iRbfA = ppcSFs[iTaskA]->get_rbf(iStart, iEnd);
			int iRbfB = ppcSFs[iTaskB]->get_rbf(iStart, iEnd);

			if (iRbfA > iRbfB)
			{
				iBDomA = 0;
			}
			else if (iRbfB > iRbfA)
			{
				iADomB = 0;
			}

			if ((iBDomA == iADomB) && (iBDomA == 0))
			{
				return -1;
			}
		}
	}
	if ((iBDomA == iADomB) && (iBDomA == 1))
	{
		return 2;
	}

	if (iADomB)	return 1;
	if (iBDomA)	return 0;
	return -1;
	
}

//Single Task Implementation Unsched Core Computer
UnschedCoreComputer_FSM_SingleTaskImple::UnschedCoreComputer_FSM_SingleTaskImple()
{

}

UnschedCoreComputer_FSM_SingleTaskImple::UnschedCoreComputer_FSM_SingleTaskImple(FSMTaskSet & rcTaskSet)
	:UnschedCoreComputer(rcTaskSet)
{
	GET_TASKSET_NUM_PTR(&rcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		m_cImpleTaskSet.AddTask(
			rcTaskSet.getFSM(i)->gcd, 
			rcTaskSet.getFSM(i)->gcd,
			(double)rcTaskSet.getFSMMaxWCET(i) / (double)rcTaskSet.getFSM(i)->gcd,
			1.0,
			0.0
			);
	}
	m_cImpleTaskSet.ConstructTaskArray();
	for (int i = 0; i < iTaskNum; i++)
	{
		set<Task::CommunicationLink> & setSuccessor = pcTaskArray[i].getSuccessorSet();
		for (set<Task::CommunicationLink>::iterator iter = setSuccessor.begin(); iter != setSuccessor.end(); iter++)
		{
			m_cImpleTaskSet.AddLink(i, iter->m_iTargetTask, iter->m_dMemoryCost, iter->m_dDelayCost);
		}
	}
	m_cImpleTaskSet.setAvailableMemory(1e70);
}

UnschedCoreComputer_FSM_SingleTaskImple::~UnschedCoreComputer_FSM_SingleTaskImple()
{

}

bool UnschedCoreComputer_FSM_SingleTaskImple::SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void * pvExtraData)
{
	_LORTCalculator cRTCalc(m_cImpleTaskSet);
	double dRT = cRTCalc.CalculateRTTask(iTaskIndex, rcPriorityAssignment);
	return dRT <= m_cImpleTaskSet.getTaskArrayPtr()[iTaskIndex].getDeadline();
}


//FSM RBFSO

SimulinkMiniDelayBnB_FSMRBFSO::SimulinkMiniDelayBnB_FSMRBFSO()
{
}

SimulinkMiniDelayBnB_FSMRBFSO::SimulinkMiniDelayBnB_FSMRBFSO(FSMTaskSet & rcTaskSet)
	:m_cUnschedCore(rcTaskSet)
{
	m_dBestDelay = -1;
	m_pcTaskSet = &rcTaskSet;	
	InitializeLinkData();
}

SimulinkMiniDelayBnB_FSMRBFSO::~SimulinkMiniDelayBnB_FSMRBFSO()
{

}

void SimulinkMiniDelayBnB_FSMRBFSO::InitializeLinkData()
{
	int iLinkNum = 0;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	UnschedCoreComputer::PriorityPOSet cPPORange;
	for (int i = 0; i < iTaskNum; i++)
	{
		for (set<Task::CommunicationLink>::iterator iter = pcTaskArray[i].getSuccessorSet().begin();
			iter != pcTaskArray[i].getSuccessorSet().end(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			double m_dSrcPeriod = pcTaskArray[iSource].getPeriod();
			double m_dDstPeriod = pcTaskArray[iDestination].getPeriod();
			m_setLHLinks.insert(SimulinkMiniDelayBnB_Link(iSource, iDestination, iter->m_dDelayCost, iter->m_dMemoryCost));
			cPPORange.insert({ iSource, iDestination });
			iLinkNum++;
		}
	}
}

double SimulinkMiniDelayBnB_FSMRBFSO::CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (m_cUnschedCore.IsSchedulable(iTaskIndex, rcPriorityStruct))
	{
		return pcTaskArray[iTaskIndex].getDeadline() - 1;
	}
	else
	{
		return pcTaskArray[iTaskIndex].getDeadline() + 1;
	}
}


#ifdef MCMILPPACT
//FR for FSM_RBFSO

SimuLinkMiniDelay_FR_FSM_RBFSO::SimuLinkMiniDelay_FR_FSM_RBFSO(FSMTaskSet & rcTaskSet)
	:SimuLinkMiniDelay_FR(rcTaskSet),
	m_cUnschedCoreComputer_FSM_RBFSO(rcTaskSet)
{
	//m_cPODET = PartialOrderSet<int>();
	//m_cUnschedCoreComputer_FSM_RBFSO.setSchedTestOption(UnschedCoreComputer::LookUpTable);
	PriorityPOSet cPPOSet;
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		cPPOSet.insert(PriorityPOElement(iter->second.m_iSource, iter->second.m_iDestination));		
	}
	//	PrintSetContent(cPPOSet.getSetContent());
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (cPPOSet.count(PriorityPOElement(iter->second.m_iSource, iter->second.m_iDestination)))
			iter->second.m_iType = SIMULINK_LINKTYPE_LH;
		else
			iter->second.m_iType = SIMULINK_LINKTYPE_HL;
	}
	m_cUnschedCoreComputer_FSM_RBFSO.setPPORange(cPPOSet);
	//m_cUnschedCoreComputer_FSM_RBFSO.setUnschedCoreCompOption(UnschedCoreComputer::UCOpt_QuickPPOSched);
	m_iIncorrectOptimalFailedTimes = 0;
}

SimuLinkMiniDelay_FR_FSM_RBFSO::SimuLinkMiniDelay_FR_FSM_RBFSO()
{

}

SimuLinkMiniDelay_FR_FSM_RBFSO::~SimuLinkMiniDelay_FR_FSM_RBFSO()
{

}

void SimuLinkMiniDelay_FR_FSM_RBFSO::SchedTestOption(string stringOption)
{
	if (stringOption.compare("Original") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setSchedTestOption(UnschedCoreComputer::SchedTest_Original);
	}
	else if (stringOption.compare("LookUpTable") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setSchedTestOption(UnschedCoreComputer::SchedTest_LookUpTable);
	}	
	else
	{
		my_assert(false, "Unknown option for schedulability test");
	}
}

void SimuLinkMiniDelay_FR_FSM_RBFSO::UnschedCoreCompOption(string stringOption)
{
	if (stringOption.compare("Original") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setUnschedCoreCompOption(UnschedCoreComputer::UCOpt_Original);
	}
	else if (stringOption.compare("HinderingPPO") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setUnschedCoreCompOption(UnschedCoreComputer::UCOpt_HinderingPPO);
	}
	else if (stringOption.compare("PPOSchedLookUpTable") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setUnschedCoreCompOption(UnschedCoreComputer::UCOpt_QuickPPOSched);
	}
	else if (stringOption.compare("BinGrouping") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setUnschedCoreCompOption(UnschedCoreComputer::UCOpt_BinGrouping);
	}
	else if (stringOption.compare("ReusedLowestAssigned") == 0)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.setUnschedCoreCompOption(UnschedCoreComputer::UCOpt_ReusedLowestAssigned);
	}
	else
	{
		my_assert(false, "Unknown option for unsched-core computation");
	}
}

void SimuLinkMiniDelay_FR_FSM_RBFSO::InstanceApproximationOption(int iInstanceLimit)
{
	if (iInstanceLimit == -1)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceLimit = -1;
		m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate = 0;
	}
	else
	{
		m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate = 1;
		m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceLimit = iInstanceLimit;
	}
}

void SimuLinkMiniDelay_FR_FSM_RBFSO::BusyStartApproximation(int iOpt)
{
	if (iOpt == 1)
	{
		m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation = 1;
	}
	else
	{
		m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation = 0;
	}
}

bool SimuLinkMiniDelay_FR_FSM_RBFSO::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	int iInstanceApproximate = m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate;
	int iBusyStartApproximate = m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation;
	m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate = 0;
	m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation = 0;
	bool bStatus = m_cUnschedCoreComputer_FSM_RBFSO.IsSchedulable(rcPriorityAssignment, rcPPOSet);
	m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate = iInstanceApproximate;
	m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation = iBusyStartApproximate;
	return bStatus;
}

bool SimuLinkMiniDelay_FR_FSM_RBFSO::VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment)
{
	_FSMRBFSORTCalculator cRTCalc(*m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	bool bSchedulable = true;;
	UnschedCoreComputer_FSM_RBFSO m_cThirdPartyComp(*(FSMTaskSet*)m_pcTaskSet);
	bSchedulable = m_cThirdPartyComp.IsSchedulable(rcPriorityAssignment);
	assert(bSchedulable);
	return true;
}

bool SimuLinkMiniDelay_FR_FSM_RBFSO::VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	return true;
	cout << "Verifying " << endl;
	rcPriorityAssignment.Print();
	TaskSetPriorityStruct cPA(*m_pcTaskSet);
	UnschedCoreComputer_FSM_RBFSO m_cThirdPartyComp(*(FSMTaskSet*)m_pcTaskSet);
	assert(m_cThirdPartyComp.IsSchedulable(cPA, rcPOSet));
	return true;
}

int SimuLinkMiniDelay_FR_FSM_RBFSO::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{
	//SimuLinkMiniDelay_FR::ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);			
	//return m_cUnschedCoreComputer_FSM_RBFSO_OA.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
	return m_cUnschedCoreComputer_FSM_RBFSO.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
}

int SimuLinkMiniDelay_FR_FSM_RBFSO::FeasibleHook(UnschedCores & rcUnschedCores, PriorityPOSet & rcFixedSet, PriorityPOSet & rcPPOSolution)
{
	//return 1;
	UnschedCores cThisCore;	
	int iInstanceApproximate = m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate;
	int iBusyStartApproximate = m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation;
	m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate = 0;
	m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation = 0;
	int iSize = m_cUnschedCoreComputer_FSM_RBFSO.ComputeUnschedCores(rcPPOSolution, rcFixedSet, cThisCore, m_iCorePerIter);	
	m_cUnschedCoreComputer_FSM_RBFSO.m_iInstanceApproximate = iInstanceApproximate;
	m_cUnschedCoreComputer_FSM_RBFSO.m_iBusyStartApproximation = iBusyStartApproximate;
	for (UnschedCores::iterator iter = cThisCore.begin(); iter != cThisCore.end(); iter++)
	{
		rcUnschedCores.push_back(*iter);
	}
	if (iSize == 0)
	{
		return 1;
	}	
	else
	{
		m_iIncorrectOptimalFailedTimes++;
		return 0;
	}
}

void SimuLinkMiniDelay_FR_FSM_RBFSO::WriteSchedTestStatistic()
{
	if (m_stringLogFile.empty())
	{
		return;
	}
	char axBuffer[512] = { 0 };
	ofstream ofstreamFile(m_stringLogFile, ios::app);
	map<int, int > & rcStatisticData = m_cUnschedCoreComputer_FSM_RBFSO.m_mapUnschedStopInstance;
	ofstreamFile << "---------------------Unsched Scenario Tested # Instances-------------------------" << endl;
	int iTotal = 0;
	for (map<int, int>::iterator iter = rcStatisticData.begin(); iter != rcStatisticData.end(); iter++)
	{
		iTotal += iter->second;
	}

	for (map<int, int>::iterator iter = rcStatisticData.begin(); iter != rcStatisticData.end(); iter++)
	{
		sprintf_s(axBuffer, "%d Instances: %d, Ratio: %.2f%%", iter->first, iter->second, (double)iter->second / (double)iTotal * 100);
		ofstreamFile << axBuffer << endl;
	}
	ofstreamFile << "---------------------Unsched Scenario Trigger Time Status-------------------------" << endl;
	int iTotalTimes = m_cUnschedCoreComputer_FSM_RBFSO.m_iUnschedNotAtTriggerTimes + m_cUnschedCoreComputer_FSM_RBFSO.m_iUnschedAtTriggerTimes;
	sprintf_s(axBuffer, "Schdulable at Trigger Time However: %d, Ratio: %.2f",
		m_cUnschedCoreComputer_FSM_RBFSO.m_iUnschedNotAtTriggerTimes,
		(double)m_cUnschedCoreComputer_FSM_RBFSO.m_iUnschedNotAtTriggerTimes / (double)iTotalTimes * 100.0);
	ofstreamFile << axBuffer << endl;
	sprintf_s(axBuffer, "Not Schdulable at Trigger Time Either: %d, Ratio: %.2f%%",
		m_cUnschedCoreComputer_FSM_RBFSO.m_iUnschedAtTriggerTimes,
		(double)m_cUnschedCoreComputer_FSM_RBFSO.m_iUnschedAtTriggerTimes / (double)iTotalTimes * 100.0);
	ofstreamFile << axBuffer << endl;

	ofstreamFile << endl;
	ofstreamFile << "Incorrect Optimality #: " << m_iIncorrectOptimalFailedTimes << endl;

	ofstreamFile.close();	
}

void SimuLinkMiniDelay_FR_FSM_RBFSO::PostAccomplishWork(int iStatus)
{
	WriteSchedTestStatistic();
}
//Single Task Imple

SimuLinkMiniDelay_FR_FSM_SingleTaskImple::SimuLinkMiniDelay_FR_FSM_SingleTaskImple(FSMTaskSet & rcTaskSet)
	:SimuLinkMiniDelay_FR(rcTaskSet),
	m_cUnschedCoreComputer_FSM_SingleTaskImple(rcTaskSet)
{
	//m_cPODET = PartialOrderSet<int>();
	PriorityPOSet cPPOSet;
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		cPPOSet.insert(PriorityPOElement(iter->second.m_iSource, iter->second.m_iDestination));
	}
	//	PrintSetContent(cPPOSet.getSetContent());
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (cPPOSet.count(PriorityPOElement(iter->second.m_iSource, iter->second.m_iDestination)))
			iter->second.m_iType = SIMULINK_LINKTYPE_LH;
		else
			iter->second.m_iType = SIMULINK_LINKTYPE_HL;
	}

}

SimuLinkMiniDelay_FR_FSM_SingleTaskImple::SimuLinkMiniDelay_FR_FSM_SingleTaskImple()
{

}

SimuLinkMiniDelay_FR_FSM_SingleTaskImple::~SimuLinkMiniDelay_FR_FSM_SingleTaskImple()
{

}

bool SimuLinkMiniDelay_FR_FSM_SingleTaskImple::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	return m_cUnschedCoreComputer_FSM_SingleTaskImple.IsSchedulable(rcPriorityAssignment, rcPPOSet);
}

bool SimuLinkMiniDelay_FR_FSM_SingleTaskImple::VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment)
{
	_FSMRBFSORTCalculator cRTCalc(*m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	bool bSchedulable = true;;
	bSchedulable = m_cUnschedCoreComputer_FSM_SingleTaskImple.IsSchedulable(rcPriorityAssignment);
	assert(bSchedulable);
	return true;
}

int SimuLinkMiniDelay_FR_FSM_SingleTaskImple::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{
	//SimuLinkMiniDelay_FR::ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);			
	//return m_cUnschedCoreComputer_FSM_RBFSO_OA.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
	return m_cUnschedCoreComputer_FSM_SingleTaskImple.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
}

int SimuLinkMiniDelay_FR_FSM_SingleTaskImple::FeasibleHook(UnschedCores & rcUnschedCores, PriorityPOSet & rcFixedSet, PriorityPOSet & rcPPOSolution)
{
	return 1;
	UnschedCores cThisCore;
	int iSize = m_cUnschedCoreComputer_FSM_SingleTaskImple.ComputeUnschedCores(rcPPOSolution, rcFixedSet, cThisCore, m_iCorePerIter);
	for (UnschedCores::iterator iter = cThisCore.begin(); iter != cThisCore.end(); iter++)
	{
		rcUnschedCores.push_back(*iter);
	}
	if (iSize == 0)
		return 1;
	else
		return 0;
}

void GenerateSimulinkFIJCaseFSMImple()
{
	FSMTaskSet cTaskSet;
	cTaskSet.ReadImageFile("F:\\C++Project\\MCMILPPact\\MCMILPPact\\MCMILPPact\\SimulinkTaskSet\\v3_deadlineversion\\simulinkdata.tskst");
	GET_TASKSET_NUM_PTR(&cTaskSet, num, pcTaskArray);
	Stateflow ** sfs = cTaskSet.getFSMArray();
	sfs = new Stateflow*[num];
	double scc_probability = 0.90;
	int sIndex = -1;
	bool isExisted = false;
	int iScale = 10;
	//if (rand()%100<80) isExisted = true;

	if (isExisted) sIndex = rand() % num;

	for (int i = 0; i<num; i++) {
		if (i == sIndex) continue;

		int numState = 0;
		double r = (double)rand() / RAND_MAX;
		if (r < 0.70) numState = 1;
		else if (r < 0.76) numState = 5;
		else if (r < 0.82) numState = 10;
		else if (r < 0.88) numState = 15;
		else if (r < 0.94) numState = 20;
		else if (r < 0.97) numState = 25;		
		else if (r <= 1) numState = 50;
		else {
			cerr << "Error random double " << r << endl;
			exit(EXIT_FAILURE);
		}

		if (i == 0) numState = 50;
		int numTran = RandomGenerator::calculate_num_edge(numState);
		//	cout<<"numState="<<numState<<"\t"<<"numTran="<<numTran<<endl;
		if (numState == 1)	numTran = 1;
		Stateflow* sf;
		//	cout << "begin graph" << endl;
		while (true) {
			//cout << "generate_one_stateflow2" << endl;
			//sf = generate_one_stateflow2(i, STATEFLOW_SCALE, numState, numTran);
			sf = RandomGenerator::generate_one_stateflow3(i, iScale, numState);
			//cout << "generate_simple_digraph" << endl;
			Digraph* digraph = GraphAlgorithms::generate_simple_digraph(sf);
			//cout << "generate_strongly_connected_components" << endl;
			digraph->generate_strongly_connected_components();
			digraph->check_strongly_connected();

			r = (double)rand() / RAND_MAX;

			if (digraph->strongly_connected) {
				delete digraph;
				break;
			}

			if (r<1 - scc_probability) {
				delete digraph;
				break;
			}

			delete digraph;
			delete sf;
		}
		//	cout << "end graph" << endl;
		sfs[i] = sf;
		// set up the periods for the stateflow
		// in general, period_choice should be ApproximateAnalysis1
		//	cout << "Begin Period" << endl;		
		{
			int nPeriod = sizeof(RandomGenerator::STATEFLOW_BASE_Richie) / sizeof(RandomGenerator::STATEFLOW_BASE_Richie[0]);
			int nFactor = sizeof(RandomGenerator::STATEFLOW_FACTOR_Richie) / sizeof(int);
			int period_base = pcTaskArray[i].getPeriod();

			int k = 0;
			for (vector<Transition*>::iterator iter = sf->trans.begin(); iter != sf->trans.end(); iter++) {
				Transition* t = *iter;

				int period_factor = RandomGenerator::STATEFLOW_FACTOR_Richie[rand() % nFactor];

				t->period = period_base * period_factor * iScale;

				t->priority = k++;
			}
		}
		//	cout << "End Period" << endl;
	}

	//double* util = Utility::uniformly_distributed(num, tUtil);
	double dTotalUtil = 0.40;
	double* util = new double[num];
	double dUtilTotalShare = 0;
	for (int i = 0; i < num; i++)
	{
		dUtilTotalShare += pcTaskArray[i].getUtilization();
	}

	for (int i = 0; i < num; i++)
	{
		util[i] = dTotalUtil * pcTaskArray[i].getUtilization() / dUtilTotalShare;;
	}

	// set up the wcets for the stateflow based on the expected utilization
	//cout << "Begin WCET" << endl;
	for (int i = 0; i<num; i++) {
		if (i == sIndex) continue;

		RandomGenerator::Richie_setup_wcets_for_one_stateflow(sfs[i], util[i]);
		//setup_wcets_for_one_stateflow(sfs[i], tUtil/num);
	}
	//cout << "End WCET" << endl;
	// for the special one
	if (sIndex != -1) {
		//cout << sIndex << endl;
		//cout << "Special ?" << endl;
		string name = "Input\\OneSpecial.dot";
		const char *p = name.c_str();

		Stateflow* sf = FileReader::ReadOneStateflow(1, p);
		// set wcets
		for (vector<Transition*>::iterator iter = sf->trans.begin(); iter != sf->trans.end(); iter++) {
			Transition* t = *iter;
			if (t->period == 100000) t->wcet = 10000 + rand() % 5000;
			if (t->period == 20000) {
				int wcet = util[sIndex] * t->period;
				if (wcet == 0) wcet = rand() % 5 + 1;
				t->wcet = wcet;
			}
		}
		//cout << "Begin Data" << endl;
		sf->calculate_gcd();
		sf->calculate_hyperperiod();
		sf->set_state_number();
		sf->generate_rbf_time_instances();
		sf->generate_rbfs();
		sf->generate_exec_req_matrix();
		//Utility::output_matrix(sf->exec_req_matrix,sf->n_state,sf->n_state);
		sf->calculate_linear_factor();
		//cout << "End Data" << endl;
		sfs[sIndex] = sf;
	}

	FileWriter::DotFileWriter(sfs, num, "simulink.tskst.fsm.txt");

	delete[] util;	
}


#ifdef WINDOWS

void TestFocusRefinementPeriodicTaskApprox(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMPeriodicTaskApprox" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			sprintf_s(axFSMFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2fto%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
				0.40, 0.40, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%sPrimitve_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%sPrimitive_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s -SchedTestOption=LookUpTable -Suffix=FSMPeriodicTaskApproxPrimitive"
					, axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%sPrimitive_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_FSM_%sPrimitive_NSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementFSMRBFSO(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			sprintf_s(axFSMFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2fto%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
				0.40, 0.40, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_LookUpPrimitive_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_LookUpPrimitive_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s -SchedTestOption=LookUpTable -Suffix=FSMRBFSO_LookUpPrimitive",
					axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_LookUpPrimitive_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSM_LookUpPrimitive_NSweep.txt");
#endif
	}
}

void TestFocusRefinementFSMRBFSONoBitMask(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			sprintf_s(axFSMFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2fto%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
				0.40, 0.40, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

			sprintf_s(axBuffer, "%s_FR_%s_NoBitMaskPrimitive_Result.rslt", axFileName, axSystemType);
#if ASSISTANT			
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif			
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s -Suffix=FSMRBFSO_NoBitMaskPrimitive", axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_NoBitMaskPrimitive_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSM_NoBitMaskPrimitive_NSweep.txt");
#endif
	}
}

void TestFocusRefinementFSMRBFSOApproximation(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			sprintf_s(axFSMFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2fto%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
				0.40, 0.40, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

			sprintf_s(axBuffer, "%s_FR_%s_ApproxPrimitive_Result.rslt", axFileName, axSystemType);
#if ASSISTANT			
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif			
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s -Suffix=FSMRBFSO_ApproxPrimitive -SchedTestOption=LookUpTable -InstanceApproximation=3 -BusyStartApproximation=1",
					axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_ApproxPrimitive_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSM_ApproxPrimitive_NSweep.txt");
#endif
	}
}

void TestPeriodicTaskApproxILP(char axDstFolder[], char axFSMFolder[])
{
	char axBuffer[2048] = { 0 };
	char axFileName[512] = { 0 };
	char axFSMFileName[512] = { 0 };
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iSizeN = sizeof(aiTaskN) / sizeof(int);
	if (0)
	{
		for (int iN = 0; iN < iSizeN; iN++)
		{						
			sprintf_s(axBuffer, "%s\\FSMNSweepRandomU_SingleTaskApprox\\U%.2fto%.2f_N%d", axDstFolder, 0.40, 0.40, aiTaskN[iN]);
			MakePath(axBuffer);
			for (int j = 0; j < 1000; j++)
			{				
				cout << "N=" << aiTaskN[iN] << " i=" << j << endl;
				sprintf_s(axFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[iN], j + 1);
				sprintf_s(axFSMFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[iN], j + 1);

				sprintf_s(axBuffer, "%s\\FSMNSweepRandomU_SingleTaskApprox\\U%.2fto%.2f_N%d\\TaskSet%d.fsmp.tskst", axDstFolder, 0.40, 0.40, aiTaskN[iN], j + 1);
				if (!IsFileExist(axBuffer))
				{
					sprintf_s(axBuffer, "MCMILPPact.exe GenFSMPeridoicTaskApproximation -TaskSetFile=%s -FSMFile=%s -Target=%s\\FSMNSweepRandomU_SingleTaskApprox\\U%.2fto%.2f_N%d\\TaskSet%d",
						axFileName, axFSMFileName, axDstFolder, 0.40, 0.40, aiTaskN[iN], j + 1);
					system(axBuffer);
				}				
			}			
		}
	}
	if (1)
	{
		StatisticSet cStatistic;
		char axBuffer[1024] = { 0 };
		char axFileName[512] = { 0 };
		int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
		int iN = sizeof(aiTaskN) / sizeof(int);
		cout << endl << "Running test..." << endl;
		int iVolume = 1000;
		for (int i = 0; i < iN; i++)
		{
			//start the test
			double dTime = 0;
			double dCPUTime_TPRed = 0;
			double dCPUTime_MILP = 0;
			int iTPRedTime = 0;
			int iAccepted = 0;
			double dNormalizedDelay = 0;
			int iSchedulableTaskSet = 0;

			//Test Point Reduction
			TaskSet * pcTaskSetArray = new TaskSet[iVolume];
			bool * pbSchedulable = new bool[iVolume];
			for (int j = 0; j < iVolume; j++)
			{
				StatisticSet cThisStatistic;
				sprintf_s(axFileName, "%s\\FSMNSweepRandomU_SingleTaskApprox\\U0.40to0.40_N%d\\TaskSet%d.fsmp.tskst", axDstFolder, aiTaskN[i], j + 1);
				printf_s("\r%s.tpcc    ", axFileName);

				pcTaskSetArray[j].ReadImageFile(axFileName);
				TaskSet & cTaskSet = pcTaskSetArray[j];
				//Test first if Schedulable
				AudsleyEngine<SchedTest_MILPRbf> cAudsley;
				TPCCSet cTPCC;
				cTPCC.Initialize(cTaskSet);
				cTPCC.GenRawTPCC();
				cAudsley.Initialize(cTaskSet, &cTPCC);
				if (cAudsley.Run())
				{
					int iTPRedTimeTemp = clock();
					pbSchedulable[j] = true;
					sprintf_s(axBuffer, "%s_tpredinfo", axFileName);
					if (!IsFileExist(axBuffer))
					{						
						sprintf_s(axBuffer, "MCMILPPact.exe LOTPTaskSet %s", axFileName);
						ExecuteSelf(axBuffer);
					}
					iTPRedTime += clock() - iTPRedTimeTemp;
					sprintf_s(axBuffer, "%s_tpredinfo", axFileName);
					cThisStatistic.ReadStatisticImage(axBuffer);
					dCPUTime_TPRed += cThisStatistic.getItem("CPU Time").getValue();
					//remove(axBuffer);
				}
				else
				{
					pbSchedulable[j] = false;
				}
			}


			for (int j = 0; j < iVolume; j++)
			{
				StatisticSet cThisStatistic;
				sprintf_s(axFileName, "%s\\FSMNSweepRandomU_SingleTaskApprox\\U0.40to0.40_N%d\\TaskSet%d.fsmp.tskst", axDstFolder, aiTaskN[i], j + 1);
				printf_s("\r%s    ", axFileName);

				int iTPRedTimeTemp = clock();
				TaskSet & cTaskSet = pcTaskSetArray[j];

				if (!pbSchedulable[j])
				{
					dNormalizedDelay += 1;
					continue;
				}
				//Test first if Schedulable
				AudsleyEngine<SchedTest_MILPRbf> cAudsley;
				sprintf_s(axBuffer, "%s.lotpcc.tpcc", axFileName);
				TPCCSet cTPCC;
				cTPCC.ReadTPCCImage(axBuffer);
				cAudsley.Initialize(cTaskSet, &cTPCC);
				int iMILPTemp = clock();
				if (cAudsley.Run())
				{
					iSchedulableTaskSet++;

					sprintf_s(axBuffer, "%s_LO.rslt", axFileName);
					if (!IsFileExist(axBuffer))
					{
						//Second Run the MILP
						//sprintf_s(axBuffer, "MCMILPPact.exe MCSRMiniDelay LO %s quiet -timeout=1200 %s.lotpcc.tpcc", axFileName, axFileName);
						sprintf_s(axBuffer, "MCMILPPact.exe SimulinkMILP NoMemLnkTypeLO %s -display=0 -Timeout=1200 -tpcc=%s.lotpcc.tpcc",
							axFileName, axFileName);
						ExecuteSelf(axBuffer);
					}
					//read the result 
					sprintf_s(axBuffer, "%s_LO.rslt", axFileName);
					cThisStatistic.ReadStatisticImage(axBuffer);
					if ((strcmp(cThisStatistic.getItem("Feasibility").getString(), "Feasible") == 0))
					{
						iAccepted += 1;
						if (cThisStatistic.getItem("Worst Delay").getValue() > 0)
							dNormalizedDelay += cThisStatistic.getItem("Best Delay").getValue() / cThisStatistic.getItem("Worst Delay").getValue();
					}
					else
					{
						dNormalizedDelay += 1;
					}
					dTime += cThisStatistic.getItem("Time Elapsed").getValue();
					dCPUTime_MILP += cThisStatistic.getItem("CPU Time").getValue();
				}
				else
				{
					dNormalizedDelay += 1;
					dTime += clock() - iMILPTemp;
				}

			}
			sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, iAccepted);
			sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
			sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dCPUTime_MILP / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task TPRed Run Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)iTPRedTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task TPRed CPU Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dCPUTime_TPRed / (double)iSchedulableTaskSet);

			cStatistic.WriteStatisticText("FSMPeriodicApproxILP.txt");
		}
	}


}

void TestFocusRefinementFSMRBFSOUSweep(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90 };
	int iSystemSize = 25;
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s\\FSMUSweep\\U%.2f_N%d\\TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
			sprintf_s(axFSMFileName, "%s\\FSMUSweep\\U%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, aiTaskN[i], iSystemSize, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
				aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s", axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSM.txt");
#endif
	}
}

void TestFocusRefinementFSMRBFSOKSweep(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double dUtil = 0.40;
	int aiK[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	int iN = sizeof(aiK) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };
	char axSuffix[512] = { 0 };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
		sprintf_s(axSuffix, "%sK%d", axSystemType, aiK[i]);
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s\\TaskSet%d.tskst", axDstFolder, aiK[i], dUtil, j + 1);
			sprintf_s(axFSMFileName, "%s\\TaskSet%d.tskst.fsm.txt", axFSMFolder, aiK[i], dUtil, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "K= TaskSet%d.tskst Avg Time: %.2fms",
				aiK[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted %d 1200 0 -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
					axSystemType, axFileName, aiK[i], axSuffix, axSuffix, axSuffix);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_KSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementFSMRBFSONKSweep(char axDstFolder[], char axFSMFolder[])
{
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };
	char axSuffix[512] = { 0 };
	int iKMin = 2;
	int iKMax = 7;
	StatisticSet * pcStatistic = new StatisticSet[iKMax - iKMin + 1];
	for (int i = 0; i < iN; i++)
	{
		for (int k = iKMin; k <= iKMax; k++)
		{
			StatisticSet & cStatistic = pcStatistic[k - iKMin];
			sprintf_s(axSuffix, "%sK%d", axSystemType, k);
			//start the test
			double dTime = 0;
			double dCPUTime = 0;
			double dILPTime = 0;
			double dUCCompTime = 0;
			int iAccepted = 0;
			double dNormalizedDelay = 0;
			int iSchedulableTaskSet = 0;
			int iTotalIteration = 0;
			double dPreanalysisTime = 0;
#if ASSISTANT
			for (int j = iVolume - 1; j >= 0; j--)
#else
			for (int j = 0; j < iVolume; j++)
#endif
			{
				StatisticSet cThisStatistic;
				sprintf_s(axFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
				sprintf_s(axFSMFileName, "%s\\FSMNSweepRandomU\\U%.2fto%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);
				TaskSet cTaskSet;
				cTaskSet.ReadImageFile(axFileName);

				sprintf_s(axBuffer, "K=%d U%.2fto%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
					k, 0.40, 0.40, aiTaskN[i], j + 1, dTime / (j + 1));
				cout << "\r" << axBuffer << "       ";

#if ASSISTANT
				sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix);
				if (IsFileExist(axBuffer))
				{
					continue;
				}
#endif

				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				if (!IsFileExist(axBuffer))
				{
					sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted %d 1200 0 -FSMFile=%s -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
						axSystemType, axFileName, k, axFSMFileName, axSuffix, axSuffix, axSuffix);
					ExecuteSelf(axBuffer);
				}
				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				cThisStatistic.ReadStatisticImage(axBuffer);

				string stringStatus = cThisStatistic.getItem("Status").getString();
				if (stringStatus.compare("Optimal") == 0)
				{
					iAccepted += 1;
					double dObjective = cThisStatistic.getItem("Objective").getValue();
					double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
					if (dObjective > 0)
					{
						dNormalizedDelay += dObjective / dWorstDelay;
					}
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Timeout") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Abort") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Infeasible") == 0)
				{
					dNormalizedDelay += 1;
				}
				else
				{
					my_assert(0, "Unknown FR status");
				}
				dTime += cThisStatistic.getItem("Total Time").getValue();
				dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
				dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
				dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
				iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
				dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
			}
			sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, iAccepted);
			sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
			sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
			sprintf_s(axBuffer, "FocusRefinement_%s_NKSweep.txt", axSuffix);
			cStatistic.WriteStatisticText(axBuffer);
#endif
		}
	}
	delete[] pcStatistic;
}

void TestFocusRefinementFSMRBFSOUKSweep(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90 };
	int iSystemSize = 25;
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };
	char axSuffix[512] = { 0 };
	int iKMin = 2;
	int iKMax = 7;
	StatisticSet * pcStatistic = new StatisticSet[iKMax - iKMin + 1];
	for (int i = 0; i < iN; i++)
	{
		for (int k = iKMin; k <= iKMax; k++)
		{
			sprintf_s(axSuffix, "%sK%d", axSystemType, k);
			StatisticSet cStatistic = pcStatistic[k - iKMin];
			//start the test
			double dTime = 0;
			double dCPUTime = 0;
			double dILPTime = 0;
			double dUCCompTime = 0;
			int iAccepted = 0;
			double dNormalizedDelay = 0;
			int iSchedulableTaskSet = 0;
			int iTotalIteration = 0;
			double dPreanalysisTime = 0;
#if ASSISTANT
			for (int j = iVolume - 1; j >= 0; j--)
#else
			for (int j = 0; j < iVolume; j++)
#endif
			{
				StatisticSet cThisStatistic;
				sprintf_s(axFileName, "%s\\FSMUSweep\\U%.2f_N%d\\TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
				sprintf_s(axFSMFileName, "%s\\FSMUSweep\\U%.2f_N%d\\TaskSet%d.tskst.fsm.txt", axFSMFolder, aiTaskN[i], iSystemSize, j + 1);
				TaskSet cTaskSet;
				cTaskSet.ReadImageFile(axFileName);

				sprintf_s(axBuffer, "K=%d, U%.2f_N%d\\TaskSet%d.tskst Avg Time: %.2fms",
					k, aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
				cout << "\r" << axBuffer << "       ";

#if ASSISTANT
				sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix);
				if (IsFileExist(axBuffer))
				{
					continue;
				}
#endif

				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				if (!IsFileExist(axBuffer))
				{
					sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted %d 1200 0 -FSMFile=%s -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
						axSystemType, axFileName, k, axFSMFileName, axSuffix, axSuffix, axSuffix);
					ExecuteSelf(axBuffer);
				}
				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				cThisStatistic.ReadStatisticImage(axBuffer);

				string stringStatus = cThisStatistic.getItem("Status").getString();
				if (stringStatus.compare("Optimal") == 0)
				{
					iAccepted += 1;
					double dObjective = cThisStatistic.getItem("Objective").getValue();
					double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
					if (dObjective > 0)
					{
						dNormalizedDelay += dObjective / dWorstDelay;
					}
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Timeout") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Abort") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Infeasible") == 0)
				{
					dNormalizedDelay += 1;
				}
				else
				{
					my_assert(0, "Unknown FR status");
				}
				dTime += cThisStatistic.getItem("Total Time").getValue();
				dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
				dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
				dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
				iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
				dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
			}
			sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, iAccepted);
			sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
			sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
			sprintf_s(axBuffer, "FocusRefinement_%s_UKSweep.txt", axSuffix);
			cStatistic.WriteStatisticText(axBuffer);
#endif
		}

	}
}
#endif
#endif

#if 1
struct TestBnbFSMRBFSONSweep_ThreadArg
{
	int * pi;
	int * pj;
	int iVolume;
	const char * axDstFolder;
	const char * axFSMFolder;
	const int * piTaskN;
	int iN;
	int iSystemType;
	mutex * pcLock;
	bool bUseLookUpTableSchedTest;
};

void TestBnbFSMRBFSONSweep_Thread(struct TestBnbFSMRBFSONSweep_ThreadArg * pvArg)
{
	TestBnbFSMRBFSONSweep_ThreadArg & rtagArgs = *(TestBnbFSMRBFSONSweep_ThreadArg*)pvArg;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	char axCmdBuffer[2048] = { 0 };
	int & iGlobali = *rtagArgs.pi;
	int & iGlobalj = *rtagArgs.pj;
	int iVolume = rtagArgs.iVolume;
	int iN = rtagArgs.iN;
	const char * axDstFolder = rtagArgs.axDstFolder;
	const int * aiTaskN = rtagArgs.piTaskN;
	const char * axFSMFolder = rtagArgs.axFSMFolder;
	char axSystemTypeSuffix[128] = {};
	double dTimeout = 1200;
	switch (rtagArgs.iSystemType)
	{
	case 1: //FSM
		sprintf_s(axSystemTypeSuffix, "FSMRBFSO");
		break;
	case 2: //AMC-max
		sprintf_s(axSystemTypeSuffix, "AMCMax");
		break;
	case 3: //AMC-rtb
		sprintf_s(axSystemTypeSuffix, "AMCRtb");
		break;
	default:
		cout << "Unknown system type" << endl;
		assert(0);
		break;
	}

	while (1)
	{
		//WaitForSingleObject(*rtagArgs.pcLock, INFINITE);
		rtagArgs.pcLock->lock();
		if (iGlobalj == iVolume)
		{
			iGlobalj = 0;
			iGlobali++;
		}
		if (iGlobali == iN)
		{
			//ReleaseMutex(*rtagArgs.pcLock);
			rtagArgs.pcLock->unlock();
			break;
		}
		int i = iGlobali;
		int j = iGlobalj;
		iGlobalj++;
		rtagArgs.pcLock->unlock();

		FSMTaskSet cTaskSet;
		Timer cTimer;

		SimulinkMiniDelayBnB_FSMRBFSO *pcBnBFSMRBFSO = NULL;
		SimulinkMiniDelayBnB_AMCMax *pcBnBAMCMax = NULL;
		SimulinkMiniDelayBnB_AMCRtb *pcBnBAMCRtb = NULL;
		switch (rtagArgs.iSystemType)
		{
		case 1: //FSM

			//sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT.rslt", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
#if 0
			if (rtagArgs.bUseLookUpTableSchedTest)
				sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT_LookUpTable.rlst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
			else
				sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT_NoLookUpTable.rslt", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
#endif
			sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d.tskst_BnB_FSMRBFSO_LookUpTable_%d",
				axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, (int)rtagArgs.bUseLookUpTableSchedTest);
			if (IsFileExist(axBuffer))	continue;
			sprintf_s(axFileName, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			sprintf_s(axFSMFileName, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);

#if 0
			cTaskSet.ReadImageFile(axFileName);
			cTaskSet.ReadStateflow(axFSMFileName);
			pcBnBFSMRBFSO = new SimulinkMiniDelayBnB_FSMRBFSO(cTaskSet);
			if (rtagArgs.bUseLookUpTableSchedTest)
				pcBnBFSMRBFSO->m_cUnschedCore.setSchedTestOption(UnschedCoreComputer::LookUpTable);
			else
				pcBnBFSMRBFSO->m_cUnschedCore.setSchedTestOption(UnschedCoreComputer::Original);
			cTimer.StartThread();
			pcBnBFSMRBFSO->Run(0, dTimeout);
			cTimer.StopThread();
			if (rtagArgs.bUseLookUpTableSchedTest)
				sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT_LookUpTable", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
			else
				sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT_NoLookUpTable", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
			pcBnBFSMRBFSO->WriteStatisticFile(axBuffer);
			delete pcBnBFSMRBFSO;
#endif			
			sprintf_s(axCmdBuffer, "./MCMILPPact.exe SimulinkFSMBnB -TaskSetFile=%s -FSMFile=%s -UseLookUpTable=%d -Timeout=%.2f",
				axFileName, axFSMFileName, rtagArgs.bUseLookUpTableSchedTest, dTimeout);
			system(axCmdBuffer);
			break;
		case 2: //AMC-max			
			sprintf_s(axBuffer, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d_BnB_%s_MT.rslt", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1, axSystemTypeSuffix);
			if (IsFileExist(axBuffer))	continue;
			sprintf_s(axFileName, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1);
			cTaskSet.ReadImageFile(axFileName);
			pcBnBAMCMax = new SimulinkMiniDelayBnB_AMCMax(cTaskSet);
			cTimer.StartThread();
			pcBnBAMCMax->Run(0, dTimeout);
			cTimer.StopThread();
			sprintf_s(axBuffer, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d_BnB_%s_MT", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1, axSystemTypeSuffix);
			pcBnBAMCMax->WriteStatisticFile(axBuffer);
			delete pcBnBAMCMax;
			break;
		case 3: //AMC-rtb		
			sprintf_s(axBuffer, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d_BnB_%s_MT.rslt", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1, axSystemTypeSuffix);
			if (IsFileExist(axBuffer))	continue;
			sprintf_s(axFileName, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1);
			cTaskSet.ReadImageFile(axFileName);
			pcBnBAMCRtb = new SimulinkMiniDelayBnB_AMCRtb(cTaskSet);
			cTimer.StartThread();
			pcBnBAMCRtb->Run(0, dTimeout);
			cTimer.StopThread();
			sprintf_s(axBuffer, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d_BnB_%s_MT", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1, axSystemTypeSuffix);
			pcBnBAMCRtb->WriteStatisticFile(axBuffer);
			delete pcBnBAMCRtb;
			break;
		default:
			cout << "Unknown system type" << endl;
			assert(0);
			break;
		}
		double dThreadTime = cTimer.getElapsedThreadTime_ms();

		StatisticSet cStat;
		cStat.ReadStatisticImage((char*)(string(axBuffer) + string(".rslt")).data());
		cStat.setItem("Thread Time(ms)", dThreadTime);
		cStat.WriteStatisticImage((char*)(string(axBuffer) + string(".rslt")).data());
		cStat.WriteStatisticText((char*)(string(axBuffer) + string(".txt")).data());
	}		
}

void TestBnbFSMRBFSONSweep_MT(char axDstFolder[], char axFSMFolder[], int iThreadNum, int iSystemType, int iUseLookUpTable)
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskNAMC[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, /*45, 50, 55, 60, 65, 70, 75, 80, 85, 90,
																						  95, 100 */ };
	int aiTaskNFSM[] = { 5, 10, 15, 20, 25, 30, 35, /*40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 */ };
	int iN = 0;
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	char axSystemTypeSuffix[128] = { 0 };
	int * aiTaskN = NULL;
	switch (iSystemType)
	{
	case 1: //FSM
		sprintf_s(axSystemTypeSuffix, "FSMRBFSO");
		aiTaskN = aiTaskNFSM;
		iN = sizeof(aiTaskNFSM) / sizeof(int);
		break;
	case 2: //AMC-max
		aiTaskN = aiTaskNAMC;
		iN = sizeof(aiTaskNAMC) / sizeof(int);
		sprintf_s(axSystemTypeSuffix, "AMCMax");
		break;
	case 3: //AMC-rtb
		aiTaskN = aiTaskNAMC;
		iN = sizeof(aiTaskNAMC) / sizeof(int);
		sprintf_s(axSystemTypeSuffix, "AMCRtb");
		break;
	default:
		cout << "Unknown system type" << endl;
		assert(0);
		break;
	}

	deque<int> dequeNs;
	mutex cLock;
	TestBnbFSMRBFSONSweep_ThreadArg * ptagArgs = new TestBnbFSMRBFSONSweep_ThreadArg[iThreadNum];
	std::thread * pcThreads = new std::thread[iThreadNum];
	int iGlobali = 0;
	int iGlobalj = 0;
	Timer cTimer;
	cTimer.Start();
	for (int i = 0; i < iThreadNum; i++)
	{
		ptagArgs[i].axDstFolder = axDstFolder;
		ptagArgs[i].axFSMFolder = axFSMFolder;
		ptagArgs[i].iN = iN;
		ptagArgs[i].iVolume = iVolume;
		ptagArgs[i].pcLock = &cLock;
		ptagArgs[i].pi = &iGlobali;
		ptagArgs[i].pj = &iGlobalj;
		ptagArgs[i].piTaskN = aiTaskN;
		ptagArgs[i].iSystemType = iSystemType;
		ptagArgs[i].bUseLookUpTableSchedTest = iUseLookUpTable == 1;
		//pcHandles[i] = _beginthreadex(0, 0, &TestBnbFSMRBFSONSweep_Thread, (void*)&ptagArgs[i], 0, 0);
		pcThreads[i] = std::thread(TestBnbFSMRBFSONSweep_Thread, &ptagArgs[i]);
	}
	cout << iThreadNum << " threads created" << endl;
	for (int i = 0; i < iThreadNum; i++)
	{
		pcThreads[i].join();
	}
	cTimer.Stop();
	bool bNotFinished = false;
	for (int i = 0; i < iN; i++)
	{
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		double dTime = 0;
		for (int j = 0; j < iVolume; j++)
		{
			switch (iSystemType)
			{
			case 1:
#if 0
				if (iUseLookUpTable == 1)
					sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT_LookUpTable.rslt", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
				else
					sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d_BnB_%s_MT_NoLookUpTable.rslt", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, axSystemTypeSuffix);
#endif				
				sprintf_s(axBuffer, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d.tskst_BnB_FSMRBFSO_LookUpTable_%d.rslt",
					axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1, iUseLookUpTable);

				break;
			case 2:
			case 3:
				sprintf_s(axBuffer, "%s/NSweepRandomU/U%.2fto%.2f_CF2.00_N%d/TaskSet%d_BnB_%s_MT.rslt", axDstFolder, 0.50, 0.95, aiTaskN[i], j + 1, axSystemTypeSuffix);
				break;
			default:
				break;
			}

			if (!IsFileExist(axBuffer))
			{
				cout << axBuffer << " not finished" << endl;
				bNotFinished = true;
				break;
			}
			StatisticSet cStatistic;
			cStatistic.ReadStatisticImage(axBuffer);
			iAccepted++;
			if (strcmp(cStatistic.getItem("Status").getString(), "Infeasible") == 0)
			{
				iAccepted--;
				dNormalizedDelay += 1;
			}
			else
			{
				double dObjective = cStatistic.getItem("Objective").getValue();
				double dObjectiveUB = cStatistic.getItem("Objective UB").getValue();
				double dThisNormalizedDelay = 0;
				if (dObjectiveUB > 0)
				{
					dThisNormalizedDelay = dObjective / dObjectiveUB;
				}
				dNormalizedDelay += dThisNormalizedDelay;
			}
			//dTime += cStatistic.getItem("Thread Time(ms)").getValue();
			dTime += cStatistic.getItem("Thread CPU Time").getValue();
		}
		if (bNotFinished)
			break;
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		//cout << dNormalizedDelay << endl;
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, 0);
		if (iUseLookUpTable == 1)
			sprintf_s(axBuffer, "BnB_%s_LookUpTable_NSweep.txt", axSystemTypeSuffix);
		else
			sprintf_s(axBuffer, "BnB_%s_NoLookUpTable_NSweep.txt", axSystemTypeSuffix);
		cStatistic.WriteStatisticText(axBuffer);
	}

	delete[] ptagArgs;	
	return;
}

#endif

void ReadUnschedTestedInstance()
{
	char axBuffer[2048] = { 0 };
	map<int, int> m_mapOccurrenceTable;	
	StatisticSet cStatisticSet;
	for (int iN = 5; iN < 100; iN += 5)
	{
		for (int i = 0; i < 1000; i++)
		{			
			sprintf_s(axBuffer,
				"\\\\RICHIEZHAO-PC\\FSMExperiment\\FSMNSweepRandomU\\U0.40to0.40_N%d\\TaskSet%d.tskst_FSMRBFSO_NoBitMaskPrimitive_Log.txt", iN, i);			
			ifstream ifstreamFile(axBuffer);	
			if (ifstreamFile.is_open() == false)
			{
				cout << "\rProcessing Task " << i << " N=" << iN << " Not Exists   ";
				ifstreamFile.close();
				continue;
			}
			assert(ifstreamFile.is_open());
			cout << "\rProcessing Task " << i << " N=" << iN << "           ";
			int iStatus = 0;
			while (ifstreamFile.eof() == false)
			{
				ifstreamFile.getline(axBuffer, 2048);
				string stringLine(axBuffer);
				if (stringLine.compare("---------------------Unsched Scenario Tested # Instances-------------------------") == 0)
				{
					iStatus = 1;					
					ifstreamFile.getline(axBuffer, 2048);					
					stringLine = axBuffer;
				}

				if (iStatus == 1)
				{
					if ((stringLine.compare("----------------------------------------------") == 0) || (stringLine.compare("---------------------Unsched Scenario Trigger Time Status-------------------------") == 0))
					{
						iStatus = 0;
						break;
					}
					else
					{
						int iInstance = 0;
						int iNInstance = 0;
						double dRatio = 0;						
						//cout << stringLine.data();
						sscanf_s(stringLine.data(), "%d Instances: %d, Ratio: %lf%%", &iInstance, &iNInstance, &dRatio);
					//	cout << " " << iInstance << " " << iNInstance << " " << dRatio << endl;
						assert(iInstance >=0);
						assert(iNInstance >= 0);
						if (m_mapOccurrenceTable.count(iInstance))
						{
							m_mapOccurrenceTable[iInstance] += iNInstance;
						}
						else
						{
							m_mapOccurrenceTable[iInstance] = iNInstance;
						}
					}
				}
			}
			ifstreamFile.close();
		}
	}
	cout << endl;
	int iTotal = 0;
	int iIndex = 0;
	for(map<int, int>::iterator iter = m_mapOccurrenceTable.begin(); iter != m_mapOccurrenceTable.end(); iter++)
	{
		sprintf_s(axBuffer, "%c-%d Instances", 'A' + iIndex, iter->first);
		cStatisticSet.setItem(axBuffer, iter->second);
		iIndex++;
		iTotal += iter->second;		
	}

	cStatisticSet.setItem("%c-Total", iTotal);
	cStatisticSet.WriteStatisticImage("FSMRBFSO_UnschedInstanceTested");
	cStatisticSet.WriteStatisticText("FSMRBFSO_UnschedInstanceTested.txt");

	int iAccumulative = 0;
	for(map<int, int>::iterator iter = m_mapOccurrenceTable.begin(); iter != m_mapOccurrenceTable.end(); iter++)
	{
		iAccumulative += iter->second;
		sprintf_s(axBuffer, "\\hline %d & %d & %.4f\\%% & %.4f\\%% \\\\",
			iter->first, iter->second, (double)iter->second / (double)iTotal * 100, (double)iAccumulative / (double)iTotal * 100);
		cout << axBuffer << endl;
	}
	printf_s("Total: %d\n", iTotal );
}

#ifdef LINUX
void TestFocusRefinementFSMRBFSONoBitMaskUSweep(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90 };
	int iSystemSize = 25;
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/FSMUSweep/U%.2f_N%d/TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
			sprintf_s(axFSMFileName, "%s/FSMUSweep/U%.2f_N%d/TaskSet%d.tskst.fsm.txt", axFSMFolder, aiTaskN[i], iSystemSize, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
				aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_NoBitMask_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_NoBitMask_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s -Suffix=FSMRBFSO_NoBitMask -LookUpTableSchedTest=0", axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_NoBitMask_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSMRBFSONoBitMask_USweep.txt");
#endif
	}
}
#endif

void TestFIJCaseStudy()
{
	//MCMILPPact SimulinkFR FSMRBFSO .\simulinkdata.tskst unweighted 5 1e74 1 -FSMFile=.\simulink.tskst.fsm.txt -LookUpTableSchedTest=1
	//MCMILPPact SimulinkFR FSMRBFSO .\simulinkdata.tskst unweighted 5 1e74 1 -FSMFile=.\simulink.tskst.fsm.txt -LookUpTableSchedTest=0 -Suffix=RBFSONoBitMask
#if 0
	cout << currentDateTime() << endl;
	system("MCMILPPact SimulinkFR FSMRBFSO .\\simulinkdata.tskst unweighted 5 1e74 1 -FSMFile=.\\simulink.tskst.fsm.txt -LookUpTableSchedTest=1");
	cout << currentDateTime() << endl;
	system("MCMILPPact SimulinkFR FSMRBFSO .\\simulinkdata.tskst unweighted 5 1e74 1 -FSMFile=.\\simulink.tskst.fsm.txt -LookUpTableSchedTest=0 -Suffix=RBFSONoBitMask");
#endif
	FSMTaskSet cFSM;
	cFSM.ReadImageFile(".\\simulinkdata.tskst");
	cFSM.ReadStateflow(".\\simulink.tskst.fsm.txt");
	SimulinkMiniDelayBnB_FSMRBFSO cBnBModel(cFSM);
	cout << cBnBModel.m_cUnschedCore.getSchedTestOption() << endl;
	cout << currentDateTime() << endl;
	cBnBModel.Run(1, 1e70);
	cBnBModel.WriteStatisticFile("FSMRBFSO_BnB_Result");
}

#ifdef WINDOWS



#endif