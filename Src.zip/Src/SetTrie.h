#pragma once
#include <deque>
#include "MySet.h"
template<class T, class CMP = less<T>, class Alloc = std::allocator<T> >
class SetTrie
{
public:
	typedef T	Element;
	typedef MySet<T, CMP, Alloc> ElementSet;
	
	struct SetTrieNode
	{	
		typedef SetTrieNode	NodeType;	
		struct SetTrieNodeCompare
		{	
			bool operator() (const NodeType & rcLHS, const NodeType & rcRHS)
			{
				CMP comparator;
				return comparator(rcLHS.cElement, rcRHS.cElement);
			}
		};

		typedef MySet< NodeType, SetTrieNodeCompare> NodePtrSet;
		//typedef deque< NodeType *> NodePtrDeque;		
		T cElement;
		NodePtrSet cSuccessors;
		bool bEndOfSet;

		SetTrieNode()
		{
			bEndOfSet = false;
		}

		SetTrieNode(const T & rcElement)
		{
			cElement = rcElement;
			bEndOfSet = false;
		}	
	};
protected:
	typedef SetTrieNode	NodeType;	
	NodeType m_cRootNode;
public:
	SetTrie()
	{
		
	}

	~SetTrie()
	{

	}

	void insert(ElementSet & rcElementSet)
	{
		NodeType * pcNode = &m_cRootNode;
		for (typename ElementSet::iterator iter = rcElementSet.begin(); iter != rcElementSet.end(); iter++)
		{			
			NodeType QueryNode(*iter);
			typename NodeType::NodePtrSet::iterator iterFind = pcNode->cSuccessors.find(QueryNode);
			if (iterFind != pcNode->cSuccessors.end())
			{
				pcNode = (NodeType * )&(*iterFind);
			}
			else
			{
				pcNode = (NodeType *)AllocateNewNode(*iter, *pcNode);
			}

		}
		pcNode->bEndOfSet = true;
	}

	void remove(ElementSet & rcElementSet)
	{
	
	}

	bool find(ElementSet & rcElementSet)
	{
		NodeType * pcNode = &m_cRootNode;
		for (typename ElementSet::iterator iter = rcElementSet.begin(); iter != rcElementSet.end(); iter++)
		{
			NodeType QueryNode(*iter);
			typename NodeType::NodePtrSet::iterator iterFind = pcNode->cSuccessors.find(QueryNode);
			if (iterFind != pcNode->cSuccessors.end())
			{
				pcNode = (NodeType *)&(*iterFind);
			}
			else
			{
				return false;
			}
		}		

		if (pcNode->bEndOfSet)
			return true;

		return false;
	}

	bool ExistSubset(ElementSet & rcElementSet)
	{
		if (rcElementSet.empty())
			return false;
		for (typename NodeType::NodePtrSet::iterator iterSucc = m_cRootNode.cSuccessors.begin();
			iterSucc != m_cRootNode.cSuccessors.end(); iterSucc++)
		{
			int iStatus = ExistSubsetRecur((NodeType &)*iterSucc, rcElementSet);
			if (iStatus == 1)
				return true;
		}
		return false;
	}
	
	bool ExistSupset(ElementSet & rcElementSet)
	{
		if (rcElementSet.empty())
			return false;
		for (typename NodeType::NodePtrSet::iterator iterSucc = m_cRootNode.cSuccessors.begin();
			iterSucc != m_cRootNode.cSuccessors.end(); iterSucc++)
		{
			int iStatus = ExistSupsetRecur((NodeType &)*iterSucc, rcElementSet.begin(), rcElementSet);
			if (iStatus == 1)
				return true;
		}
		return false;
	}

private:
	int ExistSubsetRecur(NodeType & rcCurrentNode, ElementSet & rcElementSet)
	{
		Element & rcElementInNode = rcCurrentNode.cElement;
		typename ElementSet::iterator iterFind = rcElementSet.find(rcElementInNode);
		if (iterFind == rcElementSet.end())
			return 0;

		if ((rcCurrentNode.bEndOfSet))
			return 1;

		for (typename NodeType::NodePtrSet::iterator iterSucc = rcCurrentNode.cSuccessors.begin();
			iterSucc != rcCurrentNode.cSuccessors.end(); iterSucc++)
		{
			int iStatus = ExistSubsetRecur((NodeType &)*iterSucc, rcElementSet);
			if (iStatus == 1)
				return iStatus;
		}
		return 0;
	}

	int ExistSupsetRecur(NodeType & rcCurrentNode, typename ElementSet::iterator iterCurrentElement, ElementSet & rcElementSet)
	{
		Element & rcElementInNode = rcCurrentNode.cElement;
		if (GreaterThan(rcElementInNode, (Element &)*iterCurrentElement))
			return 0;

		typename ElementSet::iterator iterNext = iterCurrentElement;
		if (Equal(rcElementInNode, (Element &)*iterCurrentElement))
			iterNext++;

		if (iterNext == rcElementSet.end())//All elements found in the path
			return 1;
		
		for (typename NodeType::NodePtrSet::iterator iterSucc = rcCurrentNode.cSuccessors.begin();
			iterSucc != rcCurrentNode.cSuccessors.end(); iterSucc++)
		{
			int iStatus = ExistSupsetRecur((NodeType &)*iterSucc, iterNext, rcElementSet);
			if (iStatus == 1)
				return 1;
		}

		return 0;				
	}

	inline bool Equal(T & rcEleA, T & rcEleB)
	{
		CMP comparator;
		return (!comparator(rcEleA, rcEleB) && !comparator(rcEleB, rcEleA));
	}

	inline bool LessEqual(T & rcEleA, T & rcEleB)
	{
		//rcELeA <= rcEleB <--> !(rcEleB < rcEleA)
		CMP cLessCMP;
		return !cLessCMP(rcEleB, rcEleA);
	}

	inline bool GreaterEqual(T & rcEleA, T & rcEleB)
	{
		//rcELeA >= rcEleB <--> (rcEleB <= rcEleA)	
		return LessEqual(rcEleB, rcEleA);
	}

	inline bool GreaterThan(T & rcEleA, T & rcEleB)
	{
		CMP cLessCMP;
		return cLessCMP(rcEleB, rcEleA);
	}

	const NodeType * AllocateNewNode(const T & rcElement, NodeType& rcPredecessor)
	{		
		return &(*rcPredecessor.cSuccessors.insert(NodeType(rcElement)).first);		
	}

protected:
};