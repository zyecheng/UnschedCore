#pragma once
#include "TaskSet.h"
#include <set>
#include <iostream>
using namespace std;
#include <fstream>
#include <vector>
#include <map>
#include "BitMask.h"
class TPCCSet
{
public:
	struct TPCCStructTask
	{
		set<double> setTestPoints;
		set<double> setCritiChanges;
	};
	struct TPCCStructLink
	{
		int iSourceTask;
		int iDestTask;
		set<double> setTestPoints;
		set<double> setCritiChanges;
	};
protected:
	TaskSet * m_pcTargetTaskSet;
	int m_iLinkNum;	
	int m_iTaskNum;
	struct TPCCStructTask * m_ptagTaskTPCCArray;
	struct TPCCStructLink * m_ptagLinkTPCCArray;
public:
	TPCCSet();
	~TPCCSet();
	void Initialize(TaskSet & rcTaskSet);
	void GenRawTPCC();
	void GenCompleteTPCC();
	void GenRawTestPoints();
	void GenCompleteTestPoints();
	void GenRawCritiChanges();
	void ReadTPCCImage(char axFileName[]);
	void WriteTPCCImage(char axFileName[]);
	void WriteTPCCText(char axFileName[], bool bAppend = false, char * pcTitle = NULL);
	void CopyFrom(TPCCSet & rcTPCCSet);	
	set<double> & getTestPoints(int iTaskIndex);
	set<double> & getTestPoints(int iSource, int iDest);
	set<double> & getCritiChanges(int iTaskIndex);
	set<double> & getCritiChanges(int iSource, int iDest);
	void DisplayTestPoint(int iTaskIndex);
	void DisplayTestPoint(int iSource, int iDest);
	void DisplayCritiChange(int iTaskIndex);
	void DisplayCritiChange(int iSource, int iDest);
	TaskSet * getHostTaskSet()	{ return m_pcTargetTaskSet; }
	int getLinkNum()	{ return m_iLinkNum; }
	int getTaskNum()	{ return m_iTaskNum; }
	TPCCStructLink * getLinkTPCCArray()	{ return m_ptagLinkTPCCArray; }
	TPCCStructTask * getTaskTPCCArray()	{ return m_ptagTaskTPCCArray; }
	int getTPNumTask(int iTaskIndex);
	int getTPNumLink(int iSource, int iDest);
	int getTPNumTotal();
	int getHITPNumTotal();
	void GenRawCritiChangesSingle(int iTaskIndex, double dTotalTime, set<double> & rsetStore);
	void CSpaceTestPoint(int iTaskIndex, double dTotalTime, set<double> & rsetStore);
	static void CSpaceTestPoint(int iTaskIndex, double dTotalTime, TaskSet & rcTaskSet, set<double> & rsetStore);
	void TaskTPNumStatistic(std::map<int, int> & rmapStat);
protected:
	void CSpaceTestPointRecur(int iCurrentIndex, double dTotalTime, set<double> & rsetStore, set<CSpaceRecurEntry> & rsetRecurEntry);
	static void CSpaceTestPointRecur(int iCurrentIndex, double dTotalTime, 
		TaskSet & rcTaskSet, set<double> & rsetStore, set<CSpaceRecurEntry> & rsetRecurEntry);
	void HICompleteTestPointPerTask(int iTaskIndex, double dTotalTime, set<double> & rsetStore);
	void DisplaySetContent(set<double> & rsetSet);
	void WriteSetContentImage(set<double> & rsetSet,ofstream & ofstreamWriteFile);
	void ReadSetContentImage(set<double> & rsetSet, ifstream & ifstreamReadFile);
	void CreateTaskTPCCArray(int iSize);
	void DestroyTaskTPCCArray();
	void CreateLinkTPCCArray(int iSize);
	void DestroyLinkTPCCArray();
	void WriteSetContentText(set<double> & rsetSet, ofstream & ofstreamWriteFile);
};

class TPCCSet_PerDeadlines :public TPCCSet
{
public:
	struct DeadlineTPCCTuple
	{
		double dDeadline;
		TPCCStructTask tagTPCCStruct;

		DeadlineTPCCTuple()	{}
		DeadlineTPCCTuple(double dDeadline_in)	{ dDeadline = dDeadline_in; }
	};

	typedef deque<DeadlineTPCCTuple> TaskTPCCData;

	vector<TaskTPCCData> m_vectorTPCCs;
	set<double> m_setDummy;
public:
	TPCCSet_PerDeadlines();
	TPCCSet_PerDeadlines(TaskSet & rcTaskSet);
	~TPCCSet_PerDeadlines();
	void Initialize(TaskSet & rcTaskSet);
	void Clear();
	void GenAllTPCC();
	void GenAllRawTestPoint();
	void GenAllCritiChanges();
	void GenBasicCompleteTestPoint();
	void AddDeadline(int iTaskIndex, double Deadline);

	TaskTPCCData getTaskTPCCData(int iTaskIndex);

	void WriteTPCCImage(const char axFileName[]);
	void WriteTPCCText(const char axFileName[]);
	void ReadTPCCImage(const char axFileName[]);
	
	set<double> & getTestPoints(int iTaskIndex, double dDeadline);
	set<double> & getCritChanges(int iTaskIndex, double dDeadline);



};


