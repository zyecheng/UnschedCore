#pragma once
#include <iostream>
using namespace std;
#include <map>
#include "Util.h"
int DispatchFunction(int argc, char * argv[]);
int SimulinkFR(int argc, char * argv[]);
int DummyTemp(int argc, char * argv[]);

typedef map<string, string, StringCompObj>	ArgName2Arg;
int ExtractArgument(int argc, char * argv[], ArgName2Arg & rmapName2Arg);
int MinimizeAUTOSTARMemory_FR(int argc, char * argv[]);
int SimulinkFSMBnB(int argc, char * argv[]);
int SimulinkMILP(int argc, char * argv[]);
