#pragma once
#include "SimulinkMiniDelayBnB.h"
#include <SchedulabilityAnalysis.h>


class FSMTaskSet :public TaskSet
{
public:
protected:
	Stateflow ** m_ppcStateFlows;
	vector<double> m_vectorStateFlowMaxWCET;
public:
	void ReadStateflow(char axFileName[]);
	void ReadRawStateflow(char axFileName[]);
	void BuildFSMData();
	Stateflow * getFSM(int iTaskIndex);
	Stateflow ** getFSMArray()	{ return m_ppcStateFlows; }
	double getFSMMaxWCET(int iTaskIndex);
protected:
};

#include <ResponseTimeAnalysis.h>
class _FSMRBFSORTCalculator
{
private:
	TaskSet * m_pcTaskSet;
public:
	_FSMRBFSORTCalculator();
	_FSMRBFSORTCalculator(TaskSet & rcTaskSet);
	//double CalculateRTTask(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment);
	double CalculateRTTrans(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, Transition * pcTrans);
	bool IsDeadlineMet(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment);
private:
	double CalculateRTTrans(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, Transition * pcTrans, int iStart, int iGCD);

};

void GenerateFSMImplementationSingle(char axFileName[], int maxState, double tUtil, int period_choice, double scc_probability);
void GenerateFSMImplementationFolder(char axFolder[], char axDstFolder[], int maxState, double tUtil, int period_choice, double scc_probability);

class UnschedCoreComputer_FSM_RBFSO : public UnschedCoreComputer
{
public:
	int m_iInstanceApproximate;
	int m_iResultTrulyApproximiate;
	int m_iInstanceLimit;
	int m_iBusyStartApproximation;
protected:
	MySet<int> m_cSetofPeriods;//The set of periods for all transitions.
	//typedef map<int, MySet<int> > Deadline2BiniPoint;
	//Deadline2BiniPoint m_cDeadline2BiniPoint;	


	//Temp Data
	vector<int> m_vectorSFArrayMapping;
	map<int, map<int, int> > m_mapPairwiseDominance;

	//Approximate Analysis Look Up Table		
	SystemHPBitMaskTableNLH m_vectorSystemApproxFeaHPBitMaskNLH;	
	SystemHPBitMaskTableNLH m_vectorSystemApproxInfeaHPBitMaskNLH;
	//Statistic Data
public:
	map<int, int> m_mapUnschedStopInstance;	
	int m_iUnschedNotAtTriggerTimes;
	int m_iUnschedAtTriggerTimes;
public:
	UnschedCoreComputer_FSM_RBFSO();
	UnschedCoreComputer_FSM_RBFSO(FSMTaskSet & rcTaskSet);
	~UnschedCoreComputer_FSM_RBFSO();
protected:
	virtual bool SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData);
	int GenSFArrayByPriority(Stateflow ** ppcStateflows, int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment);
	bool Richie_rbf_analysis_static_offset_index(Stateflow** sfs, int i);
	bool Richie_rbf_analysis_static_offset_index(Stateflow** sfs, int i, int wcet, int stime, int deadline, int & iStartLB, int iHPGCD);
	bool IsDominateByLP(Stateflow** sfs, int i, int stime, ActionPair & rcAP);
	int HPGCD(Stateflow** sfs, int iTaskIndex);
	double getIBF(Stateflow ** ppcStateflows, int iLevel, int iStart, int iFinish);
	bool Richie_lub_rbf_analysis_static_offset_index(Stateflow** sfs, int i, int wcet, int stime, int deadline, int iHPGCD);
	bool Richie_lub_rbf_analysis_static_offset_index(Stateflow** sfs, int i);
	bool Richie_llb_rbf_analysis_static_offset_index(Stateflow** sfs, int i, int wcet, int stime, int deadline, int iHPGCD);
	bool Richie_llb_rbf_analysis_static_offset_index(Stateflow** sfs, int i);
	void ComputePairwiseDominance();
	int TestDominance(int iTaskA, int iTaskB, int iSTDistance);
	inline virtual bool PreInsertPAEncoding(int iTaskIndex, bool SchedStatus, BitMask & rcEncoding)
	{		
		if (m_iResultTrulyApproximiate)
		{	
			assert(SchedStatus); //Instance Approximation can only be indecisive on schedulable cases
			if (SchedStatus)
			{
				m_vectorSystemApproxFeaHPBitMaskNLH[iTaskIndex].Insert(rcEncoding);
			}			
			m_iResultTrulyApproximiate = 0;
			return false;
		}
		return true;
	}
	virtual int QuickSchedTest_Forv4(int iTaskIndex, BitMask & rcHPSets);
};

class UnschedCoreComputer_FSM_SingleTaskImple : public UnschedCoreComputer
{
public:
	TaskSet m_cImpleTaskSet;
public:
	UnschedCoreComputer_FSM_SingleTaskImple();
	UnschedCoreComputer_FSM_SingleTaskImple(FSMTaskSet & rcTaskSet);
	~UnschedCoreComputer_FSM_SingleTaskImple();
protected:
	virtual bool SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void * pvExtraData);
};


class SimulinkMiniDelayBnB_FSMRBFSO : public SimulinkMiniDelayBnB
{
public:
	UnschedCoreComputer_FSM_RBFSO m_cUnschedCore;
public:
	SimulinkMiniDelayBnB_FSMRBFSO();
	SimulinkMiniDelayBnB_FSMRBFSO(FSMTaskSet & rcTaskSet);
	~SimulinkMiniDelayBnB_FSMRBFSO();
private:
	virtual void InitializeLinkData();
	virtual double CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct);
};

void TestFIJCaseStudy();
#ifdef MCMILPPACT

#include "SimuLinkMiniDelay.h"
class SimuLinkMiniDelay_FR_FSM_RBFSO : public SimuLinkMiniDelay_FR
{
public:
	UnschedCoreComputer_FSM_RBFSO m_cUnschedCoreComputer_FSM_RBFSO;
	int m_iIncorrectOptimalFailedTimes;
public:
	SimuLinkMiniDelay_FR_FSM_RBFSO();
	SimuLinkMiniDelay_FR_FSM_RBFSO(FSMTaskSet & rcTaskSet);
	~SimuLinkMiniDelay_FR_FSM_RBFSO();
	void UnschedCore_UseOccurenceSort(int iOpt);
	void UseBitMaskLookUpTable(bool bOpt);
	void UsePPOSchedTestLookUpTable(bool bOpt);

	void SchedTestOption(string stringOption);
	void UnschedCoreCompOption(string stringOption);
	void InstanceApproximationOption(int iInstanceLimit);
	void BusyStartApproximation(int iOpt);
	virtual bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
private:
	virtual bool VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int FeasibleHook(UnschedCores & rcUnschedCores, PriorityPOSet & rcFixedSet, PriorityPOSet & rcPPOSolution);
	virtual bool VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	void WriteSchedTestStatistic();
	virtual void PostAccomplishWork(int iStatus);
};



class SimuLinkMiniDelay_FR_FSM_SingleTaskImple : public SimuLinkMiniDelay_FR
{
public:
	UnschedCoreComputer_FSM_SingleTaskImple m_cUnschedCoreComputer_FSM_SingleTaskImple;
public:
	SimuLinkMiniDelay_FR_FSM_SingleTaskImple();
	SimuLinkMiniDelay_FR_FSM_SingleTaskImple(FSMTaskSet & rcTaskSet);
	~SimuLinkMiniDelay_FR_FSM_SingleTaskImple();
	virtual bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
private:
	virtual bool VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int FeasibleHook(UnschedCores & rcUnschedCores, PriorityPOSet & rcFixedSet, PriorityPOSet & rcPPOSolution);
};

void TestFocusRefinementLO(char axDstFolder[]);
void TestFocusRefinementFSMRBFSO(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSONoBitMask(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSO_NoBitMask_NoSorting(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSONoSorting(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSOKSweep(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSOUSweep(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSONKSweep(char axDstFolder[], char axFSMFolder[]);
void TestBnbFSMRBFSONSweep_MT(char axDstFolder[], char axFSMFolder[], int iThreadNum, int iSystemType = 3, int iUseLookUpTable = 0);
void TestFocusRefinementPeriodicTaskApprox(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSONoBitMaskUSweep(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSOApproximation(char axDstFolder[], char axFSMFolder[]);
void GenerateSimulinkFIJCaseFSMImple();
void ReadUnschedTestedInstance();
void TestPeriodicTaskApproxILP(char axDstFolder[], char axFSMFolder[]);
#endif