#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_
#include "stdafx.h"
//#define GOOGLETEST
//#define VLDTEST
//#define EXACTANALYSIS

#endif