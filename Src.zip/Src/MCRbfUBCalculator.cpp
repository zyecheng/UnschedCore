#include "stdafx.h"
#include "MCRbfUBCalculator.h"
#include <algorithm>
extern void my_assert(bool bCondition, char axInfo[]);

MCRbfUBCalculator::MCRbfUBCalculator()
{
	m_pipriorityTable = NULL;
	m_pcTaskSet = NULL;
}


MCRbfUBCalculator::~MCRbfUBCalculator()
{
	m_pcTaskSet = NULL;
	m_pipriorityTable = NULL;
	ClearTable();
}

void MCRbfUBCalculator::setPriority(int iTaskIndex, int iPriority)
{
	my_assert(m_pipriorityTable != NULL, "Not Initialized yet");
	m_pipriorityTable[iTaskIndex] = iPriority;
}

void MCRbfUBCalculator::Initialize(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet)
{
	m_pcTaskSet = &rcTaskSet;
	m_pcTPCCSet = &rcTPCCSet;
	CreateTable();
}

void MCRbfUBCalculator::CreateTable()
{
	ClearTable();
	my_assert(m_pcTaskSet != NULL, "Not Initialized yet");
	m_pipriorityTable = new int[m_pcTaskSet->getTaskNum()];
	memset(m_pipriorityTable, 0, sizeof(int)*m_pcTaskSet->getTaskNum());
}

void MCRbfUBCalculator::ClearTable()
{
	if (m_pipriorityTable)
	{
		delete m_pipriorityTable;
	}
	m_pipriorityTable = NULL;
}

double MCRbfUBCalculator::LUBCalculator(int iTaskIndex, double dTotalTime)
{	
	int iTaskNum = m_pcTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	my_assert(pcTaskArray[iTaskIndex].getCriticality(), "LUB can't be used on LO-criticality tasks");
	double dValueLeft = pcTaskArray[iTaskIndex].getCHI();
	double dValueRight = pcTaskArray[iTaskIndex].getCHI();	
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
		{
			continue;
		}
		double dInterferenceLeft = 0;
		double dInterferenceRight = 0;
		if (m_pipriorityTable[i] <= m_pipriorityTable[iTaskIndex])
		{
			if (pcTaskArray[i].getCriticality())
			{
				dInterferenceLeft = ceil(dTotalTime / pcTaskArray[i].getPeriod()) * pcTaskArray[i].getCHI() +
					pcTaskArray[i].getCHI() - pcTaskArray[i].getCLO();
				dInterferenceRight = dInterferenceLeft + (pcTaskArray[i].getCLO() - pcTaskArray[i].getCHI()) / pcTaskArray[i].getPeriod() * dTotalTime;
			}
			else
			{
				dInterferenceLeft = pcTaskArray[i].getCLO();
				dInterferenceRight = dInterferenceLeft + pcTaskArray[i].getCLO() / pcTaskArray[i].getPeriod() * dTotalTime;
			}
			dValueRight += dInterferenceRight;
			dValueLeft += dInterferenceLeft;
		}		
	}
	return max(dValueLeft, dValueRight);
}

double MCRbfUBCalculator::PLUBCalculator(int iTaskIndex, double dTotalTime)
{
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	int iTaskNum = m_pcTaskSet->getTaskNum();
	double dValue = 0;
	for (int i = 0; i < iTaskNum; i++)
	{				
		if (i == iTaskIndex)
		{
			continue;
		}
		if (m_pipriorityTable[i] < m_pipriorityTable[iTaskIndex])
		{
			double dThisValue = PLUBCalculator_Point(iTaskIndex, dTotalTime, DiscontinuityPoint(i, dTotalTime));
			if (dThisValue > dValue)
			{
				dValue = dThisValue;
				if (dValue > dTotalTime)
				{
					//No need to continue
					return dValue;
				}
			}
		}
		
	}
	return dValue;
}

double MCRbfUBCalculator::PLUBCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange)
{
	int iTaskNum = m_pcTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	my_assert(pcTaskArray[iTaskIndex].getCriticality(), "PLUB can't be used on LO-criticality tasks");
	double dValue = pcTaskArray[iTaskIndex].getCHI();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
		{
			continue;
		}
		if (m_pipriorityTable[i] <= m_pipriorityTable[iTaskIndex])
		{
			double dDiscontinuityPoint = DiscontinuityPoint(i, dTotalTime);
			if (pcTaskArray[i].getCriticality())
			{
				dValue += ceil(dTotalTime / pcTaskArray[i].getPeriod()) * pcTaskArray[i].getCHI()
					+ max(dCritiChange - dDiscontinuityPoint, 0.0) * (pcTaskArray[i].getCLO() - pcTaskArray[i].getCHI()) / pcTaskArray[i].getPeriod();;
			}
			else
			{
				dValue += pcTaskArray[i].getCLO() +
					min(dDiscontinuityPoint, dCritiChange) * pcTaskArray[i].getCLO() / pcTaskArray[i].getPeriod();
			}
		}
	}	
	return dValue;
}

double MCRbfUBCalculator::DiscontinuityPoint(int iTaskIndex, double dTotalTime)
{
	Task & rcTask = m_pcTaskSet->getTaskArrayPtr()[iTaskIndex];
	if (rcTask.getCriticality())
	{
		return min((double)rcTask.getPeriod(), dTotalTime);
	}
	else
	{
		return max((ceil(dTotalTime / rcTask.getPeriod()) - 1) * rcTask.getPeriod(),0.0);
	}
}

bool MCRbfUBCalculator::bIsSchedulableTask(int iTaskIndex, int iUBType)
{
	my_assert(m_pcTaskSet != NULL, "Not Initialized Yet");
	Task & rcTask = m_pcTaskSet->getTaskArrayPtr()[iTaskIndex];
	//set<double> & rsetSufficientTestSet = m_pcTaskSet->getTaskArrayPtr()[iTaskIndex].getSufficientTestSet();
	set<double> & rsetSufficientTestSet = m_pcTPCCSet->getTestPoints(iTaskIndex);
	if (rcTask.getCriticality())
	{
		switch (iUBType)
		{
		case UBTYPE_PLUB:
			for (set<double>::iterator iter = rsetSufficientTestSet.begin();
				iter != rsetSufficientTestSet.end(); iter++)
			{
				if (PLUBCalculator(iTaskIndex, *iter) <= *iter)
				{
					return true;
				}
			}
			break;
		case UBTYPE_LUB:
			for (set<double>::iterator iter = rsetSufficientTestSet.begin();
				iter != rsetSufficientTestSet.end(); iter++)
			{
				if (LUBCalculator(iTaskIndex, *iter) <= *iter)
				{
					return true;
				}
			}
			break;
		default:
			my_assert(false, "Invalid UB Type parameter");
			break;
		}
	}
	else
	{
		for (set<double>::iterator iter = rsetSufficientTestSet.begin();
			iter != rsetSufficientTestSet.end(); iter++)
		{
			if (LORbfCalculator(iTaskIndex, *iter) <= *iter)
			{
				return true;
			}
		}
	}
	return false;
}

bool MCRbfUBCalculator::bIsSchedulableAll(int iUBType)
{
	my_assert(m_pcTaskSet != NULL, "Not Initialized Yet");
	int iTaskNum = m_pcTaskSet->getTaskNum();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (!bIsSchedulableTask(i,iUBType))
		{
			return false;
		}
	}
	return true;
}

double MCRbfUBCalculator::LORbfCalculator(int iTaskIndex, double dTotalTime)
{
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	int iTaskNum = m_pcTaskSet->getTaskNum();
	double dValue = pcTaskArray[iTaskIndex].getCLO();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
		{
			continue;
		}
		if (m_pipriorityTable[i] <= m_pipriorityTable[iTaskIndex])
		{
			dValue += ceil(dTotalTime / pcTaskArray[i].getPeriod()) * pcTaskArray[i].getCLO();
		}
	}
	return dValue;
}

double MCRbfUBCalculator::AMCSepRbfCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange)
{
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	int iTaskNum = m_pcTaskSet->getTaskNum();
	double dValue = pcTaskArray[iTaskIndex].getCHI();

	if (dTotalTime < dCritiChange)
	{
		return LORbfCalculator(iTaskIndex, dTotalTime);
	}

	for (int i = 0; i < iTaskNum; i++)
	{
		if (iTaskIndex == i)
			continue;
		if (m_pipriorityTable[i] <= m_pipriorityTable[iTaskIndex])
		{
			if (pcTaskArray[i].getCriticality())
			{
#if 1			
				int iLOInstances = max(floor((dCritiChange - pcTaskArray[i].getDeadline()) / pcTaskArray[i].getPeriod()), 0.0);
				int iHIInstances = ceil(dTotalTime / pcTaskArray[i].getPeriod()) - iLOInstances;
#endif

#if 0
				int iHIInstances = min(
					ceil((dTotalTime - dCritiChange - (pcTaskArray[i].getPeriod() - pcTaskArray[i].getDeadline())) / pcTaskArray[i].getPeriod()) + 1,
					ceil(dTotalTime / pcTaskArray[i].getPeriod())
					);
				int iLOInstances = ceil(dTotalTime / pcTaskArray[i].getPeriod()) - iHIInstances;
#endif
				double dLOInterference =  iLOInstances * pcTaskArray[i].getCLO();
				double dHIInterference = iHIInstances * pcTaskArray[i].getCHI();
				dValue += dLOInterference + dHIInterference;
			}
			else
			{
				int iLOInstances = floor(dCritiChange / pcTaskArray[i].getPeriod()) + 1;
				//int iLOInstances = ceil(dCritiChange / pcTaskArray[i].getPeriod());
				double dInterference = iLOInstances * pcTaskArray[i].getCLO();
				dValue += dInterference;
			}
		}
	}
	return dValue;
}

double MCRbfUBCalculator::AMCMaxRbfCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange)
{
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	int iTaskNum = m_pcTaskSet->getTaskNum();
	double dValue = pcTaskArray[iTaskIndex].getCHI();

	if (dTotalTime < dCritiChange)
	{
		return LORbfCalculator(iTaskIndex, dTotalTime);
	}

	for (int i = 0; i < iTaskNum; i++)
	{
		if (iTaskIndex == i)
			continue;
		if (m_pipriorityTable[i] <= m_pipriorityTable[iTaskIndex])
		{
			if (pcTaskArray[i].getCriticality())
			{
#if 1
				int iHIInstances = min(
					ceil((dTotalTime - dCritiChange - (pcTaskArray[i].getPeriod() - pcTaskArray[i].getDeadline())) / pcTaskArray[i].getPeriod()) + 1,
					ceil(dTotalTime / pcTaskArray[i].getPeriod())
					);
				int iLOInstances = ceil(dTotalTime / pcTaskArray[i].getPeriod()) - iHIInstances;
#endif
				double dLOInterference = iLOInstances * pcTaskArray[i].getCLO();
				double dHIInterference = iHIInstances * pcTaskArray[i].getCHI();
				dValue += dLOInterference + dHIInterference;
			}
			else
			{
				int iLOInstances = floor(dCritiChange / pcTaskArray[i].getPeriod()) + 1;
				//int iLOInstances = ceil(dCritiChange / pcTaskArray[i].getPeriod());
				double dInterference = iLOInstances * pcTaskArray[i].getCLO();
				dValue += dInterference;
			}
		}
	}
	return dValue;
}

