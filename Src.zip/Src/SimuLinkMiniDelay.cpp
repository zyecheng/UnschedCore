#include "stdafx.h"
#include "SimuLinkMiniDelay.h"
#include "Util.h"
#include <assert.h>
#include <cmath>
#include "ResponseTimeCalculator.h"
#include "Timer.h"
#include "StatisticSet.h"

#define min(a,b)            (((a) < (b)) ? (a) : (b))
extern IloEnv cEnv;
SimuLinkMiniDelay::SimuLinkMiniDelay()	
{
}

SimuLinkMiniDelay::SimuLinkMiniDelay(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet)
	:RTSchedMILP_rbf_P(rcTaskSet, rcTPCCSet)
{
	InitializeLinkObj();
	//cout << "Analyzing HL Link PODET..." << endl;
	AnalyzePODET();
}

SimuLinkMiniDelay::~SimuLinkMiniDelay()
{
}

SimuLinkMiniDelay_LinkData::SimuLinkMiniDelay_LinkData()	
{

}

SimuLinkMiniDelay_LinkData::SimuLinkMiniDelay_LinkData(int iSource, int iDestination, double dMemoryCost, double dDelayCost, int iType)
{ 	
	m_iSource = iSource;
	m_iDestination = iDestination;
	m_dMemoryCost = dMemoryCost; m_dDelayCost = dDelayCost; m_iType = iType; 
}

bool operator < (const SimuLinkMiniDelay_Link & rcLHS, const SimuLinkMiniDelay_Link & rcRHS)
{
	if (rcLHS.m_iSource == rcRHS.m_iSource)
	{
		return rcLHS.m_iDestination < rcRHS.m_iDestination;
	}
	else
	{
		return rcLHS.m_iSource < rcRHS.m_iSource;
	}
}

void SimuLinkMiniDelay::InitializeLinkObj()
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iLinkIndex = 0;
	for (int i = 0; i < iTaskNum; i++)
	{
		for (set<Task::CommunicationLink>::iterator iter = pcTaskArray[i].getSuccessorSet().begin();
			iter != pcTaskArray[i].getSuccessorSet().end(); iter++)
		{
			int iType = 0;
			if (DOUBLE_EQUAL(pcTaskArray[i].getPeriod(), pcTaskArray[iter->m_iTargetTask].getPeriod(), 1e-7))
			{
				iType = SIMULINK_LINKTYPE_EQ;
			}
			else if (pcTaskArray[i].getPeriod() < pcTaskArray[iter->m_iTargetTask].getPeriod())
			{
				iType = SIMULINK_LINKTYPE_HL;
			}
			else
			{
				iType = SIMULINK_LINKTYPE_LH;
			}

			//m_cLinkObj[SimuLinkMiniDelay_Link(i, iter->m_iTargetTask)] = SimuLinkMiniDelay_LinkData(iter->m_dMemoryCost, iter->m_dDelayCost* 1.0, iType);
			m_mapLink2Index[SimuLinkMiniDelay_Link(i, iter->m_iTargetTask)] = iLinkIndex;
#if 1
			m_mapIndex2LinkData[iLinkIndex] = SimuLinkMiniDelay_LinkData(i, iter->m_iTargetTask, iter->m_dMemoryCost, iter->m_dDelayCost* 1.0, iType);
#else
			m_mapIndex2LinkData[iLinkIndex] = SimuLinkMiniDelay_LinkData(i, iter->m_iTargetTask, iter->m_dMemoryCost, 1.0, iType);			
#endif
			iLinkIndex++;
		}
	}
}

void SimuLinkMiniDelay::CreateFBVars(IloNumVarArray & rcFBVars)
{
	const IloEnv & rcEnv = rcFBVars.getEnv();
	int iSize = m_mapLink2Index.size();
	char axBuffer[128] = { 0 };
	for (int i = 0; i < iSize; i++)
	{
		int iSource = m_mapIndex2LinkData[i].m_iSource;
		int iDestination = m_mapIndex2LinkData[i].m_iDestination;
		sprintf_s(axBuffer, "fb(%d, %d)", iSource, iDestination);
		rcFBVars.add(IloNumVar(rcEnv, 0.0, 1.0, IloNumVar::Int, axBuffer));
	}
}

void SimuLinkMiniDelay::CreateLinkEncoders(IloEnv & rcEnv, deque<DisjunctionEncoder> & rdequeEncoders)
{
	int iSize = m_mapLink2Index.size();
	char axBuffer[128] = { 0 };
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		int iTPSize = m_pcTPCCSet->getTestPoints(iSource, iDestination).size();
		rdequeEncoders.push_back(DisjunctionEncoder(rcEnv, iTPSize));
	}
	
}

void SimuLinkMiniDelay::GenRTLinkLOConst(SimuLinkMiniDelay_LinkData & rcLinkKey, IloNumVarArray & rcPVars,
	IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	int iSrc = rcLinkKey.m_iSource;
	int iDst = rcLinkKey.m_iDestination;
	GenRTLinkLOConst(rcLinkKey, m_pcTPCCSet->getTestPoints(iSrc, iDst), rcPVars, rcFBVars, rcEncoder, rcRangeArray);
}

void SimuLinkMiniDelay::GenRTLinkLOConst(SimuLinkMiniDelay_LinkData & rcLinkKey, set<double> & rsetTP, IloNumVarArray & rcPVars,
	IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	SimuLinkMiniDelay_LinkData & rcLinkData = rcLinkKey;
	const IloEnv & rcEnv = rcPVars.getEnv();
	int iSrc = rcLinkKey.m_iSource;
	int iDst = rcLinkKey.m_iDestination;
	int iTaskIndex = rcLinkKey.m_iDestination;
	if (rcLinkData.m_iType == SIMULINK_LINKTYPE_HL)
	{
		assert(iTaskIndex < m_pcTaskSet->getTaskNum());
		set<double> & rsetTestPoint = rsetTP;				
		char axBuffer[128] = { 0 };
		int iEncIndex = 0;
		double dBigM = DetermineBigMLO(iTaskIndex);
		for (set<double>::iterator iter = rsetTestPoint.begin();
			iter != rsetTestPoint.end(); iter++)
		{
			sprintf_s(axBuffer, "rbfLO(%d, %.2f)", iTaskIndex, *iter);
			rcRangeArray.add(IloRange(rcEnv, -IloInfinity,
				rbfLO(iTaskIndex, *iter, rcPVars) - *iter - rcEncoder.getEncodingExpression(iEncIndex, dBigM) - getFBVar(iSrc, iDst, rcFBVars) *dBigM,
				0.0, axBuffer));
			iEncIndex++;		
		}
		rcRangeArray.add(rcEncoder.getEncodingConstraint());		
		//rcRangeArray.add(IloRange(rcEnv, 0.0, getPriorityVariable(iSrc, iDst, rcPVars) - 1.0, 0.0));
	}
	else if (rcLinkData.m_iType == SIMULINK_LINKTYPE_EQ)
	{		
		//rcRangeArray.add(IloRange(rcEnv, 0.0, getPriorityVariable(iSrc, iDst, rcPVars) - 1.0, 0.0));
	}
	else if (rcLinkData.m_iType == SIMULINK_LINKTYPE_LH)
	{
		//rcRangeArray.add(IloRange(m_cCplexEnv, 0.0, rcLinkData.m_cFBVar - 1.0, 0.0));
	}
	
}

void SimuLinkMiniDelay::GenRTLinkHIConst(SimuLinkMiniDelay_LinkData & rcLinkKey,
	IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	int iSrc = rcLinkKey.m_iSource;
	int iDst = rcLinkKey.m_iDestination;
	GenRTLinkHIConst(rcLinkKey, m_pcTPCCSet->getTestPoints(iSrc, iDst), m_pcTPCCSet->getCritiChanges(iSrc, iDst),
		rcPVars, rcFBVars, rcEncoder, rcRangeArray);
}

void SimuLinkMiniDelay::GenRTLinkHIConst(SimuLinkMiniDelay_LinkData & rcLinkKey, set<double> & rsetTP, set<double> & rsetCC,
	IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	SimuLinkMiniDelay_LinkData & rcLinkData = rcLinkKey;
	const IloEnv & rcEnv = rcPVars.getEnv();
	int iSrc = rcLinkKey.m_iSource;
	int iDst = rcLinkKey.m_iDestination;
	int iTaskIndex = rcLinkKey.m_iDestination;
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);	
	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		GenRTLinkLOConst(rcLinkKey, rsetTP, rcPVars, rcFBVars, rcEncoder, rcRangeArray);
	}
	else
	{
		if (rcLinkData.m_iType == SIMULINK_LINKTYPE_HL)
		{
			set<double> & rsetTestPoint = rsetTP;
			set<double> & rsetCC = m_pcTPCCSet->getCritiChanges(iTaskIndex);						
			char axBuffer[128] = { 0 };
			int iEncIndex = 0;
			double dBigM = DetermineBigMHI(iTaskIndex);
			for (set<double>::iterator iterTP = rsetTestPoint.begin();
				iterTP != rsetTestPoint.end(); iterTP++)
			{
				for (set<double>::iterator iterCC = rsetCC.begin();
					iterCC != rsetCC.end(); iterCC++)
				{
					if (*iterCC < *iterTP)
					{
						sprintf_s(axBuffer, "rbfCC(%d, %.2f, %.2f)", iTaskIndex, *iterTP, *iterCC);
						rcRangeArray.add(IloRange(rcEnv, -IloInfinity,
							rbfCC(iTaskIndex, *iterTP, *iterCC, rcPVars) - *iterTP - rcEncoder.getEncodingExpression(iEncIndex, dBigM) - getFBVar(iSrc, iDst, rcFBVars) *dBigM,
							0.0, axBuffer));
					}
				}
				iEncIndex++;
			}
			rcRangeArray.add(rcEncoder.getEncodingConstraint());			
			rcRangeArray.add(IloRange(rcEnv, 0.0, getPriorityVariable(iSrc, iDst, rcPVars) - 1.0, 0.0));
		}
		else if (rcLinkData.m_iType == SIMULINK_LINKTYPE_EQ)
		{			
			rcRangeArray.add(IloRange(rcEnv, 0.0, getPriorityVariable(iSrc, iDst, rcPVars) - 1.0, 0.0));
		}
		else
		{
		//	rcRangeArray.add(IloRange(m_cCplexEnv, 0.0, rcLinkData.m_cFBVar - 1.0, 0.0));
		}
		
	}
}

void SimuLinkMiniDelay::BuildRTLinkHIConst(IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, deque<DisjunctionEncoder> & rdequeEncoder, IloRangeArray & rcRangeArray)
{
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
	//	cout << iter->first.m_iSource << " " << iter->first.m_iDestination << endl;
		GenRTLinkHIConst(iter->second, rcPVars, rcFBVars, rdequeEncoder[iter->first], rcRangeArray);
	}
}

void SimuLinkMiniDelay::BuildRTLinkLOConst(IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, deque<DisjunctionEncoder> & rdequeEncoder, IloRangeArray & rcRangeArray)
{
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		//	cout << iter->first.m_iSource << " " << iter->first.m_iDestination << endl;
		GenRTLinkLOConst(iter->second, rcPVars, rcFBVars, rdequeEncoder[iter->first], rcRangeArray);
	}
}

IloNumVar & SimuLinkMiniDelay::getFBVar(int iSrc, int iDst, IloNumVarArray & rcFBVar)
{
	//assert(m_cLinkObj.count(SimuLinkMiniDelay_Link(iSrc, iDst)) == 1);
	int iDataIndex = m_mapLink2Index[SimuLinkMiniDelay_Link(iSrc, iDst)];
	assert(rcFBVar.getSize() > iDataIndex);
	return rcFBVar[iDataIndex];
}

void SimuLinkMiniDelay::GenMemoryConst(double dMemory, IloNumVarArray & rcPVars, IloNumVarArray & rcFBVars, IloRangeArray & rcRangeArray)
{
	const IloEnv & rcEnv = rcFBVars.getEnv();
	IloExpr cExpr(rcEnv);
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		int iSource = iter->second.m_iSource;
		int iDestination = iter->second.m_iDestination;
		if (iter->second.m_iType == SIMULINK_LINKTYPE_HL)
		{
			cExpr += getFBVar(iSource, iDestination, rcFBVars) * iter->second.m_dMemoryCost;
		}
		else if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			cExpr += (1.0 - getPriorityVariable(iSource, iDestination, rcPVars)) * iter->second.m_dMemoryCost;
		}
	}
	rcRangeArray.add(IloRange(rcEnv, -IloInfinity, cExpr - dMemory, 0.0, "Memory"));
}

IloObjective SimuLinkMiniDelay::GenObjective(IloNumVarArray & rcPVars)
{	
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cObjExpression(rcEnv);
	int iUndet = 0;
	int iTotal = 0;
	int iMax = 100;
	
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			iTotal++;
			int iSrcIndex = iter->second.m_iSource;
			int iDstIndex = iter->second.m_iDestination;								
			cObjExpression += (1 - getPriorityVariable(iSrcIndex, iDstIndex, rcPVars)) * iter->second.m_dDelayCost * 1;
			
		}
	}
	//cout << endl << iUndet << " Undet LH links" << endl;
	//cout << "Total " << iTotal << " Links" << endl;
	return IloObjective(rcEnv, cObjExpression, IloObjective::Minimize, "Minimize Delay");
}


void SimuLinkMiniDelay::AnalyzePODET()
{
	//return;

	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_HL || iter->second.m_iType == SIMULINK_LINKTYPE_EQ)
		{
			int iSrc = iter->second.m_iSource;
			int iDst = iter->second.m_iDestination;
			setPODET(iSrc, iDst, true);
			//cout << "HL Linkd PODET; " << iSrc << " " << iDst << endl;
			assert(CheckPODET(iSrc, iDst) == 1);
		}
	}
}

int SimuLinkMiniDelay::getFBResult(int iSrc, int iDst, IloNumVarArray & rcFBVars, IloCplex & rcSolver)
{
	SimuLinkMiniDelay_LinkData & rcLinkData = m_cLinkObj[SimuLinkMiniDelay_Link(iSrc, iDst)];
	assert(rcLinkData.m_iType == SIMULINK_LINKTYPE_HL);
	return round(rcSolver.getValue(getFBVar(iSrc, iDst, rcFBVars)));
}

bool SimuLinkMiniDelay::VerifyFB(IloNumVarArray & rcFBVars, IloCplex & rcSolver)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (LinkMap::iterator iter = m_cLinkObj.begin(); iter != m_cLinkObj.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_HL)
		{
			int iSrc = iter->first.m_iSource;
			int iDst = iter->first.m_iDestination;
			if (getFBResult(iSrc, iDst, rcFBVars, rcSolver) == 0)
			{
				if (m_mapTask2ResponseTime[iDst] > pcTaskArray[iSrc].getPeriod())
				{
					cout << iDst << " " << iSrc << endl;
					cout << m_mapTask2ResponseTime[iDst] << " " << pcTaskArray[iSrc].getPeriod() << " " << rcSolver.getValue(getFBVar(iSrc,iDst, rcFBVars)) << endl;
					cout << *m_pcTPCCSet->getTestPoints(iSrc, iDst).begin() << endl;
					return false;
				}
					
			}			
		}		
	}
	return true;
}

double SimuLinkMiniDelay::ComputeMemory()
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	double dMemoryCost = 0;
	for (LinkMap::iterator iter = m_cLinkObj.begin(); iter != m_cLinkObj.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_HL)
		{
			int iSrc = iter->first.m_iSource;
			int iDst = iter->first.m_iDestination;
			if (m_mapTask2ResponseTime[iDst] > pcTaskArray[iSrc].getPeriod())
			{
				dMemoryCost += iter->second.m_dMemoryCost;
			}
		}
		else if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			int iSrc = iter->first.m_iSource;
			int iDst = iter->first.m_iDestination;
			if (m_mapPriorityResult[iDst] < m_mapPriorityResult[iSrc])
			{
				dMemoryCost += iter->second.m_dMemoryCost;
			}
		}
	}
	return dMemoryCost;
}

double SimuLinkMiniDelay::ComputeDelay()
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	double dDelayCost = 0;
	for (LinkMap::iterator iter = m_cLinkObj.begin(); iter != m_cLinkObj.end(); iter++)
	{
		 if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			int iSrc = iter->first.m_iSource;
			int iDst = iter->first.m_iDestination;
			if (m_mapPriorityResult[iDst] < m_mapPriorityResult[iSrc])
			{
				dDelayCost += iter->second.m_dDelayCost;
			}
		}
	}
	return dDelayCost;
}

bool SimuLinkMiniDelay::VerifyMemory()
{
	if (m_dMemoryCost > m_pcTaskSet->getAvailableMemory())
		return false;
	return true;
}

bool SimuLinkMiniDelay::VerifyDelayCost()
{
	if (!DOUBLE_EQUAL(ComputeDelay(), m_dBestCost, 1e-7))
	{
		cout << ComputeDelay() << " " << m_dBestCost << endl;
		return false;
	}	
	return true;
}

void SimuLinkMiniDelay::GenObjConst(double dObjValue, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray, int iBoundDir)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cObjExpression(rcEnv);
	for (LinkMap::iterator iter = m_cLinkObj.begin(); iter != m_cLinkObj.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			int iSrcIndex = iter->first.m_iSource;
			int iDstIndex = iter->first.m_iDestination;
			int iPODET = CheckPODET(iSrcIndex, iDstIndex);
			if (iPODET != -1)
			{
				cObjExpression += (1 - iPODET) * iter->second.m_dDelayCost;
			}
			else
			{
				cObjExpression += (1 - getPriorityVariable(iSrcIndex, iDstIndex, rcPVars)) * iter->second.m_dDelayCost;
			}
			
		}
	}
	if (iBoundDir == 0)
		rcRangeArray.add(IloRange(rcEnv, -IloInfinity, -1 * cObjExpression, -1 * dObjValue));
	else if (iBoundDir == 1)
		rcRangeArray.add(IloRange(rcEnv, -IloInfinity, cObjExpression, dObjValue));
	else if (iBoundDir == -1)
		rcRangeArray.add(IloRange(rcEnv, dObjValue, cObjExpression, dObjValue));
}

void SimuLinkMiniDelay::PrintLHLinkStat()
{

}

int SimuLinkMiniDelay::Solve(int iModelType, int iDisplay, double dTimeout /* = 1e74 */)
{

	IloEnv cSolveEnv;
	IloNumVarArray cPriorityVariables(cSolveEnv);
	deque<DisjunctionEncoder> dequeEncoders;
	IloNumVarArray cLinkFBVariables(cSolveEnv);
	deque<DisjunctionEncoder> dequeLinkEncoders;

	CreatePriortyVariable(cPriorityVariables);
	CreateEncodingVariable(cSolveEnv, dequeEncoders);
	CreateFBVars(cLinkFBVariables);
	CreateLinkEncoders(cSolveEnv, dequeLinkEncoders);


	IloRangeArray cConst(cSolveEnv);
	BuildSchedConstLO(cPriorityVariables, dequeEncoders, cConst);
	GenPriorityConst(cPriorityVariables, cConst);
	BuildRTLinkLOConst(cPriorityVariables, cLinkFBVariables, dequeLinkEncoders, cConst);
	GenPreDetPOConst(cPriorityVariables, cConst);
	GenMemoryConst(m_pcTaskSet->getAvailableMemory(), cPriorityVariables, cLinkFBVariables, cConst);	
	GenGenUCConst(cPriorityVariables, m_cUnschedCores, cConst);	
	IloObjective cObjective(cSolveEnv);
	cObjective = GenObjective(cPriorityVariables);

	IloModel cModel(cSolveEnv);
	cModel.add(cConst);
	cModel.add(cObjective);

	IloCplex cSolver(cModel);

	EnableSolverDisp(iDisplay, cSolver);
	setSolverParam(cSolver);
	cSolver.setParam(IloCplex::Param::TimeLimit, dTimeout);
	//cSolver.exportModel("A:\\FVM2.sav");

	m_dSolveCPUTime = getCPUTimeStamp();
	m_dSolveWallTime = cSolver.getCplexTime();
	bool bStatus = cSolver.solve();
	m_dSolveCPUTime = getCPUTimeStamp() - m_dSolveCPUTime;
	m_dSolveWallTime = cSolver.getCplexTime() - m_dSolveWallTime;	
	int iRetStatus = 0;
	if (bStatus)
	{
		assert(VerifyPriority(cPriorityVariables, cSolver));
		ExtractPriorityResult(cPriorityVariables, cSolver);
		assert(VerifySchedulability(iModelType));
		assert(VerifyFB(cLinkFBVariables, cSolver));
		m_bIsValidSolution = true;
	}


	{
		m_bIsValidSolution = false;
		if (cSolver.getCplexStatus() == cSolver.Optimal)
			iRetStatus = 1;
		else if (cSolver.getCplexStatus() == cSolver.AbortTimeLim)
			iRetStatus = -1;
		else if (cSolver.getCplexStatus() == cSolver.Infeasible)
			iRetStatus = 0;
		else
			iRetStatus = 0;
	}

	cSolver.end();
	cModel.end();
	cConst.end();
	cPriorityVariables.end();
	cLinkFBVariables.end();
	cSolveEnv.end();
	return iRetStatus;
}

void SimuLinkMiniDelay::GenGenUCConst(IloNumVarArray & rcPVars, UnschedCores & rcGenUC, IloRangeArray & rcRangeArray)
{
	const IloEnv & rcEnv = rcRangeArray.getEnv();
	for (UnschedCoreComputer::UnschedCores::iterator iterCores = rcGenUC.begin();
		iterCores != rcGenUC.end(); iterCores++)
	{
		IloExpr cExpr(rcEnv);
		for (UnschedCoreComputer::PriorityPOSet::iterator iterPOEle = iterCores->begin(); iterPOEle != iterCores->end(); iterPOEle++)
		{
			int iHPTask = iterPOEle->m_iHPTask;
			int iLPTask = iterPOEle->m_iLPTask;
			assert(iHPTask != iLPTask);
			cExpr += getPriorityVariable(iHPTask, iLPTask, rcPVars);
		}
		rcRangeArray.add(IloRange(rcEnv, 0.0, cExpr, iterCores->size() - 1.0));
		cExpr.end();
	}
}

//No notion of memory and HL LH 
SimulinkMiniDelay_NoMemLH::SimulinkMiniDelay_NoMemLH()
{

}

SimulinkMiniDelay_NoMemLH::SimulinkMiniDelay_NoMemLH(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet)
	:SimuLinkMiniDelay(rcTaskSet, rcTPCCSet)
{


}

SimulinkMiniDelay_NoMemLH::~SimulinkMiniDelay_NoMemLH()
{


}

IloObjective SimulinkMiniDelay_NoMemLH::GenObjective(IloNumVarArray & rcPVars)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cExpr(rcEnv);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].SuccessorBegin(); iter != pcTaskArray[i].SuccessorEnd(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			if (pcTaskArray[iDestination].getPeriod() < pcTaskArray[iSource].getPeriod())
			{
				cExpr += (getPriorityVariable(iDestination, iSource, rcPVars)) * iter->m_dDelayCost;
			}			
		}
	}
	return IloMinimize(rcEnv, cExpr);
}

int SimulinkMiniDelay_NoMemLH::Solve(int iModelType, int iDisplay, double dTimeout /* = 1e74 */)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	IloEnv cSolveEnv;
	IloNumVarArray cPriorityVariables(cSolveEnv);
	deque<DisjunctionEncoder> dequeEncoders;
	IloNumVarArray cLinkFBVariables(cSolveEnv);
	deque<DisjunctionEncoder> dequeLinkEncoders;
	IloRangeArray cConst(cSolveEnv);

	CreatePriortyVariable(cPriorityVariables);
	CreateEncodingVariable(cSolveEnv, dequeEncoders);	

	for (int i = 0; i < iTaskNum; i++)
	{
		for (Task::CommIter iter = pcTaskArray[i].SuccessorBegin(); iter != pcTaskArray[i].SuccessorEnd(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			if (pcTaskArray[iDestination].getPeriod() >= pcTaskArray[iSource].getPeriod())
			{
				(getPriorityVariable(iSource, iDestination, cPriorityVariables)).setLB(1.0);
				cConst.add(IloRange(cSolveEnv, 1.0, getPriorityVariable(iSource, iDestination, cPriorityVariables), 1.0));
			}
		}
	}
	
	BuildSchedConstLO(cPriorityVariables, dequeEncoders, cConst);
	GenPriorityConst(cPriorityVariables, cConst);	
	IloObjective cObjective(cSolveEnv);
	cObjective = GenObjective(cPriorityVariables);

	IloModel cModel(cSolveEnv);
	cModel.add(cConst);
	cModel.add(cObjective);

	IloCplex cSolver(cModel);

	EnableSolverDisp(iDisplay, cSolver);
	setSolverParam(cSolver);
	cSolver.setParam(IloCplex::Param::TimeLimit, dTimeout);
	//cSolver.exportModel("A:\\FVM2.sav");

	m_dSolveCPUTime = getCPUTimeStamp();
	m_dSolveWallTime = cSolver.getCplexTime();
	bool bStatus = cSolver.solve();
	m_dSolveCPUTime = getCPUTimeStamp() - m_dSolveCPUTime;
	m_dSolveWallTime = cSolver.getCplexTime() - m_dSolveWallTime;
	int iRetStatus = 0;
	if (bStatus)
	{
		assert(VerifyPriority(cPriorityVariables, cSolver));
		ExtractPriorityResult(cPriorityVariables, cSolver);
		assert(VerifySchedulability(iModelType));	
		m_bIsValidSolution = true;
	}


	{
		m_bIsValidSolution = false;
		if (cSolver.getCplexStatus() == cSolver.Optimal)
			iRetStatus = 1;
		else if (cSolver.getCplexStatus() == cSolver.AbortTimeLim)
			iRetStatus = -1;
		else if (cSolver.getCplexStatus() == cSolver.Infeasible)
			iRetStatus = 0;
		else
			iRetStatus = 0;
	}

	cSolver.end();
	cModel.end();
	cConst.end();
	cPriorityVariables.end();
	cLinkFBVariables.end();
	cSolveEnv.end();
	return iRetStatus;

}


//Fast Focus Refinement

ILOMIPINFOCALLBACK5(timeLimitCallback,
	IloCplex, cplex,
	IloBool, aborted,
	IloNum, timeStart,
	IloNum, timeLimit,	
	IloNum, acceptableGap)
{
	if (!aborted  &&  hasIncumbent()) {
		IloNum gap = 100.0 * getMIPRelativeGap();			
		IloNum timeUsed = cplex.getCplexTime() - timeStart;	
		if (timeUsed > timeLimit && gap < acceptableGap) {			
			aborted = IloTrue;
			abort();
		}
	}
}

SimuLinkMiniDelay_FR::IterationStatus::IterationStatus()
{
	iIterationN = 0;
	iTotalCores = 0;
	dObjective = 0;
	dBestFeasible = 0;
	dTime = 0;
	dCPUTime = 0;
	dUCComputeTime = 0;
	dILPTime = 0;
	iStatus = 0;
	enumState = Search;
}

SimuLinkMiniDelay_FR::SimuLinkMiniDelay_FR()
{

}

SimuLinkMiniDelay_FR::SimuLinkMiniDelay_FR(TaskSet & rcTaskSet)	
	:FocusRefinement(rcTaskSet),
	m_cUnschedCoreComputer(rcTaskSet)
{	
	m_pcTaskSet = &rcTaskSet;
	m_mapIndex2LinkData.clear();
	m_mapLink2Index.clear();	
	InitializeLinkObj();			
	m_enumAlgConfig = enumAlgConfig::Lazy;
	m_dILPTimeout = 1e74;
	m_iSubILPDisplay = 0;
	m_dILPOptGap = 100;
	m_iTerminateOnFeasible = 0;
	m_iCorePerIter = 10;
	m_dObjUB = 1e74;
	m_dObjLB = -1e74;
}

SimuLinkMiniDelay_FR::~SimuLinkMiniDelay_FR()
{

}

void SimuLinkMiniDelay_FR::InitializeLinkObj()
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iLinkIndex = 0;
	for (int i = 0; i < iTaskNum; i++)
	{
		for (set<Task::CommunicationLink>::iterator iter = pcTaskArray[i].getSuccessorSet().begin();
			iter != pcTaskArray[i].getSuccessorSet().end(); iter++)
		{
			int iType = 0;
			if (DOUBLE_EQUAL(pcTaskArray[i].getPeriod(), pcTaskArray[iter->m_iTargetTask].getPeriod(), 1e-7))
			{
				iType = SIMULINK_LINKTYPE_EQ;
			}
			else if (pcTaskArray[i].getPeriod() < pcTaskArray[iter->m_iTargetTask].getPeriod())
			{
				iType = SIMULINK_LINKTYPE_HL;
			}
			else
			{
				iType = SIMULINK_LINKTYPE_LH;
			}

			//m_cLinkObj[SimuLinkMiniDelay_Link(i, iter->m_iTargetTask)] = SimuLinkMiniDelay_LinkData(iter->m_dMemoryCost, iter->m_dDelayCost* 1.0, iType);
			m_mapLink2Index[SimuLinkMiniDelay_Link(i, iter->m_iTargetTask)] = iLinkIndex;
#if 1
			m_mapIndex2LinkData[iLinkIndex] = SimuLinkMiniDelay_LinkData(i, iter->m_iTargetTask, iter->m_dMemoryCost, iter->m_dDelayCost* 1.0, iType);
#else
			m_mapIndex2LinkData[iLinkIndex] = SimuLinkMiniDelay_LinkData(i, iter->m_iTargetTask, iter->m_dMemoryCost, 1.0, iType);
#endif
			iLinkIndex++;
		}
	}
}

void SimuLinkMiniDelay_FR::GenFixedPPOSet(PriorityPOSet & rcFixedSet)
{
	rcFixedSet.clear();
	int iTaskNum = m_pcTaskSet->getTaskNum();
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_HL || iter->second.m_iType == SIMULINK_LINKTYPE_EQ)
		{
			int iSrc = iter->second.m_iSource;
			int iDst = iter->second.m_iDestination;
			rcFixedSet.insert(PriorityPOElement(iSrc, iDst));						
		}
	}
}

bool SimuLinkMiniDelay_FR::VerifyDelay(double dDelay, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	//Verify Delay
	double dActualDelay = 0;
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			int iSource = iter->second.m_iSource;
			int iDestination = iter->second.m_iDestination;
			int iSourceP = rcPriorityAssignment.getPriorityByTask(iSource);
			int iDestinationP = rcPriorityAssignment.getPriorityByTask(iDestination);
			if (iDestinationP < iSourceP)
			{
				//dActualDelay += iter->m_dDelayCost;
				int iLinkIndex = m_mapLink2Index[SimuLinkMiniDelay_Link(iSource, iDestination)];
				dActualDelay += m_mapIndex2LinkData[iLinkIndex].m_dDelayCost;
			}
		}

	}


	//if (dActualDelay != dDelay)
	if (abs(dActualDelay - dDelay) > 1e-7)
	{
		rcPriorityAssignment.Print();
		cout << "Link Solution: " << m_cPPOSolution << endl;
		cout << dActualDelay << " " << dDelay << endl;
		assert(0);
	}

	return true;
}

bool SimuLinkMiniDelay_FR::VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment)
{
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		assert(rcPriorityAssignment.getPriorityByTask(i) != -1);
		cRTCalc.setPrioirty(i, rcPriorityAssignment.getPriorityByTask(i));
	}
	cRTCalc.Calculate(RTCALC_LO);
	bool bSchedulable = !cRTCalc.getDeadlineMiss();
	assert(bSchedulable);
	return true;
}

bool SimuLinkMiniDelay_FR::VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	VerifySchedulability(rcPriorityAssignment);

	VerifyDelay(dObjective, rcPriorityAssignment);

	return true;
}

IloExpr SimuLinkMiniDelay_FR::ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cObjExpression(rcEnv);
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if (iter->second.m_iType == SIMULINK_LINKTYPE_LH)
		{
			int iSource = iter->second.m_iSource;
			int iDestination = iter->second.m_iDestination;
			if (iter->second.m_dDelayCost != 0)
			{
				cObjExpression += (1.0 - getPriorityVariable(iSource, iDestination, rcPVars)) * iter->second.m_dDelayCost;
				if (pcRelevantPPO)
				{
					pcRelevantPPO->insert(PriorityPOElement(iSource, iDestination));
				}
			}
		}
	}
	return cObjExpression;
}

double SimuLinkMiniDelay_FR::getObjUB()
{
	double dValue = 0;
	for (map<int, SimuLinkMiniDelay_LinkData>::iterator iter = m_mapIndex2LinkData.begin();
		iter != m_mapIndex2LinkData.end(); iter++)
	{
		if ((iter->second.m_iType == SIMULINK_LINKTYPE_LH) || (iter->second.m_iType == SIMULINK_LINKTYPE_EQ))
		{
			dValue += iter->second.m_dDelayCost;
		}
	}
	return dValue;
}

bool SimuLinkMiniDelay_FR::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{

	return m_cUnschedCoreComputer.IsSchedulable(rcPriorityAssignment, rcPPOSet);
}

int SimuLinkMiniDelay_FR::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{
	//SimuLinkMiniDelay_FR::ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
	return m_cUnschedCoreComputer.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
}

//FR for AMC-max

SimuLinkMiniDelay_FR_AMCMax::SimuLinkMiniDelay_FR_AMCMax(TaskSet & rcTaskSet)
	:SimuLinkMiniDelay_FR(rcTaskSet),
	m_cUnschedCoreComputer_AMCMax(rcTaskSet)
{

}

SimuLinkMiniDelay_FR_AMCMax::SimuLinkMiniDelay_FR_AMCMax()
{

}

SimuLinkMiniDelay_FR_AMCMax::~SimuLinkMiniDelay_FR_AMCMax()
{

}

bool SimuLinkMiniDelay_FR_AMCMax::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	return m_cUnschedCoreComputer_AMCMax.IsSchedulable(rcPriorityAssignment, rcPPOSet);
}

bool SimuLinkMiniDelay_FR_AMCMax::VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment)
{
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		assert(rcPriorityAssignment.getPriorityByTask(i) != -1);
		cRTCalc.setPrioirty(i, rcPriorityAssignment.getPriorityByTask(i));
	}
	cRTCalc.Calculate(RTCALC_AMCMAX);
	bool bSchedulable = !cRTCalc.getDeadlineMiss();

	if (!bSchedulable)
	{
		m_pcTaskSet->DisplayTaskInfo();
		rcPriorityAssignment.Print();
		_AMCMaxRTCalculator cRTCalc2(*m_pcTaskSet);
		for (int i = 0; i < iTaskNum; i++)
		{
			if (cRTCalc.getResponseTime(i) > pcTaskArray[i].getDeadline())
			{
				cout << "Task " << i << " Unschedulable:" << endl;
				cout << cRTCalc.getResponseTime(i) << " " << pcTaskArray[i].getDeadline() << endl;
				cout << cRTCalc2.CalculateRTTask(i,rcPriorityAssignment) << endl;
				system("pause");
			}
		}
	}
	
	assert(bSchedulable);
	return true;
}

int SimuLinkMiniDelay_FR_AMCMax::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{	
	//SimuLinkMiniDelay_FR::ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
	return m_cUnschedCoreComputer_AMCMax.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
}

//FR for AMC-rtb

SimuLinkMiniDelay_FR_AMCRtb::SimuLinkMiniDelay_FR_AMCRtb(TaskSet & rcTaskSet)
	:SimuLinkMiniDelay_FR(rcTaskSet),
	m_cUnschedCoreComputer_AMCRtb(rcTaskSet)
{

}

SimuLinkMiniDelay_FR_AMCRtb::SimuLinkMiniDelay_FR_AMCRtb()
{

}

SimuLinkMiniDelay_FR_AMCRtb::~SimuLinkMiniDelay_FR_AMCRtb()
{

}

bool SimuLinkMiniDelay_FR_AMCRtb::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{	
	return m_cUnschedCoreComputer_AMCRtb.IsSchedulable(rcPriorityAssignment, rcPPOSet);
}

bool SimuLinkMiniDelay_FR_AMCRtb::VerifySchedulability(TaskSetPriorityStruct & rcPriorityAssignment)
{
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		assert(rcPriorityAssignment.getPriorityByTask(i) != -1);
		cRTCalc.setPrioirty(i, rcPriorityAssignment.getPriorityByTask(i));
	}
	cRTCalc.Calculate(RTCALC_AMCRTB);
	bool bSchedulable = !cRTCalc.getDeadlineMiss();
	assert(bSchedulable);
	return true;
}

int SimuLinkMiniDelay_FR_AMCRtb::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{
	//SimuLinkMiniDelay_FR::ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
	return m_cUnschedCoreComputer_AMCRtb.ComputeUnschedCores(rcPPOSet, rcFixedSet, rcUnschedCores, iLimit);
}
