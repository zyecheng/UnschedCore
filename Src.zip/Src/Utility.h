/* \file Utility.h
 *  This file implements some math-related functions.
 *  \author Chao Peng
 *  
 *  Changes
 *  ------
 *  22-Aug-2015 : Initial revision (CP)
 *
 */

#ifndef UTILITY_H
#define UTILITY_H

//#include <vld.h>
#include "stdafx.h"
#include <string>
#include <iostream>

class Utility {
public:
	static double EPSILON;

	// return the greatest common divisor for two integers
	static int math_gcd(int a, int b);
	static int math_lcm(int a, int b);
	static std::string int_to_string(int a);
	static double** creat_matrix(int nrow, int ncol);
	static void output_matrix(double** A, int nrow, int ncol);
	static void output_latex_matrix(double** A, int nrow, int ncol);
	static double* uniformly_distributed(int n, double tUtil);
	static double* uniformly_distributed2(int n, double tUtil);
	static double max_uniformly_distributed(int n, double tUtil);
	static bool compare_two_matrices(double** A, double** B, int n);
};

class ObjRefTracker
{
private:
	int * m_piReferenceNum;
public:
	ObjRefTracker()
	{
		m_piReferenceNum = new int;
		*m_piReferenceNum = 1;
	}

	~ObjRefTracker()
	{
		*m_piReferenceNum--;
		if (*m_piReferenceNum == 0)
		{
			delete m_piReferenceNum;
		}
	}

	ObjRefTracker(const ObjRefTracker & rcSrcObj)
	{
		if (m_piReferenceNum != rcSrcObj.m_piReferenceNum)
		{

			m_piReferenceNum = rcSrcObj.m_piReferenceNum;
			*m_piReferenceNum++;
		}
		
	}

	int getReferenceIndex()	
	{ 
		return *m_piReferenceNum; 
	}

	ObjRefTracker & operator = (const ObjRefTracker & rcSource)
	{
		m_piReferenceNum = rcSource.m_piReferenceNum;
		*m_piReferenceNum++;
		return *this;
	}
};

#endif