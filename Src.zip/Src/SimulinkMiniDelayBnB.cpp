#include "stdafx.h"
#include "SimulinkMiniDelayBnB.h"
#include "ResponseTimeCalculator.h"
#include "Util.h"
#include "StatisticSet.h"
#include <time.h>
#include "Timer.h"

SimulinkMiniDelayBnB::SimulinkMiniDelayBnB_Link::SimulinkMiniDelayBnB_Link()
{
	m_iSource = 0;
	m_iDestination = 0;
	m_dDelayCost = 0;
	m_dMemoryCost = 0;
}

SimulinkMiniDelayBnB::SimulinkMiniDelayBnB_Link::~SimulinkMiniDelayBnB_Link()
{

}

SimulinkMiniDelayBnB::SimulinkMiniDelayBnB_Link::SimulinkMiniDelayBnB_Link(int iSource, int iDestination, double dDelayCost, double dMemoryCost)
{	
	m_iSource = iSource;
	m_iDestination = iDestination;
	m_dDelayCost = dDelayCost;
	m_dMemoryCost = dMemoryCost;
}

bool operator < (const SimulinkMiniDelayBnB::SimulinkMiniDelayBnB_Link & rcLHS, const SimulinkMiniDelayBnB::SimulinkMiniDelayBnB_Link & rcRHS)
{
	if (DOUBLE_EQUAL(rcLHS.m_dDelayCost, rcRHS.m_dDelayCost, 1e-8))
	{
		if (rcLHS.m_iSource == rcRHS.m_iSource)
		{
			return rcLHS.m_iDestination < rcRHS.m_iDestination;
		}
		else
		{
			return rcLHS.m_iSource < rcRHS.m_iSource;
		}
	}
	else
	{
		return rcLHS.m_dDelayCost < rcRHS.m_dDelayCost;
	}
	return false;
}

SimulinkMiniDelayBnB::SimulinkMiniDelayBnB()
{
}

SimulinkMiniDelayBnB::SimulinkMiniDelayBnB(TaskSet & rcTaskSet)
{
	m_dBestDelay = -1;
	m_pcTaskSet = &rcTaskSet;
	InitializeLinkData();
}

void SimulinkMiniDelayBnB::InitializeLinkData()
{
	int iLinkNum = 0;
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (set<Task::CommunicationLink>::iterator iter = pcTaskArray[i].getSuccessorSet().begin();
			iter != pcTaskArray[i].getSuccessorSet().end(); iter++)
		{
			int iSource = i;
			int iDestination = iter->m_iTargetTask;
			double m_dSrcPeriod = pcTaskArray[iSource].getPeriod();
			double m_dDstPeriod = pcTaskArray[iDestination].getPeriod();
			if (m_dSrcPeriod > m_dDstPeriod)
			{				
				//if (iLinkNum >= 10) continue;
				m_setLHLinks.insert(SimulinkMiniDelayBnB_Link(iSource, iDestination, iter->m_dDelayCost, iter->m_dMemoryCost));
				iLinkNum++;
			}
			else if (m_dSrcPeriod == m_dDstPeriod)
			{
				m_setLHLinks.insert(SimulinkMiniDelayBnB_Link(iSource, iDestination, iter->m_dDelayCost, iter->m_dMemoryCost));
				iLinkNum++;
				m_cPOSet.setPartialOrder(iSource, iDestination);
			}
			else if (m_dSrcPeriod < m_dDstPeriod)
			{
				m_cPOSet.setPartialOrder(iSource, iDestination);
			}
		}
	}
}


SimulinkMiniDelayBnB::~SimulinkMiniDelayBnB()
{
}

bool SimulinkMiniDelayBnB::setPartialOrder(int iTaskA, int iTaskB)
{
	return m_cPOSet.setPartialOrder(iTaskA, iTaskB);
}

void SimulinkMiniDelayBnB::setBestDelay(double dDelay)
{
	m_dBestDelay = dDelay;
}

void SimulinkMiniDelayBnB::Run(int iDisplay, double dTimeout /* = 1e74 */)
{
	m_dTimeout = dTimeout;
	m_dTimeStart = time(NULL);
	m_dBestDelay = m_dBestDelay > 0 ? m_dBestDelay : -1;	
	m_iRecursionN = 0;
	m_iDisplay = iDisplay;
	m_dBestDelay = getWorstDelay();
	Timer cTimer;
	cTimer.StartThread();
	if(iDisplay) cout << "Timeout: " <<  m_dTimeout << endl;
	TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	m_iStatus = 0;
	clock_t iClockStart = clock();
	if (IsSchedulable(m_cPOSet, 0, cPriorityAssignment))
	{
		m_dBestDelay = EstimateDelayCost(cPriorityAssignment);
		if (iDisplay)
			cout << "Best Delay: " << m_dBestDelay << endl;
		DelayRecur(m_setLHLinks.begin(), 0, 0, m_cPOSet);
		if (m_iStatus != -2)
		{
			m_iStatus = 1;
		}		
	}
	else
	{
		m_iStatus = 0;
	}	
	cTimer.StopThread();
	m_dThreadCPUTime = cTimer.getElapsedThreadTime_ms();
	m_dTimeElapsed = time(NULL) - m_dTimeStart;
	m_dTimeElapsed = (double)(clock() - iClockStart) / double(CLOCKS_PER_SEC);
	if (m_iDisplay)
	{
		cout << endl;
		cout << "Time: " << m_dTimeElapsed << endl;
	}
	return;
}

void SimulinkMiniDelayBnB::DisplayFlippableLink()
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (set<SimulinkMiniDelayBnB_Link>::iterator iter = m_setLHLinks.begin();
		iter != m_setLHLinks.end(); iter++)
	{
		int iSrc = iter->m_iSource;
		int iDst = iter->m_iDestination;
		if (m_cPOSet.getPartialOrder(iDst, iSrc) == -1)
		{
			printf_s("LH Link: (%d, %d) (%.0f, %.0f)\n",
				iSrc, iDst, pcTaskArray[iSrc].getPeriod(), pcTaskArray[iDst].getPeriod());
		}
	}
}

void SimulinkMiniDelayBnB::DelayRecur(set<SimulinkMiniDelayBnB_Link>::iterator iterCurrLink, double dDelay, double dMemoryCost, PartialOrderSet<int> & rcPOSet)
{

	if (time(NULL) - m_dTimeStart > m_dTimeout)
	{		
		m_iStatus = -2;
		return;
	}
	
	//Skip the unflippable ones
	while (iterCurrLink != m_setLHLinks.end())
	{
		int iPO = m_cPOSet.getPartialOrder(iterCurrLink->m_iDestination, iterCurrLink->m_iSource);
		if (iPO != -1)
		{
			//assert(iPO == 1);
			if (iPO == 1)
			{
				dDelay += iterCurrLink->m_dDelayCost;
				dMemoryCost += iterCurrLink->m_dMemoryCost;				
			}			
			iterCurrLink++;
		}
		else
		{
			break;
		}
	}
		
	if (dMemoryCost > m_pcTaskSet->getAvailableMemory())
	{
		//assert(0);
		return;
	}

	if( (dDelay >= m_dBestDelay) && (m_dBestDelay >= 0))
	{
		return;
	}

	if (iterCurrLink == m_setLHLinks.end())
	{
		m_iRecursionN++;
		if (m_iDisplay)
			cout << "\rRecursion: " << m_iRecursionN << "                    ";
		//Base Case
		TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);		
		if (IsSchedulable(rcPOSet, dMemoryCost, cPriorityAssignment) == 1)
		{
			if (!(((m_dBestDelay > dDelay) || (m_dBestDelay < 0))))
			{
				cout << m_dBestDelay << " " << dDelay << endl;
			}
			assert((m_dBestDelay > dDelay) || (m_dBestDelay < 0));			
			m_dBestDelay = dDelay;
			m_dBestMemory = dMemoryCost;
			m_cBestPriorityAssignment = cPriorityAssignment;
			if (m_iDisplay)
				cout << endl << "Best Delay: " << m_dBestDelay << endl;
			//cout << "Tested " << m_iRecursionN << endl;
		}
		return;
	}

	//Two Branch: Flipped or Not Flipped

	set<SimulinkMiniDelayBnB_Link>::iterator iterNextLink = iterCurrLink;
	iterNextLink++;

	int iSource = iterCurrLink->m_iSource;
	int iDestination = iterCurrLink->m_iDestination;

#if 1
	PartialOrderSet<int> cThisPOFlipped = rcPOSet;
	if (cThisPOFlipped.setPartialOrder(iDestination, iSource))
	{
		DelayRecur(iterNextLink, dDelay + iterCurrLink->m_dDelayCost,
			dMemoryCost + iterCurrLink->m_dMemoryCost, cThisPOFlipped);
	}

	PartialOrderSet<int> cThisPONotFlipped = rcPOSet;
	if (cThisPONotFlipped.setPartialOrder(iSource, iDestination))
	{
		DelayRecur(iterNextLink, dDelay, dMemoryCost, cThisPONotFlipped);
	}
#else
	PartialOrderSet<int> cThisPONotFlipped = rcPOSet;
	if (cThisPONotFlipped.setPartialOrder(iSource, iDestination))
	{
		DelayRecur(iterNextLink, dDelay, dMemoryCost, cThisPONotFlipped);
	}

	PartialOrderSet<int> cThisPOFlipped = rcPOSet;
	if (cThisPOFlipped.setPartialOrder(iDestination, iSource))
	{
		DelayRecur(iterNextLink, dDelay + iterCurrLink->m_dDelayCost,
			dMemoryCost + iterCurrLink->m_dMemoryCost, cThisPOFlipped);
	}	
#endif


	return;
}

bool SimulinkMiniDelayBnB::ExistUnassignedHPTask(int iTaskIndex, PartialOrderSet<int> & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{				
		if ((rcPOSet.getPartialOrder(iTaskIndex, i) == 1) && (rcPriorityAssignment.getPriorityByTask(i) == -1))
			return true;
	}
	return false;
}

bool SimulinkMiniDelayBnB::IsSchedulable(PartialOrderSet<int> & rcPOSet, double dMemoryCost, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);	
	if (IsSchedulableRecur(iTaskNum - 1, dMemoryCost, rcPOSet, rcPriorityAssignment) == 1)
	{
		return true;
	}
	return false;
}

double SimulinkMiniDelayBnB::EstimateMemoryCost(int iTaskIndex, double dResponseTime, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	double dMemoryCost = 0;
	for (set<Task::CommunicationLink>::iterator iter = pcTaskArray[iTaskIndex].getPredecessorSet().begin();
		iter != pcTaskArray[iTaskIndex].getPredecessorSet().end(); iter++)
	{
		int iSource = iter->m_iTargetTask;
		int iDestination = iTaskIndex;

		double m_dSrcPeriod = pcTaskArray[iSource].getPeriod();
		double m_dDstPeriod = pcTaskArray[iDestination].getPeriod();

		int iPrioritySource = rcPriorityAssignment.getPriorityByTask(iSource);
		int iPriorityDestination = rcPriorityAssignment.getPriorityByTask(iDestination);

		assert(iPriorityDestination != -1);
		if (iPrioritySource != -1)
		{
			assert(iPrioritySource > iPriorityDestination);
			continue;
		}

		if (m_dSrcPeriod < m_dDstPeriod)//HL Link
		{
			if (dResponseTime > pcTaskArray[iSource].getDeadline())
			{
				dMemoryCost += iter->m_dMemoryCost;
			}
		}
	}
	return dMemoryCost;
}

int SimulinkMiniDelayBnB::IsSchedulableRecur(int iPriority, double dMemoryCost, PartialOrderSet<int> & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	int iNextPriority = iPriority - 1;
	bool bIsTaskLeft = false;
	bool bMemoryIssue = false;
	for (int i = 0; i < iTaskNum; i++)
	{
		if (rcPriorityAssignment.getPriorityByTask(i) != -1)
			continue;
		else
			bIsTaskLeft = true;

		if (ExistUnassignedHPTask(i, rcPOSet, rcPriorityAssignment))	continue;

		rcPriorityAssignment.setPriority(i, iPriority);
		double dRT = CalcResponseTime(i, rcPriorityAssignment);
		if (dRT > pcTaskArray[i].getDeadline())
		{
			rcPriorityAssignment.unset(i);
			continue;
		}

		double dMemInc = EstimateMemoryCost(i, dRT, rcPriorityAssignment);
		if (dMemInc + dMemoryCost <= m_pcTaskSet->getAvailableMemory())
		{
			int iStatus = IsSchedulableRecur(iNextPriority, dMemInc + dMemoryCost, rcPOSet, rcPriorityAssignment);
			if (iStatus == 1)
				return 1;
			else if (iStatus == -1)
				return -1;
		}
		else
		{
			bMemoryIssue = true;
		}
		rcPriorityAssignment.unset(i);
	}

	if (bIsTaskLeft)
	{
		if (bMemoryIssue)
			return 0;
		else
			return -1;
	}		
	else
		return 1;
}

double SimulinkMiniDelayBnB::CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);
	assert(rcPriorityStruct.getPriorityByTask(iTaskIndex) != -1);
	for (int i = 0; i < iTaskNum; i++)
	{		
		int iPriority = rcPriorityStruct.getPriorityByTask(i);
		if (iPriority == -1)
			cRTCalc.setPrioirty(i, 0);
		else
			cRTCalc.setPrioirty(i, iPriority);
	}
	return cRTCalc.CalcResponseTimeTask(iTaskIndex, RTCALC_LO);
}

void SimulinkMiniDelayBnB::WriteStatisticFile(const char axFileName[])
{
	StatisticSet cStatisticSet;
	char axBuffer[512] = { 0 };
	switch (m_iStatus)
	{
	case 1:
		cStatisticSet.setItem("Status", "Optimal");
		break;
	case 0:
		cStatisticSet.setItem("Status", "Infeasible");
		break;
	case -2:
		cStatisticSet.setItem("Status", "Timeout");
		break;
	default:
		sprintf_s(axBuffer, "%d", m_iStatus);
		cStatisticSet.setItem("Status", axBuffer);
		break;
	}

	cStatisticSet.setItem("Objective", m_dBestDelay);
	cStatisticSet.setItem("Objective UB", getWorstDelay());
	cStatisticSet.setItem("Memory", m_dBestMemory);
	cStatisticSet.setItem("Time", m_dTimeElapsed);
	cStatisticSet.setItem("Recursions", m_iRecursionN);
	cStatisticSet.setItem("Thread CPU Time", m_dThreadCPUTime);

	sprintf_s(axBuffer, "%s.rslt", axFileName);
	cStatisticSet.WriteStatisticImage((char *)axBuffer);
	sprintf_s(axBuffer, "%s.txt", axFileName);
	cStatisticSet.WriteStatisticText((char *)axBuffer);
}

double SimulinkMiniDelayBnB::getWorstDelay()
{
	double dValue = 0;
	for (set<SimulinkMiniDelayBnB_Link>::iterator iter = m_setLHLinks.begin();
		iter != m_setLHLinks.end(); iter++)
	{
		dValue += iter->m_dDelayCost;
	}
	return dValue;
}

double SimulinkMiniDelayBnB::EstimateDelayCost(TaskSetPriorityStruct & rcPriorityAssignment)
{
	double dValue = 0;
	for (set<SimulinkMiniDelayBnB_Link>::iterator iter = m_setLHLinks.begin();
		iter != m_setLHLinks.end(); iter++)
	{
		int iSource = iter->m_iSource;
		int iDestination = iter->m_iDestination;
		if (rcPriorityAssignment.getPriorityByTask(iSource) > rcPriorityAssignment.getPriorityByTask(iDestination))
		{
			dValue += iter->m_dDelayCost;
		}		
	}
	return dValue;	
}

//AMC Max

SimulinkMiniDelayBnB_AMCMax::SimulinkMiniDelayBnB_AMCMax()
{
}

SimulinkMiniDelayBnB_AMCMax::SimulinkMiniDelayBnB_AMCMax(TaskSet & rcTaskSet)
	:m_cUnschedCore(rcTaskSet)
{
	m_dBestDelay = -1;
	m_pcTaskSet = &rcTaskSet;
	InitializeLinkData();
}

SimulinkMiniDelayBnB_AMCMax::~SimulinkMiniDelayBnB_AMCMax()
{

}

double SimulinkMiniDelayBnB_AMCMax::CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (m_cUnschedCore.IsSchedulable(iTaskIndex, rcPriorityStruct))
	{
		return pcTaskArray[iTaskIndex].getDeadline() - 1;
	}
	else
	{
		return pcTaskArray[iTaskIndex].getDeadline() + 1;
	}
}

//AMC rtb

SimulinkMiniDelayBnB_AMCRtb::SimulinkMiniDelayBnB_AMCRtb()
{
}

SimulinkMiniDelayBnB_AMCRtb::SimulinkMiniDelayBnB_AMCRtb(TaskSet & rcTaskSet)
	:m_cUnschedCore(rcTaskSet)
{
	m_dBestDelay = -1;
	m_pcTaskSet = &rcTaskSet;
	InitializeLinkData();
}

SimulinkMiniDelayBnB_AMCRtb::~SimulinkMiniDelayBnB_AMCRtb()
{

}

double SimulinkMiniDelayBnB_AMCRtb::CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (m_cUnschedCore.IsSchedulable(iTaskIndex, rcPriorityStruct))
	{
		return pcTaskArray[iTaskIndex].getDeadline() - 1;
	}
	else
	{
		return pcTaskArray[iTaskIndex].getDeadline() + 1;
	}
}