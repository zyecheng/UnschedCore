#pragma once 
#include <map>
#include <set>
#include <algorithm>
#include <assert.h>

template<
	class T, 
	class CompObj = less<T>, 
	class SetAlloc = allocator<T>,
	class MapAlloc = allocator< pair<T, set<T, CompObj, SetAlloc> > > >
class PartialOrderSet
{
public:
	typedef set<T, CompObj, SetAlloc> ElementSet;
	typedef map<T, ElementSet, CompObj, MapAlloc> ElementMap;
private:
	ElementMap m_mapPartialOrder;
	set<T, CompObj, SetAlloc> m_setTCFlag;
public:
	PartialOrderSet()
	{

	}

	~PartialOrderSet()
	{

	}

	bool setPartialOrder(T EleA, T EleB)
	{		
		int iPO = getPartialOrder(EleA, EleB);
		if (iPO == -1)
		{			
			ElementSet & rsetChild = m_mapPartialOrder[EleB];
			ElementSet & rsetThis = m_mapPartialOrder[EleA];									
			rsetThis.insert(rsetChild.begin(), rsetChild.end());

			for (typename ElementMap::iterator iter = m_mapPartialOrder.begin(); iter != m_mapPartialOrder.end(); iter++)
			{
				if (Compare(iter->first, EleA) == -1)	continue;

				if (getPartialOrder(iter->first, EleA) == 1)
				{
					if (iter->second.count(EleB) != 1)
						iter->second.insert(rsetChild.begin(), rsetChild.end());
				}
			}
			return true;
		}	
		else if (iPO == 0)
			return false;
		else if (iPO == 1)
			return true;
		else
			assert(0);
		return false;
	}

	int getPartialOrder(T EleA, T EleB)
	{		
		if (m_mapPartialOrder.count(EleA) == 0)
		{
			m_mapPartialOrder[EleA] = { EleA };
		}

		if (m_mapPartialOrder.count(EleB) == 0)
		{
			m_mapPartialOrder[EleB] = { EleB };
		}

		if (Compare(EleA, EleB) == -1) return -1;

		if (m_mapPartialOrder[EleA].count(EleB) == 1)
			return 1;
	
		if (m_mapPartialOrder[EleB].count(EleA))
			return 0;

		return -1;
	}

	void TransitiveClosure()
	{
		m_setTCFlag.clear();

		ElementSet setPred;

		for (typename ElementMap::iterator iter = m_mapPartialOrder.begin();
			iter != m_mapPartialOrder.end(); iter++)
		{
			TransitiveClosurePerEle(iter->first, setPred);
		}
	}

	int getPartialOrderSize()
	{
		int iSize = 0;
		for (typename ElementMap::iterator iter = m_mapPartialOrder.begin();
			iter != m_mapPartialOrder.end(); iter++)
		{
			iSize += iter->second.size() - 1;
		}

		return iSize;
	}

private:
	void TransitiveClosurePerEle(const T & Ele, ElementSet & rsetPred)
	{
		if (rsetPred.count(Ele))
		{
			cout << "Cycle Detected Not Allowed" << endl;
			assert(0);
		}
		
		if (m_setTCFlag.count(Ele) == 1)
			return;

		rsetPred.insert(Ele);

		if (m_mapPartialOrder.count(Ele) == 0)
			m_mapPartialOrder[Ele] = ElementSet();
		
		ElementSet & rsetSet = m_mapPartialOrder[Ele];		
		rsetSet.insert(Ele);
		for (typename ElementMap::iterator iter = rsetSet.begin(); iter != rsetSet.end(); iter++)
		{			
			if (Compare(Ele, *iter) == -1) continue;

			TransitiveClosurePerEle(*iter, rsetPred);
			ElementSet & rsetSetChild = m_mapPartialOrder[*iter];
			rsetSet.insert(rsetSetChild.begin(), rsetSetChild.end());
		}		
		m_setTCFlag.insert(Ele);
		rsetPred.erase(Ele);
	}

	int Compare(const T & EleLHS, const T & EleRHS)
	{
		CompObj Comparator;
		bool bA = Comparator(EleLHS, EleRHS);
		bool bB = Comparator(EleRHS, EleLHS);		
		if (bA)
		{
			assert(bA ^ bB);
			return 0;
		}
		else if (bB)
		{
			assert(bA ^ bB);
			return 1;
		}
		else if ((!bA) && (!bB))
		{
			return -1;
		}
		else
		{
			assert(0);
			return 0;
		}
	}
};