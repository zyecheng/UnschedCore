#pragma once
#include <ilcplex/ilocplex.h>
#include "RTSchedPTree.h"
#include "StatisticSet.h"
class FocusRefinement
{
public:
public:
	typedef UnschedCoreComputer::PriorityPOElement PriorityPOElement;
	typedef MySet<PriorityPOElement> PriorityPOSet;
	typedef MySet<PriorityPOSet, UnschedCoreComputer::PriorityPOSetComp> PPOSetSort;
	typedef deque<PriorityPOSet>	UnschedCores;
#define ITERSTATUS_SEARCH	0
#define ITERSTATUS_OPTIMAL	1
#define ITERSTATUS_ABORT	2
#define ITERSTATUS_INFEASIBLE	3
#define ITERSTATUS_TIMEOUT	4
#define ITERSTATUS_FEASIBLE	5
#define ITERSTATUS_MA	6
	enum IterationState
	{
		Search,
		Optimal,
		Abort,
		Infeasible,
		Timeout,
		Feasible,
		Mixed_Approximation,
	};

	struct IterationStatus
	{
		int iIterationN;
		PriorityPOSet cLinkConfigSol;
		UnschedCores cThisUnschedCores;
		int iTotalCores;
		double dObjective;
		double dBestFeasible;
		double dObjLB;
		double dTime;
		double dCPUTime;
		double dUCComputeTime;
		double dILPTime;
		int iStatus;
		IterationState enumState;
		IterationStatus();
	};

	enum enumAlgConfig
	{
		Lazy,
		Eager
	};

protected:
	TaskSet * m_pcTaskSet;

	PriorityPOSet m_cPPOSolution;
	deque<IterationStatus> m_dequeIterationLogs;
	string m_stringLogFile;
	double m_dTotalTime;
	TaskSetPriorityStruct m_cPriorityAssignmentSol;
	//UnschedCoreComputer m_cUnschedCoreComputer;
	IterationStatus m_cFinalStatistic;
	IloCplex::Status m_cCplexStatus;
	clock_t m_iStartClock;
	double m_dObjective;
	double m_dSolveCPUTime;
	double m_dSolveWallTime;
	bool m_bIsValidSolution;
	//Configuration
	enumAlgConfig m_enumAlgConfig;
	int m_iAlgConfig;
	double m_dILPTimeout;
	double m_dILPOptGap;
	int m_iSubILPDisplay;
	int m_iTerminateOnFeasible;
	int m_iCorePerIter;

	typedef deque< std::pair<double, PriorityPOSet> > SolutionPoolDeque;
	SolutionPoolDeque m_dequeSolutionPools;
	double m_dObjUB;
	double m_dObjLB;
	PriorityPOSet m_cUBLinkSolution;
	int m_iBestSolFeasible;
	void * m_pvExtraConstData;
	UnschedCores m_cUnschedCores;	
public:
	FocusRefinement();
	FocusRefinement(TaskSet & rcTaskSet);
	~FocusRefinement();	
	int FocusRefinementFast(int iDisplay, double dTimeout = 1e74);
	void setLogFile(char axCommand[]);
	TaskSetPriorityStruct getSolPA()	{ return m_cPriorityAssignmentSol; }
	StatisticSet GenerateStatisticFile(char axFileName[]);
	bool IsSchedulable();	
	virtual bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
	void setAlgorithm(int iAlgConfig)	{ m_iAlgConfig = iAlgConfig; }
	void setAlgorithm(enumAlgConfig iAlgConfig)	{ m_enumAlgConfig = iAlgConfig; }
	void setILPTimeout(double dTimeout)	{ m_dILPTimeout = dTimeout; }
	void setSubILPDisplay(int iDisplay)	{ m_iSubILPDisplay = iDisplay; }
	void setSubILPOptGap(double dOptGap)	{ m_dILPOptGap = dOptGap; }
	void setCorePerIter(int iCorePerIter)	{ m_iCorePerIter = iCorePerIter; }
	void setTerminateOnFeasible(int iConfig)	{ m_iTerminateOnFeasible = iConfig; }
	void setLB(double dLB)	{ m_dObjLB = dLB; }
	void WriteUnschedCoreToFile(char axFileName[]);
	void ReadUnschedCoreFromFile(char axFileName[]);
	void ClearFR();
protected:
	IloNumVar & getPriorityVariable(int iTaskA, int iTaskB, IloNumVarArray & rcPVars);
	void CreatePriortyVariable(IloNumVarArray & rcPVars);
	void GenPriorityConst(int i, int j, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray);
	void GenPriorityConst(int i, int j, int k, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray);
	virtual IloExpr ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO = NULL);	
	void ExtractRelevantPPO(IloExpr & rcExpr, PriorityPOSet & rcRelevantPPO);
	void GenObjConst(double dObjLB, double dObjUB, IloNumVarArray & rcPVars, IloRangeArray & rcConst);
	void GenGenUCConst(IloNumVarArray & rcPVars, UnschedCores & rcGenUC, IloRangeArray & rcRangeArray);
	virtual void GenExtraConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray, void * pvExtraData);	
	virtual double getObjUB();
	virtual void PostAccomplishWork(int iStatus)	{}

	void setSolverParam(IloCplex & rcSolver);
	void EnableSolverDisp(int iLevel, IloCplex & rcSolver);
	virtual void GenFixedPPOSet(PriorityPOSet & rcFixedSet);	
	void BuildModel(IloNumVarArray & rcPVars, PriorityPOSet & rcFixedSet, UnschedCores & rcGenUC,
		PriorityPOSet & cRelevantPO, IloRangeArray & rcRangeArray, IloObjective & cObjective);	
	virtual int SolveFRFast(int iDisplay, PriorityPOSet & rcFixedSet, UnschedCores & rcGenUC, double dObjLB, double dObjUB, double dTimeout = 1e74);
	void ComputeUnschedCoreForAllSol(PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
	virtual int FeasibleHook(UnschedCores & rcUnschedCores, PriorityPOSet & rcFixedSet, PriorityPOSet & rcPPOSolution);
	void AddMIPStart(PriorityPOSet & rcPPOSet, PriorityPOSet & cRelevantPO, IloNumVarArray & rcPVars, IloCplex & rcSolver);

	void ExtractResult(PriorityPOSet & rcLinkSolution, IloNumVarArray & rcPVars, PriorityPOSet cRelevantPO, IloCplex & rcSolver, int iSolIndex);
	void ExtractResult(IloNumVarArray & rcPVars, PriorityPOSet cRelevantPO, IloCplex & rcSolver, PriorityPOSet & rcFixedSet);
	bool DerivePriority(PriorityPOSet & rcPrioritySet, PriorityPOSet & rcFixedSet, TaskSetPriorityStruct & rcPriorityAssignment);
	bool VerifyResult(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);	
	bool VerifyPPOSet(UnschedCoreComputer::PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	virtual bool VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
		
	void PrintIterationStatus(int iIndex);
	void PrintIterationStatusSimple(IterationStatus & rcStatus);
	void PrintIterStatusToLog(int iIndex);
	void PrintObjFunctionToLog();
	void ComputeStatistic();	
	void UniquifyUnschedCore(UnschedCores & rcUnschedCores);
	string StatusToString(int iStatus);
	UnschedCores CombineCores(UnschedCores & rcPartA, UnschedCores & rcPartB);
public:
	template<typename T>
	void PrintCoreTimeDistributionToLog(T & rcUnschedCoreComputer)
	{
		if (m_stringLogFile.empty())	return;
		char axBuffer[512] = { 0 };
		ofstream ofstreamLogFile(m_stringLogFile.data(), ios::out | ios::app);
		assert(m_dequeIterationLogs.empty() == false);
		double dUCTotalTime = m_cFinalStatistic.dUCComputeTime;
		ofstreamLogFile << "----------------------------------------------" << endl;
		ofstreamLogFile << endl;
		sprintf_s(axBuffer, "Time on IsSchedulable Calls: %.2f (%.2f%%)", rcUnschedCoreComputer.getTimeOnIsSchedulableCalls(), rcUnschedCoreComputer.getTimeOnIsSchedulableCalls() / dUCTotalTime * 100.0);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Time on SchedTest Calls: %.2f (%.2f%%)", rcUnschedCoreComputer.getTimeOnSchedTestCalls(), rcUnschedCoreComputer.getTimeOnSchedTestCalls() / dUCTotalTime * 100.0);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Time on QuickSchedTest Calls: %.2f (%.2f%%)", rcUnschedCoreComputer.getTimeOnQuickSchedTestCalls(), rcUnschedCoreComputer.getTimeOnQuickSchedTestCalls() / dUCTotalTime * 100.0);				
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Time on QuickSchedTest Calls of Hit: %.2f (%.2f%%)", rcUnschedCoreComputer.getTimeOnQuickSchedTestCallsHit(), rcUnschedCoreComputer.getTimeOnQuickSchedTestCallsHit() / dUCTotalTime * 100.0);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Time on QuickSchedTest Calls of Miss: %.2f (%.2f%%)", rcUnschedCoreComputer.getTimeOnQuickSchedTestCallsMiss(), rcUnschedCoreComputer.getTimeOnQuickSchedTestCallsMiss() / dUCTotalTime * 100.0);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "QuickSchedTest Insertions: %d ", rcUnschedCoreComputer.m_iQuickSchedTestInsertions);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Time on Schedulable: %.2f", rcUnschedCoreComputer.m_dTimeOnSchedulable);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Time on Unschedulable: %.2f", rcUnschedCoreComputer.m_dTimeOnUnschedulable);
		ofstreamLogFile << axBuffer << endl;
		sprintf_s(axBuffer, "Sched Test Calls #: %d", rcUnschedCoreComputer.m_iSchedTestCall);
		ofstreamLogFile << axBuffer << endl;
		typedef deque<std::pair<unsigned int, unsigned int> > HitRateType;

		{
			map<int, int> mapAttemptOccurence;
			map<int, int> mapAttemptRatioOccurrence;
			double dAverageAttempt = 0;
			double dAverageRatio = 0;
			double dMaximumAttempt = 0;
			double dMaximumRatio = 0;
			double dSize = 0;

			ofstreamLogFile << "Subset Hit Search Ratio: " << endl;
			for (HitRateType::iterator iter = rcUnschedCoreComputer.m_dequeQuickSchedTestSubSetSearchHitNAttempts.begin();
				iter != rcUnschedCoreComputer.m_dequeQuickSchedTestSubSetSearchHitNAttempts.end(); iter++)
			{
				dAverageRatio += (double)iter->first / (double)iter->second * 100.0;
				dAverageAttempt += (double)iter->first;
				//	sprintf_s(axBuffer, "Attempts: %d, Size: %d, Ratio: %.2f%%", iter->first, iter->second, (double)iter->first / (double)iter->second * 100.0);
				//ofstreamLogFile << axBuffer << endl;
				dMaximumAttempt = max(dMaximumAttempt, (double)iter->first);
				dMaximumRatio = max(dMaximumRatio, (double)iter->first / (double)iter->second * 100.0);
				if (mapAttemptOccurence.count(iter->first) == 0)
					mapAttemptOccurence[iter->first] = 0;
				mapAttemptOccurence[iter->first] ++;

				int iRatioCeil = ceil((double)iter->first / (double)iter->second * 100.0);
				if (mapAttemptRatioOccurrence.count(iRatioCeil) == 0)
				{
					mapAttemptRatioOccurrence[iRatioCeil] = 0;
				}
				mapAttemptRatioOccurrence[iRatioCeil]++;

			}
			dSize = rcUnschedCoreComputer.m_dequeQuickSchedTestSubSetSearchHitNAttempts.size();
			ofstreamLogFile << "Average Attempt: " << dAverageAttempt / dSize << endl;
			ofstreamLogFile << "Average Ratio: " << dAverageRatio / dSize << endl;
			ofstreamLogFile << "Maximum Attempt: " << dMaximumAttempt << endl;
			ofstreamLogFile << "Maximum Ratio: " << dMaximumRatio << endl;
			double dAccumulate = 0;
			for (map < int, int >::iterator iter = mapAttemptOccurence.begin(); iter != mapAttemptOccurence.end(); iter++)
			{
				double dRatio = (double)iter->second / dSize * 100;
				dAccumulate += dRatio;
				sprintf_s(axBuffer, "Attempt Num: %d, Occurrence: %d, Ratio: %.2f%%, Accumulate:%.2f%%", iter->first, iter->second, dRatio, dAccumulate);
				ofstreamLogFile << axBuffer << endl;
			}
			dAccumulate = 0;
			for (map < int, int >::iterator iter = mapAttemptRatioOccurrence.begin(); iter != mapAttemptRatioOccurrence.end(); iter++)
			{
				double dRatio = (double)iter->second / dSize * 100;
				dAccumulate += dRatio;
				sprintf_s(axBuffer, "Attempt Ratio: %d%%~%d%%, Occurrence: %d, Ratio: %.2f%%, Accumulate:%.2f%%", iter->first - 1, iter->first, iter->second, dRatio, dAccumulate);
				ofstreamLogFile << axBuffer << endl;
			}
		}
		{
			map<int, int> mapAttemptOccurence;
			map<int, int> mapAttemptRatioOccurrence;
			double dAverageAttempt = 0;
			double dAverageRatio = 0;
			double dMaximumAttempt = 0;
			double dMaximumRatio = 0;
			double dSize = 0;

			ofstreamLogFile << "Supset Hit Search Ratio: " << endl;
			for (HitRateType::iterator iter = rcUnschedCoreComputer.m_dequeQuickSchedTestSupSetSearchHitNAttempts.begin();
				iter != rcUnschedCoreComputer.m_dequeQuickSchedTestSupSetSearchHitNAttempts.end(); iter++)
			{
				dAverageRatio += (double)iter->first / (double)iter->second * 100.0;
				dAverageAttempt += (double)iter->first;
				//	sprintf_s(axBuffer, "Attempts: %d, Size: %d, Ratio: %.2f%%", iter->first, iter->second, (double)iter->first / (double)iter->second * 100.0);
				//ofstreamLogFile << axBuffer << endl;
				dMaximumAttempt = max(dMaximumAttempt, (double)iter->first);
				dMaximumRatio = max(dMaximumRatio, (double)iter->first / (double)iter->second * 100.0);
				if (mapAttemptOccurence.count(iter->first) == 0)
					mapAttemptOccurence[iter->first] = 0;
				mapAttemptOccurence[iter->first] ++;

				int iRatioCeil = ceil((double)iter->first / (double)iter->second * 100.0);
				if (mapAttemptRatioOccurrence.count(iRatioCeil) == 0)
				{
					mapAttemptRatioOccurrence[iRatioCeil] = 0;
				}
				mapAttemptRatioOccurrence[iRatioCeil]++;

			}
			dSize = rcUnschedCoreComputer.m_dequeQuickSchedTestSupSetSearchHitNAttempts.size();
			ofstreamLogFile << "Average Attempt: " << dAverageAttempt / dSize << endl;
			ofstreamLogFile << "Average Ratio: " << dAverageRatio / dSize << endl;
			ofstreamLogFile << "Maximum Attempt: " << dMaximumAttempt << endl;
			ofstreamLogFile << "Maximum Ratio: " << dMaximumRatio << endl;
			double dAccumulate = 0;
			for (map < int, int >::iterator iter = mapAttemptOccurence.begin(); iter != mapAttemptOccurence.end(); iter++)
			{
				double dRatio = (double)iter->second / dSize * 100;
				dAccumulate += dRatio;
				sprintf_s(axBuffer, "Attempt Num: %d, Occurrence: %d, Ratio: %.2f%%, Accumulate:%.2f%%", iter->first, iter->second, dRatio, dAccumulate);
				ofstreamLogFile << axBuffer << endl;
			}
			dAccumulate = 0;
			for (map < int, int >::iterator iter = mapAttemptRatioOccurrence.begin(); iter != mapAttemptRatioOccurrence.end(); iter++)
			{
				double dRatio = (double)iter->second / dSize * 100;
				dAccumulate += dRatio;
				sprintf_s(axBuffer, "Attempt Ratio: %d%%~%d%%, Occurrence: %d, Ratio: %.2f%%, Accumulate:%.2f%%", iter->first - 1, iter->first, iter->second, dRatio, dAccumulate);
				ofstreamLogFile << axBuffer << endl;
			}
		}

		ofstreamLogFile.close();
	}
};

class LowestFeasiblePriorityAnalyzer : public FocusRefinement
{
public:
	int m_iTargetTask;
public:
	LowestFeasiblePriorityAnalyzer();
	LowestFeasiblePriorityAnalyzer(TaskSet & rcTaskSet);
protected:
	virtual IloExpr ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO = NULL);
public:
	void AnalyzeAll(vector<int> & rvectorResult, int iDisplay = 0);
};

