
#include "TaskSet.h"
#include "StatisticSet.h"
#include "Util.h"

void TestFocusRefinementAMCMax(char axDstFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { /*5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, 45, 50, 55, */60, 65, 70, 75, 80, 85, 90,
		95, 100, 105, 110, 115, 120, 125, 130, 135, 140, 145, 150 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCMax" };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, 2.0, aiTaskN[i], j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
				0.50, 0.95, 2.0, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 900 0 ", axSystemType, axFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_NSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementAMCRtb(char axDstFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90,
	95, 100, 105, 110, 115, 120, 125, 130, 135, 140, 145, 150};
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCRtb" };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{			
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, 2.0, aiTaskN[i], j + 1);			
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);			

			sprintf_s(axBuffer, "U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms", 
				0.50, 0.95, 2.0, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{						
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 900 0 ", axSystemType, axFileName);
				ExecuteSelf(axBuffer);
			}			
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();			
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_NSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementAMCMaxUSweep(char axDstFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90 };
	int iSystemSize = 70;
	int iN = sizeof(aiTaskN) / sizeof(double);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCMax" };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/U%.2f_N%d/TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
				aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 900 0", axSystemType, axFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
		}
		sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_USweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementAMCRtbUSweep(char axDstFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90 };
	int iSystemSize = 70;
	int iN = sizeof(aiTaskN) / sizeof(double);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCRtb" };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/U%.2f_N%d/TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
				 aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 900 0", axSystemType, axFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
		}
		sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_USweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementAMCRtbKSweep(char axDstFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double dUtil = 0.40;
	int aiK[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
	int iN = sizeof(aiK) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCRtb" };
	char axSuffix[512] = { 0 };	
	for (int i = 0; i < iN; i++)
	{		
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
		sprintf_s(axSuffix, "%sK%d", axSystemType, aiK[i]);
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/TaskSet%d.tskst", axDstFolder, j + 1);			
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "K=%d TaskSet%d.tskst Avg Time: %.2fms",
				aiK[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix, aiK[i]);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix, aiK[i]);
			if (!IsFileExist(axBuffer))
			{				
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted %d 900 0 -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s", 
				axSystemType, axFileName, aiK[i], axSuffix, axSuffix, axSuffix);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix, aiK[i]);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
//			if( cThisStatistic.getItem("Total UC Time").getValue() > 10000) cout <<  cThisStatistic.getItem("Total UC Time").getValue() << endl;
		}
//		cout << dUCCompTime << endl; char a; cin >> a;
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_KSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementAMCMaxKSweep(char axDstFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double dUtil = 0.40;
	int aiK[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
	int iN = sizeof(aiK) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCMax" };
	char axSuffix[512] = { 0 };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
		sprintf_s(axSuffix, "%sK%d", axSystemType, aiK[i]);
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/TaskSet%d.tskst", axDstFolder, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "K=%d TaskSet%d.tskst Avg Time: %.2fms",
				aiK[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix, aiK[i]);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix, aiK[i]);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted %d 900 0 -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
					axSystemType, axFileName, aiK[i], axSuffix, axSuffix, axSuffix);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix, aiK[i]);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_KSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementFSMRBFSO(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	/*int aiTaskN[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90,
		95, 100 };*/
	int aiTaskN[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };
	
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			sprintf_s(axFSMFileName, "%s/FSMNSweepRandomU/U%.2fto%.2f_N%d/TaskSet%d.tskst.fsm.txt", axFSMFolder, 0.40, 0.40, aiTaskN[i], j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2fto%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
				0.40, 0.40, aiTaskN[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{							
				continue;
			}			
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);			
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s", axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);		
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSM.txt");
#endif
	}
}

void TestFocusRefinementFSMRBFSOUSweep(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[1024] = { 0 };	
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95};
	int iSystemSize = 25;
	int iN = sizeof(aiTaskN) / sizeof(double);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };

	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/FSMUSweep/U%.2f_N%d/TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
			sprintf_s(axFSMFileName, "%s/FSMUSweep/U%.2f_N%d/TaskSet%d.tskst.fsm.txt", axFSMFolder, aiTaskN[i], iSystemSize, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "U%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
				aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSystemType);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted 5 1200 0 -FSMFile=%s", axSystemType, axFileName, axFSMFileName);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSystemType);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%.2f-Average Pre-Analysis Time(s)", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("FocusRefinement_FSM_USweep.txt");
#endif
	}
}

void TestFocusRefinementFSMRBFSOKSweep(char axDstFolder[], char axFSMFolder[])
{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFSMFileName[1024] = { 0 };
	char axFileName[512] = { 0 };
	double dUtil = 0.40;
	int aiK[] = { 1, 2, 3, 4, 5, 6 ,7 ,8 ,9 ,10};
	int iN = sizeof(aiK) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "FSMRBFSO" };
	char axSuffix[512] = { 0 };
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime = 0;
		double dILPTime = 0;
		double dUCCompTime = 0;
		int iAccepted = 0;
		double dNormalizedDelay = 0;
		int iSchedulableTaskSet = 0;
		int iTotalIteration = 0;
		double dPreanalysisTime = 0;
		sprintf_s(axSuffix, "%sK%d", axSystemType, aiK[i]);
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "%s/TaskSet%d.tskst", axDstFolder, aiK[i], dUtil, j + 1);
			sprintf_s(axFSMFileName, "%s/TaskSet%d.tskst.fsm.txt", axFSMFolder, aiK[i], dUtil, j + 1);
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "K= TaskSet%d.tskst Avg Time: %.2fms",
				aiK[i], j + 1, dTime / (j + 1));
			cout << "\r" << axBuffer << "       ";

#if ASSISTANT
			sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix);
			if (IsFileExist(axBuffer))
			{
				continue;
			}
#endif

			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "MCMILPPact.exe SimulinkFR %s %s weighted %d 1200 -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
					axSystemType, axFileName, aiK[i], axSuffix, axSuffix, axSuffix);
				ExecuteSelf(axBuffer);
			}
			sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
			cThisStatistic.ReadStatisticImage(axBuffer);

			string stringStatus = cThisStatistic.getItem("Status").getString();
			if (stringStatus.compare("Optimal") == 0)
			{
				iAccepted += 1;
				double dObjective = cThisStatistic.getItem("Objective").getValue();
				double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
				if (dObjective > 0)
				{
					dNormalizedDelay += dObjective / dWorstDelay;
				}
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Timeout") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Abort") == 0)
			{
				dNormalizedDelay += 1;
				iSchedulableTaskSet++;
			}
			else if (stringStatus.compare("Infeasible") == 0)
			{
				dNormalizedDelay += 1;
			}
			else
			{
				my_assert(0, "Unknown FR status");
			}
			dTime += cThisStatistic.getItem("Total Time").getValue();
			dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
			dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
			dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
			iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			dPreanalysisTime += cThisStatistic.getItem("FSM Pre-analysis Time").getValue();
		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
		sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Average Pre-Analysis Time(s)", 'A' + i, aiK[i]);
		cStatistic.setItem(axBuffer, (double)dPreanalysisTime / (double)iVolume);
#if ASSISTANT
#else
		sprintf_s(axBuffer, "FocusRefinement_%s_KSweep.txt", axSystemType);
		cStatistic.WriteStatisticText(axBuffer);
#endif
	}
}

void TestFocusRefinementAMCRtbNKSweep(char axDstFolder[])
{
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	int aiTaskN[] = { 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCMax" };
	char axSuffix[512] = { 0 };
	int iKMin = 2;
	int iKMax = 8;
	StatisticSet * pcStatistic = new StatisticSet[iKMax - iKMin + 1];
	for (int i = 0; i < iN; i++)
	{	
		for (int k = iKMin; k <= iKMax; k++)
		{
			StatisticSet & cStatistic = pcStatistic[k - iKMin];
			sprintf_s(axSuffix, "%sK%d", axSystemType, k);
			//start the test
			double dTime = 0;
			double dCPUTime = 0;
			double dILPTime = 0;
			double dUCCompTime = 0;
			int iAccepted = 0;
			double dNormalizedDelay = 0;
			int iSchedulableTaskSet = 0;
			int iTotalIteration = 0;
#if ASSISTANT
			for (int j = iVolume - 1; j >= 0; j--)
#else
			for (int j = 0; j < iVolume; j++)
#endif
			{
				StatisticSet cThisStatistic;
				sprintf_s(axFileName, "%s/U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, 2.0, aiTaskN[i], j + 1);
				TaskSet cTaskSet;
				cTaskSet.ReadImageFile(axFileName);

				sprintf_s(axBuffer, "K=%d U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
					k, 0.50, 0.95, 2.0, aiTaskN[i], j + 1, dTime / (j + 1));
				cout << "\r" << axBuffer << "       ";

#if ASSISTANT
				sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix);
				if (IsFileExist(axBuffer))
				{
					continue;
				}
#endif

				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				if (!IsFileExist(axBuffer))
				{
					sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted %d 900 0 -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
						axSystemType, axFileName, k, axSuffix, axSuffix, axSuffix);
					ExecuteSelf(axBuffer);
				}
				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				cThisStatistic.ReadStatisticImage(axBuffer);

				string stringStatus = cThisStatistic.getItem("Status").getString();
				if (stringStatus.compare("Optimal") == 0)
				{
					iAccepted += 1;
					double dObjective = cThisStatistic.getItem("Objective").getValue();
					double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
					if (dObjective > 0)
					{
						dNormalizedDelay += dObjective / dWorstDelay;
					}
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Timeout") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Abort") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Infeasible") == 0)
				{
					dNormalizedDelay += 1;
				}
				else
				{
					my_assert(0, "Unknown FR status");
				}
				dTime += cThisStatistic.getItem("Total Time").getValue();
				dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
				dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
				dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
				iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			}
			sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, iAccepted);
			sprintf_s(axBuffer, "%c.%d-Task Normalized Delay", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
			sprintf_s(axBuffer, "%c.%d-Task Average Run Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task ILP Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Task UC Computation Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%d-Average Iteration", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
			sprintf_s(axBuffer, "FocusRefinement_%s_NKSweep.txt", axSuffix);
			cStatistic.WriteStatisticText(axBuffer);
#endif
		}
	}
	delete [] pcStatistic;
}

void TestFocusRefinementAMCMaxUKSweep(char axDstFolder[])
{
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	double aiTaskN[] = { 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85,  0.90, 0.95 };
	int iSystemSize = 70;
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	const char axSystemType[] = { "AMCMax" };
	char axSuffix[512] = {};
	int iKMin = 2;
	int iKMax = 8;
	StatisticSet * pcStatistic = new StatisticSet[iKMax - iKMin + 1];
	for (int i = 0; i < iN; i++)
	{
		for (int k = iKMin; k <= iKMax; k++)
		{
			sprintf_s(axSuffix, "%sK%d", axSystemType, k);
			StatisticSet & cStatistic = pcStatistic[k - iKMin];
			//start the test
			double dTime = 0;
			double dCPUTime = 0;
			double dILPTime = 0;
			double dUCCompTime = 0;
			int iAccepted = 0;
			double dNormalizedDelay = 0;
			int iSchedulableTaskSet = 0;
			int iTotalIteration = 0;
#if ASSISTANT
			for (int j = iVolume - 1; j >= 0; j--)
#else
			for (int j = 0; j < iVolume; j++)
#endif
			{
				StatisticSet cThisStatistic;
				sprintf_s(axFileName, "%s/U%.2f_N%d/TaskSet%d.tskst", axDstFolder, aiTaskN[i], iSystemSize, j + 1);
				TaskSet cTaskSet;
				cTaskSet.ReadImageFile(axFileName);

				sprintf_s(axBuffer, "K=%d U%.2f_N%d/TaskSet%d.tskst Avg Time: %.2fms",
					k, aiTaskN[i], iSystemSize, j + 1, dTime / (j + 1));
				cout << "\r" << axBuffer << "       ";

#if ASSISTANT
				sprintf_s(axBuffer, "%s_FR_%s_Log.txt", axFileName, axSuffix);
				if (IsFileExist(axBuffer))
				{
					continue;
				}
#endif

				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				if (!IsFileExist(axBuffer))
				{
					sprintf_s(axBuffer, "./MCMILPPact.exe SimulinkFR %s %s weighted %d 900 0 -LogFileSuffix=%s -ResultFileSuffix=%s -UnschedCoreFileSuffix=%s",
						axSystemType, axFileName, k, axSuffix, axSuffix, axSuffix);
					ExecuteSelf(axBuffer);
				}
				sprintf_s(axBuffer, "%s_FR_%s_Result.rslt", axFileName, axSuffix);
				cThisStatistic.ReadStatisticImage(axBuffer);

				string stringStatus = cThisStatistic.getItem("Status").getString();
				if (stringStatus.compare("Optimal") == 0)
				{
					iAccepted += 1;
					double dObjective = cThisStatistic.getItem("Objective").getValue();
					double dWorstDelay = cThisStatistic.getItem("Objective UB").getValue();
					if (dObjective > 0)
					{
						dNormalizedDelay += dObjective / dWorstDelay;
					}
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Timeout") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Abort") == 0)
				{
					dNormalizedDelay += 1;
					iSchedulableTaskSet++;
				}
				else if (stringStatus.compare("Infeasible") == 0)
				{
					dNormalizedDelay += 1;
				}
				else
				{
					my_assert(0, "Unknown FR status");
				}
				dTime += cThisStatistic.getItem("Total Time").getValue();
				dCPUTime += cThisStatistic.getItem("Total CPU Time").getValue();
				dILPTime += cThisStatistic.getItem("Total ILP Time").getValue();
				dUCCompTime += cThisStatistic.getItem("Total UC Time").getValue();
				iTotalIteration += cThisStatistic.getItem("Iteration").getValue();
			}
			sprintf_s(axBuffer, "%c.%.2f-Task Accepted", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, iAccepted);
			sprintf_s(axBuffer, "%c.%.2f-Task Normalized Delay", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, dNormalizedDelay / (double)iVolume);
			sprintf_s(axBuffer, "%c.%.2f-Task Average Run Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Task Average CPU Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dCPUTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Task ILP Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dILPTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Task UC Computation Time", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)dUCCompTime / (double)iSchedulableTaskSet);
			sprintf_s(axBuffer, "%c.%.2f-Average Iteration", 'A' + i, aiTaskN[i]);
			cStatistic.setItem(axBuffer, (double)iTotalIteration / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
			sprintf_s(axBuffer, "FocusRefinement_%s_UKSweep.txt", axSuffix);
			cStatistic.WriteStatisticText(axBuffer);
#endif
		}
	}
	delete[] pcStatistic;
}

void TestMinimizeMemoryMILP(char axDstFolder[])

{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	//int aiTaskN[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70 };
	int aiTaskN[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40,/* 45, 50, 55, 60, 65, 70, 75, 90 */ };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime_MILP = 0;
		int iAccepted = 0;
		double dObjective = 0;
		int iSchedulableTaskSet = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst, AvgTime: %.2f", 0.50, 0.95, 2.0, aiTaskN[i], j + 1, dTime / 1e3 / (float)(j + 1.0));
			printf_s("\r%s    ", axFileName);
			sprintf_s(axFileName, "%s/U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, 2.0, aiTaskN[i], j + 1);
			//Skip the Unschedulable TaskSet						
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "%s_ILPRBF.rslt", axFileName);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, ".\MCMILPPact.exe MinimizeAUTOSTARMemory_ILPRBF -TaskSet=%s -Timeout=900 ", axFileName, 900.0);
				ExecuteSelf(axBuffer);
			}

			//read the result 
			sprintf_s(axBuffer, "%s_ILPRBF.rslt", axFileName);
			cThisStatistic.ReadStatisticImage(axBuffer);
			if ((strcmp(cThisStatistic.getItem("Status").getString(), "Infeasible") != 0))
			{
				iAccepted += 1;
				iSchedulableTaskSet++;
				dObjective += cThisStatistic.getItem("Objective").getValue();
			}
			else
			{

			}
			dTime += cThisStatistic.getItem("Wall Time").getValue();
			dCPUTime_MILP += cThisStatistic.getItem("CPU Time").getValue();

		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Average Objective", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dObjective / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average Wall Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime_MILP / (double)iSchedulableTaskSet);

#if ASSISTANT
#else
		cStatistic.WriteStatisticText("AUTOSTARMinimizeMemory_ILPRBF.txt");
#endif
	}
}

void TestMinimizeMemoryFR(char axDstFolder[])

{
	StatisticSet cStatistic;
	char axBuffer[1024] = { 0 };
	char axFileName[512] = { 0 };
	//int aiTaskN[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70 };
	int aiTaskN[] = { 5, 7, 9, 11, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	int iN = sizeof(aiTaskN) / sizeof(int);
	cout << endl << "Running test..." << endl;
	int iVolume = 1000;
	for (int i = 0; i < iN; i++)
	{
		//start the test
		double dTime = 0;
		double dCPUTime_MILP = 0;
		int iAccepted = 0;
		double dObjective = 0;
		int iSchedulableTaskSet = 0;
#if ASSISTANT
		for (int j = iVolume - 1; j >= 0; j--)
#else
		for (int j = 0; j < iVolume; j++)
#endif
		{
			StatisticSet cThisStatistic;
			sprintf_s(axFileName, "U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst, AvgTime: %.2f", 0.50, 0.95, 2.0, aiTaskN[i], j + 1, dTime / 1e3 / (float)(j + 1.0));
			printf_s("\r%s    ", axFileName);
			sprintf_s(axFileName, "%s/U%.2fto%.2f_CF%.2f_N%d/TaskSet%d.tskst", axDstFolder, 0.50, 0.95, 2.0, aiTaskN[i], j + 1);
			//Skip the Unschedulable TaskSet						
			TaskSet cTaskSet;
			cTaskSet.ReadImageFile(axFileName);

			sprintf_s(axBuffer, "%s_AUTOSTARMinMem_FR_Result.rslt", axFileName);
			if (!IsFileExist(axBuffer))
			{
				sprintf_s(axBuffer, "./MCMILPPact.exe MinimizeAUTOSTARMemory_FR -TaskSet=%s -Timeout=900 ", axFileName);
				ExecuteSelf(axBuffer);
			}

			//read the result 
			sprintf_s(axBuffer, "%s_AUTOSTARMinMem_FR_Result.rslt", axFileName);
			cThisStatistic.ReadStatisticImage(axBuffer);
			if ((strcmp(cThisStatistic.getItem("Status").getString(), "Infeasible") != 0))
			{
				iAccepted += 1;
				iSchedulableTaskSet++;
				dObjective += cThisStatistic.getItem("Objective").getValue();
			}
			else
			{

			}

			double dThisTime = cThisStatistic.getItem("Total UC Time").getValue() + cThisStatistic.getItem("Total ILP Time").getValue();
			dThisTime = min(900.0 * 1e3, dThisTime);
			dTime += dThisTime;
			dCPUTime_MILP += cThisStatistic.getItem("Total CPU Time").getValue();

		}
		sprintf_s(axBuffer, "%c.%d-Task Accepted", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, iAccepted);
		sprintf_s(axBuffer, "%c.%d-Task Average Objective", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, dObjective / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average Wall Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dTime / (double)iSchedulableTaskSet);
		sprintf_s(axBuffer, "%c.%d-Task Average CPU Time", 'A' + i, aiTaskN[i]);
		cStatistic.setItem(axBuffer, (double)dCPUTime_MILP / (double)iSchedulableTaskSet);
#if ASSISTANT
#else
		cStatistic.WriteStatisticText("AUTOSTARMinimizeMemory_FR.txt");
#endif
	}
}
