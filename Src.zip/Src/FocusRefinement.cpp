#include "stdafx.h"
#include "FocusRefinement.h"
#include <assert.h>
#include "StatisticSet.h"
#include "Timer.h"
#include "Util.h"
#include "ResponseTimeCalculator.h"
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#define min(a,b)            (((a) < (b)) ? (a) : (b))
FocusRefinement::FocusRefinement()
{	
}

FocusRefinement::FocusRefinement(TaskSet & rcTaskSet)	
{
	m_cPriorityAssignmentSol = TaskSetPriorityStruct(rcTaskSet);
	m_pcTaskSet = &rcTaskSet;
	m_enumAlgConfig = enumAlgConfig::Lazy;
	m_dILPTimeout = 1e74;
	m_iSubILPDisplay = 0;
	m_dILPOptGap = 100;
	m_iTerminateOnFeasible = 0;
	m_iCorePerIter = 5;
	m_dObjUB = 1e74;
	m_dObjLB = -1e74;
}

FocusRefinement::~FocusRefinement()
{
}

void FocusRefinement::CreatePriortyVariable(IloNumVarArray & rcPVars)
{
	const IloEnv & rcEnv = rcPVars.getEnv();	
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(m_pcTaskSet);
	char axBuffer[128] = { 0 };
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = 0; j < iTaskNum; j++)
		{
			//if (i == j)	continue;
			sprintf_s(axBuffer, "p(%d, %d)", i, j);
			rcPVars.add(IloNumVar(rcEnv, 0, 1.0, IloNumVar::Int, axBuffer));
		}
	}
}

IloNumVar & FocusRefinement::getPriorityVariable(int iTaskA, int iTaskB, IloNumVarArray & rcPVars)
{
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(iTaskA != iTaskB);
	int iAccessIndex = iTaskB + iTaskA * iTaskNum;
	assert(rcPVars.getSize() > iAccessIndex);
	return rcPVars[iAccessIndex];
}

void FocusRefinement::GenPriorityConst(int i, int j, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	rcRangeArray.add(IloRange(rcEnv, 0.0,
		getPriorityVariable(i, j, rcPVars) + getPriorityVariable(j, i, rcPVars) - 1.0,
		0.0));
	return;
}

void FocusRefinement::GenPriorityConst(int i, int j, int k, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	rcRangeArray.add(IloRange(rcEnv, -IloInfinity,
		getPriorityVariable(i, k, rcPVars) + getPriorityVariable(k, j, rcPVars) - 1.0 - getPriorityVariable(i, j, rcPVars),
		0.0));
}

void FocusRefinement::ExtractRelevantPPO(IloExpr & rcExpr, PriorityPOSet & rcRelevantPPO)
{
	IloExpr::LinearIterator rcLinIter = rcExpr.getLinearIterator();
	while (rcLinIter.ok())
	{
		int iHPTask = -1;
		int iLPTask = -1;
		sscanf_s(rcLinIter.getVar().getName(),"p(%d, %d)", &iHPTask, &iLPTask);
		rcRelevantPPO.insert(PriorityPOElement(iHPTask, iLPTask));
		++rcLinIter;
	}
}

void FocusRefinement::EnableSolverDisp(int iLevel, IloCplex & rcSolver)
{
	const IloEnv & rcEnv = rcSolver.getEnv();
	if (iLevel)
	{
		rcSolver.setParam(IloCplex::Param::MIP::Display, iLevel);
	}
	else
	{
		rcSolver.setParam(IloCplex::Param::MIP::Display, 0);
		rcSolver.setOut(rcEnv.getNullStream());
	}
}

void FocusRefinement::setSolverParam(IloCplex & rcSolver)
{
	rcSolver.setParam(IloCplex::Param::Emphasis::MIP, 0);
	rcSolver.setParam(IloCplex::Param::Simplex::Tolerances::Feasibility, 1e-9);
	rcSolver.setParam(IloCplex::Param::MIP::Tolerances::Integrality, 0);
	//rcSolver.setParam(IloCplex::Param::MIP::Cuts::Covers, 3);
	//rcSolver.setParam(IloCplex::Param::Emphasis::Memory, 1);	
	rcSolver.setParam(IloCplex::Param::MIP::OrderType, 1);

}

int FocusRefinement::SolveFRFast(int iDisplay, UnschedCoreComputer::PriorityPOSet & rcFixedSet, UnschedCoreComputer::UnschedCores & rcGenUC, double dObjLB, double dObjUB, double dTimeout /* = 1e74 */)
{
	try
	{
		IloEnv cSolveEnv;
		IloNumVarArray cPriorityVariables(cSolveEnv);
		CreatePriortyVariable(cPriorityVariables);
		IloRangeArray cConst(cSolveEnv);
		UnschedCoreComputer::PriorityPOSet cRelevantPO;
		IloObjective cObjective;

		BuildModel(cPriorityVariables, rcFixedSet, rcGenUC, cRelevantPO, cConst, cObjective);
		GenObjConst(dObjLB, dObjUB, cPriorityVariables, cConst);
		IloModel cModel(cSolveEnv);
		cModel.add(cConst);
		cModel.add(cObjective);
		IloCplex cSolver(cModel);

		EnableSolverDisp(iDisplay, cSolver);
		setSolverParam(cSolver);

		cSolver.setParam(IloCplex::Param::TimeLimit, dTimeout);

#if 0
		if (!m_cMIPStart.empty())
		{
			AddMIPStart(m_cMIPStart, cRelevantPO, cPriorityVariables, cSolver);
			m_cMIPStart.clear();
		}
#endif

		int iRetStatus = 0;

		m_cPPOSolution.clear();
		m_dequeSolutionPools.clear();
		m_iBestSolFeasible = 0;

		m_dSolveCPUTime = getCPUTimeStamp();
		m_dSolveWallTime = cSolver.getCplexTime();
		bool bStatus = cSolver.solve();
		m_dSolveCPUTime = getCPUTimeStamp() - m_dSolveCPUTime;
		m_dSolveWallTime = cSolver.getCplexTime() - m_dSolveWallTime;
		m_cCplexStatus = cSolver.getCplexStatus();
		if (bStatus)
		{
			ExtractResult(cPriorityVariables, cRelevantPO, cSolver, rcFixedSet);			
			m_bIsValidSolution = true;
		}
		m_bIsValidSolution = false;
		if ((cSolver.getCplexStatus() == cSolver.Optimal) || (cSolver.getCplexStatus() == cSolver.OptimalTol))
			iRetStatus = 1;
		else if (cSolver.getCplexStatus() == cSolver.AbortTimeLim)
			iRetStatus = -1;
		else if (cSolver.getCplexStatus() == cSolver.AbortUser)
			iRetStatus = -2;
		else if (cSolver.getCplexStatus() == cSolver.Infeasible)
			iRetStatus = 0;
		else
			iRetStatus = 0;
		cPriorityVariables.end();
		cSolveEnv.end();
		return iRetStatus;
	}
	catch (IloException& e) {
		cerr << "Concert exception caught: " << e << endl;
		return 0;
	}

}

void FocusRefinement::BuildModel(IloNumVarArray & rcPVars, UnschedCoreComputer::PriorityPOSet & rcFixedSet,
	UnschedCoreComputer::UnschedCores & rcGenUC, UnschedCoreComputer::PriorityPOSet & cRelevantPO, IloRangeArray & rcRangeArray, IloObjective & cObjective)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);

	//UC Constraint;
	try
	{
		const IloEnv & rcEnv = rcRangeArray.getEnv();
		//Objective

		IloExpr cObjExpression;
		cObjExpression = ObjExpr(rcPVars, &cRelevantPO);
		cObjective = IloObjective(rcEnv, cObjExpression, IloObjective::Minimize, "Minimize Delay");

		for (UnschedCoreComputer::UnschedCores::iterator iterCores = rcGenUC.begin();
			iterCores != rcGenUC.end(); iterCores++)
		{
			IloExpr cExpr(rcEnv);
			for (UnschedCoreComputer::PriorityPOSet::iterator iterPOEle = iterCores->begin(); iterPOEle != iterCores->end(); iterPOEle++)
			{
				int iHPTask = iterPOEle->m_iHPTask;
				int iLPTask = iterPOEle->m_iLPTask;
				cRelevantPO.insert(UnschedCoreComputer::PriorityPOElement(iHPTask, iLPTask));
				cExpr += getPriorityVariable(iHPTask, iLPTask, rcPVars);

			}
			rcRangeArray.add(IloRange(rcEnv, 0.0, cExpr, iterCores->size() - 1.0));
			cExpr.end();
		}

		//Predet PO Constraints;
		for (UnschedCoreComputer::PriorityPOSet::iterator iter = rcFixedSet.begin();
			iter != rcFixedSet.end(); iter++)
		{
			int iHPTask = iter->m_iHPTask;
			int iLPTask = iter->m_iLPTask;
			cRelevantPO.insert(UnschedCoreComputer::PriorityPOElement(iHPTask, iLPTask));
			rcRangeArray.add(IloRange(rcEnv, 1.0, getPriorityVariable(iHPTask, iLPTask, rcPVars), 1.0));
		}

		//Transitive Closure;
		GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
		for (int i = 0; i < iTaskNum; i++)
		{
			for (int j = 0; j < iTaskNum; j++)
			{
				if (i == j)	continue;
				if ((cRelevantPO.count(UnschedCoreComputer::PriorityPOElement(i, j)) == 1) &&
					(cRelevantPO.count(UnschedCoreComputer::PriorityPOElement(j, i)) == 1))
				{
					rcRangeArray.add(IloRange(rcEnv, 0.0, getPriorityVariable(i, j, rcPVars) + getPriorityVariable(j, i, rcPVars) - 1.0, 0.0));
				}

				for (int k = 0; k < iTaskNum; k++)
				{
					if ((k == i) || (k == j))	continue;

					if ((cRelevantPO.count(UnschedCoreComputer::PriorityPOElement(i, k)) == 1) &&
						(cRelevantPO.count(UnschedCoreComputer::PriorityPOElement(k, j)) == 1) &&
						(cRelevantPO.count(UnschedCoreComputer::PriorityPOElement(i, j)) == 1))
					{
						rcRangeArray.add(IloRange(rcEnv, 0.0,
							getPriorityVariable(i, j, rcPVars) - getPriorityVariable(i, k, rcPVars) - getPriorityVariable(k, j, rcPVars) + 1.0,
							IloInfinity));
					}
				}
			}
		}

		GenExtraConst(rcPVars, rcRangeArray, m_pvExtraConstData);
	}
	catch (IloException& e) {
		cerr << "Concert exception caught: " << e << endl;
	}
}

void FocusRefinement::ExtractResult(PriorityPOSet & rcLinkSolution,
	IloNumVarArray & rcPVars, PriorityPOSet cRelevantPO, IloCplex & rcSolver, int iSolIndex)
{
	rcLinkSolution.clear();
	for (PriorityPOSet::iterator iter = cRelevantPO.begin(); iter != cRelevantPO.end(); iter++)
	{
		int iHPTask = iter->m_iHPTask;
		int iLPTask = iter->m_iLPTask;		
		int iSol = 0;
		try
		{
			if (iSolIndex != -1)
				iSol = round(rcSolver.getValue(getPriorityVariable(iHPTask, iLPTask, rcPVars), iSolIndex));
			else
				iSol = round(rcSolver.getValue(getPriorityVariable(iHPTask, iLPTask, rcPVars)));
		}
		catch (IloException& e) {
			cerr << "Concert exception caught: " << e << endl;
			cerr << getPriorityVariable(iHPTask, iLPTask, rcPVars).getName() << endl;
			while (1);
		}

		if (iSol == 1)
		{
			if (rcLinkSolution.count({ iHPTask, iLPTask }) == 0)
				rcLinkSolution.insert(UnschedCoreComputer::PriorityPOElement(iHPTask, iLPTask));
		}
		else
		{
			if (rcLinkSolution.count({ iLPTask, iHPTask }) == 0)
				rcLinkSolution.insert(UnschedCoreComputer::PriorityPOElement(iLPTask, iHPTask));
		}
	}
}

void FocusRefinement::ExtractResult(IloNumVarArray & rcPVars, UnschedCoreComputer::PriorityPOSet cRelevantPO, IloCplex & rcSolver, PriorityPOSet & rcFixedSet)
{
	m_dequeSolutionPools.clear();
	m_cPPOSolution.clear();
	int iNSol = rcSolver.getSolnPoolNsolns();
	for (int i = 0; i < iNSol; i++)
	{
		PriorityPOSet cLinkSolution;
		ExtractResult(cLinkSolution, rcPVars, cRelevantPO, rcSolver, i);
		double m_dThisObj = rcSolver.getObjValue(i);
		m_dequeSolutionPools.push_back({ m_dThisObj, cLinkSolution });
		if (m_dThisObj < m_dObjUB)
		{
			TaskSetPriorityStruct cDummy(*m_pcTaskSet);
			PriorityPOSet cCombinedSet = cLinkSolution + rcFixedSet;
			if (IsSchedulable(cCombinedSet, cDummy))
			{
				if (i == 0)
				{
					m_iBestSolFeasible = 1;
				}
				m_dObjUB = m_dThisObj;
				m_cUBLinkSolution = cLinkSolution;
			}
		}
		else
			break;
	}

	m_dObjective = rcSolver.getObjValue();
	//cout << "Status: " << ((rcSolver.getCplexStatus() == rcSolver.Optimal)) << endl;
	//cout << rcSolver.getCplexStatus() << endl;
	if ((rcSolver.getCplexStatus() == rcSolver.Optimal) || (rcSolver.getCplexStatus() == rcSolver.OptimalTol))
	{
		if (m_dObjective > m_dObjLB)
			m_dObjLB = m_dObjective;
		if ((abs(m_dObjUB - m_dObjective) < 1e-5))
		{
			m_cPPOSolution = m_cUBLinkSolution;
			m_iBestSolFeasible = 1;
			return;
		}
	}

	if (iNSol == 0)
	{
		cout << "No solution? Is it a linear programming problem?" << endl;
		assert(0);
	}
	else
	{
		assert(!m_dequeSolutionPools.empty());
		m_cPPOSolution = m_dequeSolutionPools.front().second;
	}
	TaskSetPriorityStruct cDummy(*m_pcTaskSet);
	PriorityPOSet cTotalSet = m_cPPOSolution + rcFixedSet;
	if ((m_iBestSolFeasible == 0 && IsSchedulable(cTotalSet, cDummy)))
	{
		m_iBestSolFeasible = 1;
	}

}

void FocusRefinement::GenFixedPPOSet(PriorityPOSet & rcFixedSet)
{
	
}

int FocusRefinement::FocusRefinementFast(int iDisplay, double dTimeout /* = 1e74 */)
{
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);	
	char axBuffer[256] = { 0 };		
	m_dObjUB = getObjUB();
	m_dObjLB = -1e74;	
	ClearFR();
	m_iStartClock = clock();
	double dStartTimeSecond = getWallTimeSecond();
	int iStatus = 0;		
	//Test if schedulable first
	if (!IsSchedulable())
	{
		IterationStatus tagStatus;
		tagStatus.dTime = (double)(clock() - m_iStartClock) / (double)CLOCKS_PER_SEC;
		tagStatus.iStatus = ITERSTATUS_INFEASIBLE;
		tagStatus.enumState = Infeasible;
		m_dequeIterationLogs.push_back(tagStatus);
		if (iDisplay)	cout << "Infeasible" << endl;
		PrintIterStatusToLog(m_dequeIterationLogs.size() - 1);
		ComputeStatistic();
		return 0;
	}		
	if (iDisplay)
		cout << "system schedulable. start optimization" << endl;
	//Fun thing begins			
	UnschedCoreComputer::PriorityPOSet cFixedSet;
	GenFixedPPOSet(cFixedSet);
	Timer cTimer;
	cTimer.Start();

	double dLastObjective = -1e74;
	int iIterationCount = 0;
	double dUCComputeTime = 0;
	bool bCanExit = false;
	double dThisILPTimeout = m_dILPTimeout;
	int iLastCoreSize = 0;
	PrintObjFunctionToLog();	
	while (1)
	{
		bCanExit = false;		
		iStatus = SolveFRFast(m_iSubILPDisplay, cFixedSet, m_cUnschedCores, m_dObjLB, 1e74, dThisILPTimeout);		
		dLastObjective = m_dObjective;
		//Test Schedulability anc Compute Unschedcore
		//Timer cUCTImer;
		//cUCTImer.Start();
		clock_t iClockStart = clock();
		//time_t iTimeStart = time(NULL);
		UnschedCoreComputer::UnschedCores cThisCores;		
		//PrintSetContent(m_cPPOSolution.getSetContent());
		if (iDisplay == 2)
			cout << "computing unsched-cores..." << endl;		
		switch (m_enumAlgConfig)
		{
		case enumAlgConfig::Lazy:
			ComputeUnschedCores(m_cPPOSolution, cFixedSet, cThisCores, m_iCorePerIter);
			break;
		case enumAlgConfig::Eager:
			ComputeUnschedCoreForAllSol(cFixedSet, cThisCores, m_iCorePerIter);
			break;
		default:
			cout << "Unknown Algorithm Configuration" << endl;
			assert(0);
			break;
		}
		if (iDisplay == 2)
			cout << "marshaling statistic..." << endl;
		for (UnschedCoreComputer::UnschedCores::iterator iter = cThisCores.begin();
			iter != cThisCores.end(); iter++)
		{
			m_cUnschedCores.push_back(*iter);
		}

		//Update Iteration Status Statistic
		double dUCComputeTime = (double)(clock() - iClockStart) / (double)CLOCKS_PER_SEC; 
		//iTimeStart = time(NULL) - iTimeStart;
		//dUCComputeTime = iTimeStart;
		//cUCTImer.Stop();
		//double dUCComputeTimeByTimer = cUCTImer.getElapsedTime_ms() / 1000.0;
		//dUCComputeTime = dUCComputeTimeByTimer;
		//double dTimeByNow = (double)(clock() - m_iStartClock) / (double)CLOCKS_PER_SEC;
		double dTimeByNow = getWallTimeSecond() - dStartTimeSecond;
		IterationStatus tagStatus;
		iIterationCount++;
		tagStatus.cLinkConfigSol = m_cPPOSolution;
		tagStatus.iIterationN = iIterationCount;
		tagStatus.dObjective = m_dObjective;
		tagStatus.dBestFeasible = m_dObjUB;
		tagStatus.dObjLB = m_dObjLB;
		tagStatus.iTotalCores = m_cUnschedCores.size();
		tagStatus.cThisUnschedCores = cThisCores;
		tagStatus.dTime = dTimeByNow;
		tagStatus.dILPTime = m_dSolveWallTime;
		tagStatus.dUCComputeTime = dUCComputeTime;
		cTimer.Stop();
		tagStatus.dCPUTime = cTimer.getElapsedTime_ms();
		tagStatus.iStatus = ITERSTATUS_SEARCH;
		tagStatus.enumState = Search;
		m_dequeIterationLogs.push_back(tagStatus);
		//Handle the result					
		if (m_iBestSolFeasible == 1)
		{
			//A feasible solution found
			int iHookStatus = FeasibleHook(m_cUnschedCores, cFixedSet, m_cPPOSolution);
			if (iHookStatus == 1)
			{
				TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
				assert(DerivePriority(m_cPPOSolution, cFixedSet, cPriorityAssignment));
				VerifyResult(m_dObjective, m_cPPOSolution, cPriorityAssignment);
				m_cPriorityAssignmentSol = cPriorityAssignment;

				if ((m_cCplexStatus == IloCplex().Optimal) || (m_cCplexStatus == IloCplex().OptimalTol))
				{
					m_dequeIterationLogs.back().iStatus = ITERSTATUS_OPTIMAL;
					m_dequeIterationLogs.back().enumState = Optimal;
					bCanExit = true;
				}
				else
				{
					m_dequeIterationLogs.back().iStatus = ITERSTATUS_FEASIBLE;
					m_dequeIterationLogs.back().enumState = Feasible;
					if (m_iTerminateOnFeasible)
					{
						bCanExit = true;
					}
					else
					{
						dThisILPTimeout *= 10;
					}
				}
			}	
		}
		else if (m_dequeSolutionPools.empty())
		{
			//Cannot find any solution due to time limit
			dThisILPTimeout = dThisILPTimeout * 10;
		}
		else if (dTimeByNow > dTimeout)
		{
			m_dequeIterationLogs.back().iStatus = ITERSTATUS_TIMEOUT;
			m_dequeIterationLogs.back().enumState = Timeout;
			bCanExit = true;
		}
		else
		{
			dThisILPTimeout = m_dILPTimeout;
		}

		//Display Status
		if (iDisplay)
		{
			PrintIterationStatusSimple(m_dequeIterationLogs.back());
			//system("pause");
		}

		PrintIterStatusToLog(m_dequeIterationLogs.size() - 1);
		if (bCanExit)
		{
			if (iDisplay) cout << endl;
			break;
		}

	
	}

	ComputeStatistic();
	PostAccomplishWork(iStatus);
	return iStatus;
	//WriteModelFile("FinalModel.sav", cGeneralUC);
}

int FocusRefinement::FeasibleHook(UnschedCores & rcUnschedCores, PriorityPOSet & rcFixedSet, PriorityPOSet & rcPPOSolution)
{
	return 1;
}

bool FocusRefinement::VerifyResult(double dObjective, UnschedCoreComputer::PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{		
	VerifyPPOSet(rcPOSet, rcPriorityAssignment);
	VerifyOthers(dObjective, rcPOSet, rcPriorityAssignment);
	return true;
}

bool FocusRefinement::VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	return true;
}

bool FocusRefinement::VerifyPPOSet(UnschedCoreComputer::PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	//Verify PO Set
	for (UnschedCoreComputer::PriorityPOSet::iterator iter = rcPOSet.begin(); iter != rcPOSet.end(); iter++)
	{
		int iHP = iter->m_iHPTask;
		int iLP = iter->m_iLPTask;
		assert(rcPriorityAssignment.getPriorityByTask(iHP) < rcPriorityAssignment.getPriorityByTask(iLP));
	}
	return true;
}

void FocusRefinement::GenGenUCConst(IloNumVarArray & rcPVars, UnschedCores & rcGenUC, IloRangeArray & rcRangeArray)
{
	const IloEnv & rcEnv = rcRangeArray.getEnv();
	for (UnschedCoreComputer::UnschedCores::iterator iterCores = rcGenUC.begin();
		iterCores != rcGenUC.end(); iterCores++)
	{
		IloExpr cExpr(rcEnv);
		for (UnschedCoreComputer::PriorityPOSet::iterator iterPOEle = iterCores->begin(); iterPOEle != iterCores->end(); iterPOEle++)
		{
			int iHPTask = iterPOEle->m_iHPTask;
			int iLPTask = iterPOEle->m_iLPTask;
			assert(iHPTask != iLPTask);
			cExpr += getPriorityVariable(iHPTask, iLPTask, rcPVars);
		}
		rcRangeArray.add(IloRange(rcEnv, 0.0, cExpr, iterCores->size() - 1.0));
		cExpr.end();
	}
}

void FocusRefinement::GenExtraConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray, void * pvExtraData)
{

}

void FocusRefinement::GenObjConst(double dObjLB, double dObjUB, IloNumVarArray & rcPVars, IloRangeArray & rcConst)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	rcConst.add(IloRange(rcEnv, dObjLB, ObjExpr(rcPVars), dObjUB));
}

IloExpr FocusRefinement::ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cObjExpression(rcEnv);	
	cout << "FR base class don't assume any system, don't directly use it." << endl;
	while (1);
	return cObjExpression;
}

bool FocusRefinement::DerivePriority(UnschedCoreComputer::PriorityPOSet & rcPrioritySet, UnschedCoreComputer::PriorityPOSet & rcFixedSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	PriorityPOSet cCombinedSet;
	cCombinedSet.insert(rcPrioritySet.begin(), rcPrioritySet.end());
	cCombinedSet.insert(rcFixedSet.begin(), rcFixedSet.end());
	return IsSchedulable(cCombinedSet, rcPriorityAssignment);
}

void FocusRefinement::PrintIterationStatus(int iIndex)
{
	assert(m_dequeIterationLogs.size() > iIndex);
	IterationStatus & rtagStatus = m_dequeIterationLogs[iIndex];
	cout << "----------------------------------------------" << endl;
	cout << "Iteration " << rtagStatus.iIterationN << endl;
	cout << "Objective: " << rtagStatus.dObjective << endl;
	if (iIndex > 0)
	{
		double dConvergeRate = (rtagStatus.dObjective - m_dequeIterationLogs[iIndex - 1].dObjective) / m_dequeIterationLogs[iIndex - 1].dObjective;
		dConvergeRate = min(dConvergeRate, 1.0);
		printf_s("Converge Rate: %.2f%%\n", dConvergeRate * 100);
	}

	cout << "Unsched-Cores: " << rtagStatus.iTotalCores << endl;
	int iSize = rtagStatus.cThisUnschedCores.size();
	for (int i = 0; i < iSize; i++)
	{
		cout << "Core: ";
		PrintSetContent(rtagStatus.cThisUnschedCores[i].getSetContent());
	}
}

void FocusRefinement::PrintIterStatusToLog(int iIndex)
{
	assert(m_dequeIterationLogs.size() > iIndex);
	if (m_stringLogFile.empty())	return;
	char axBuffer[128] = { 0 };
	ofstream ofstreamLogFile(m_stringLogFile.data(), ios::out | ios::app);

	IterationStatus & rtagStatus = m_dequeIterationLogs[iIndex];
	ofstreamLogFile << "----------------------------------------------" << endl;
	ofstreamLogFile << "Iteration " << rtagStatus.iIterationN << endl;
	ofstreamLogFile << "Objective: " << rtagStatus.dObjective << endl;
	ofstreamLogFile << "Best Feasible: " << rtagStatus.dBestFeasible << endl;
	ofstreamLogFile << "Objective LB: " << rtagStatus.dObjLB << endl;
	ofstreamLogFile << "Time: " << rtagStatus.dTime << endl;
	ofstreamLogFile << "UC Compute Time: " << rtagStatus.dUCComputeTime << endl;
	ofstreamLogFile << "ILP Time: " << rtagStatus.dILPTime << endl;
	if (iIndex > 0)
	{
		double dConvergeRate = (rtagStatus.dObjective - m_dequeIterationLogs[iIndex - 1].dObjective) / m_dequeIterationLogs[iIndex - 1].dObjective;
		dConvergeRate = min(dConvergeRate, 1.0);
		sprintf_s(axBuffer, "Converge Rate: %.2f%%\n", dConvergeRate * 100);
		ofstreamLogFile << axBuffer;
	}

	ofstreamLogFile << "PPO Configuration: ";
	for (PriorityPOSet::iterator iter = rtagStatus.cLinkConfigSol.begin();
		iter != rtagStatus.cLinkConfigSol.end(); iter++)
	{
		ofstreamLogFile << *iter << ", ";
	}
	ofstreamLogFile << endl;

	ofstreamLogFile << "Unsched-Cores: " << rtagStatus.iTotalCores << endl;
	int iSize = rtagStatus.cThisUnschedCores.size();
	for (int i = 0; i < iSize; i++)
	{
		ofstreamLogFile << "Core: ";
		for (PriorityPOSet::iterator iter = rtagStatus.cThisUnschedCores[i].begin();
			iter != rtagStatus.cThisUnschedCores[i].end(); iter++)
		{
			sprintf_s(axBuffer, "(%d, %d), ", iter->m_iHPTask, iter->m_iLPTask);
			ofstreamLogFile << axBuffer;
		}
		ofstreamLogFile << endl;
	}

	ofstreamLogFile << "Status: ";
	switch (rtagStatus.iStatus)
	{
	case ITERSTATUS_SEARCH:
		ofstreamLogFile << "Searching";
		break;
	case ITERSTATUS_ABORT:
		ofstreamLogFile << "Abort";
		break;
	case ITERSTATUS_OPTIMAL:
		ofstreamLogFile << "Optimal";
		break;
	case ITERSTATUS_INFEASIBLE:
		ofstreamLogFile << "Infeasible";
		break;
	case ITERSTATUS_TIMEOUT:
		ofstreamLogFile << "Timeout";
		break;
	case ITERSTATUS_FEASIBLE:
		ofstreamLogFile << "Feasible";
		break;
	default:
		my_assert(0, "Unknown Status");
		break;
	}
	ofstreamLogFile << endl;

	ofstreamLogFile.close();
}

void FocusRefinement::PrintObjFunctionToLog()
{
	if (m_stringLogFile.empty())	return;
	char axBuffer[128] = { 0 };
	ofstream ofstreamLogFile(m_stringLogFile.data(), ios::out | ios::app);

	ofstreamLogFile << "Objective Function: " << endl;

	IloEnv cTempEnv;
	IloNumVarArray cPVars(cTempEnv);
	CreatePriortyVariable(cPVars);
	PriorityPOSet cObjRelevantPPO;
	IloObjective cObjective = IloMinimize(cTempEnv, ObjExpr(cPVars, &cObjRelevantPPO));

	ofstreamLogFile << cObjective << endl;
	ofstreamLogFile << "Number of Objective Relevant PPO(s): " << cObjRelevantPPO.size() << endl;
	ofstreamLogFile.close();
	cTempEnv.end();
}

void FocusRefinement::setLogFile(char axCommand[])
{
	m_stringLogFile = string(axCommand);
	if (!m_stringLogFile.empty())
	{
		ofstream ofstreamLogFile(m_stringLogFile.data(), ios::out);
		ofstreamLogFile.close();
	}
}

int FocusRefinement::ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{
	cout << "FR base class don't assume any system, don't directly use it." << endl;
	while (1);
	return 0;
}

void FocusRefinement::ComputeUnschedCoreForAllSol(PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit)
{
	int iSize = min(m_dequeSolutionPools.size(), 100);
	PPOSetSort cCoreSort;
	for (int i = 0; i < iSize; i++)
	{
		PriorityPOSet & rcLinkSol = m_dequeSolutionPools[i].second;
		UnschedCores cThisCores;
		ComputeUnschedCores(rcLinkSol, rcFixedSet, cThisCores, iLimit);
		int iCoreSize = cThisCores.size();
		for (int j = 0; j < iCoreSize; j++)
		{
#if 1
			rcUnschedCores.push_back(cThisCores[j]);
#else
			cCoreSort.insert(cThisCores[j]);
#endif
		}
	}

	for (PPOSetSort::iterator iter = cCoreSort.begin(); iter != cCoreSort.end(); iter++)
	{
		rcUnschedCores.push_back(*iter);
	}


	//Adjust the solution	
	//m_cAdjustedSolution = m_cLinkDetSolution;
	//AdjustSolutionByCores(m_cAdjustedSolution, rcUnschedCores);
	//system("pause");
}

void FocusRefinement::ComputeStatistic()
{
	UniquifyUnschedCore(m_cUnschedCores);
	IterationStatus & rcLast = m_dequeIterationLogs.back();
	m_cFinalStatistic.dObjective = rcLast.dObjective;
	m_cFinalStatistic.iIterationN = rcLast.iIterationN;
	m_cFinalStatistic.cLinkConfigSol = rcLast.cLinkConfigSol;
	m_cFinalStatistic.iTotalCores = m_cUnschedCores.size();
	m_cFinalStatistic.dTime = rcLast.dTime * 1000;
	m_cFinalStatistic.dCPUTime = rcLast.dCPUTime * 1000;
	m_cFinalStatistic.iStatus = rcLast.iStatus;
	m_cFinalStatistic.dBestFeasible = rcLast.dBestFeasible;
	m_cFinalStatistic.dILPTime = 0;
	m_cFinalStatistic.dUCComputeTime = 0;
	for (deque<IterationStatus>::iterator iter = m_dequeIterationLogs.begin();
		iter != m_dequeIterationLogs.end(); iter++)
	{
		m_cFinalStatistic.dILPTime += iter->dILPTime;
		m_cFinalStatistic.dUCComputeTime += iter->dUCComputeTime;
	}
	m_cFinalStatistic.dILPTime *= 1000;
	m_cFinalStatistic.dUCComputeTime *= 1000;
}

StatisticSet FocusRefinement::GenerateStatisticFile(char axFileName[])
{
	StatisticSet cStatistic;
	cStatistic.setItem("Total Time", m_cFinalStatistic.dTime);
	cStatistic.setItem("Total CPU Time", m_cFinalStatistic.dCPUTime);
	cStatistic.setItem("Iteration", m_cFinalStatistic.iIterationN);
	cStatistic.setItem("Cores", m_cFinalStatistic.iTotalCores);
	cStatistic.setItem("Total UC Time", m_cFinalStatistic.dUCComputeTime);
	cStatistic.setItem("Total ILP Time", m_cFinalStatistic.dILPTime);
	cStatistic.setItem("Objective", m_dObjective);
	cStatistic.setItem("Best Feasible", m_cFinalStatistic.dBestFeasible);
	//cStatistic.setItem("Objective UB", m_pcTaskSet->getWorstDelay());
	cStatistic.setItem("Objective UB", getObjUB());

	switch (m_cFinalStatistic.iStatus)
	{
	case ITERSTATUS_SEARCH:
		cStatistic.setItem("Status", "Searching");
		break;
	case ITERSTATUS_ABORT:
		cStatistic.setItem("Status", "Abort");
		break;
	case ITERSTATUS_OPTIMAL:
		cStatistic.setItem("Status", "Optimal");
		break;
	case ITERSTATUS_INFEASIBLE:
		cStatistic.setItem("Status", "Infeasible");
		break;
	case ITERSTATUS_TIMEOUT:
		cStatistic.setItem("Status", "Timeout");
		break;
	default:
		my_assert(0, "Unknown Status");
		break;
	}

	//cStatistic.setItem("", m_cFinalStatistic);
	if(strlen(axFileName) == 0)	return cStatistic;
	char axBuffer[256] = { 0 };
	sprintf_s(axBuffer, "%s.txt", axFileName);
	cStatistic.WriteStatisticText(axBuffer);

	sprintf_s(axBuffer, "%s.rslt", axFileName);
	cStatistic.WriteStatisticImage(axBuffer);

	return cStatistic;
}

bool FocusRefinement::IsSchedulable()
{
	//TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	//return m_cUnschedCoreComputer.IsSchedulable(cPriorityAssignment);
	PriorityPOSet cDummy;
	TaskSetPriorityStruct cPriorityAssignment(*m_pcTaskSet);
	return IsSchedulable(cDummy, cPriorityAssignment);	
}

bool FocusRefinement::IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment)
{
	cout << "FR base class don't assume any system, don't directly use it." << endl;
	while (1);
	return true;
	//return m_cUnschedCoreComputer.IsSchedulable(rcPriorityAssignment, rcPPOSet);
}

void FocusRefinement::UniquifyUnschedCore(UnschedCores & rcUnschedCores)
{
	PPOSetSort cPPOSetSort;
	for (UnschedCores::iterator iter = rcUnschedCores.begin(); iter != rcUnschedCores.end(); iter++)
	{
		cPPOSetSort.insert(*iter);
	}
	rcUnschedCores.clear();
	for (PPOSetSort::iterator iter = cPPOSetSort.begin(); iter != cPPOSetSort.end(); iter++)
	{
		rcUnschedCores.push_back(*iter);
	}
}

string FocusRefinement::StatusToString(int iStatus)
{
	switch (iStatus)
	{
	case ITERSTATUS_SEARCH:
		return string("Searching");
		break;
	case ITERSTATUS_ABORT:
		return string("Abort");
		break;
	case ITERSTATUS_OPTIMAL:
		return string("Optimal");
		break;
	case ITERSTATUS_INFEASIBLE:
		return string("Unschedulable");
		break;
	case ITERSTATUS_TIMEOUT:
		return string("Timeout");
		break;
	case ITERSTATUS_MA:
		return string("Mixed Approximation");
	case ITERSTATUS_FEASIBLE:
		return string("Feasible");
	default:
		my_assert(0, "Unknown Status");
		break;
	}
	return string("Unknown");
}

void FocusRefinement::PrintIterationStatusSimple(IterationStatus & rcStatus)
{
	cout <<
		"\rIt: " << rcStatus.iIterationN <<
		" | UB: " << rcStatus.dBestFeasible <<
		" | LB: " << rcStatus.dObjLB <<
		" | Obj: " << rcStatus.dObjective <<
		" | UC: " << rcStatus.iTotalCores <<
		" | " << StatusToString(rcStatus.iStatus).data() <<
		//" | " << rcStatus.enumState <<
		" | t: " << rcStatus.dTime << "s   ";
}

UnschedCoreComputer::UnschedCores FocusRefinement::CombineCores(UnschedCores & rcPartA, UnschedCores & rcPartB)
{
	UnschedCores cCombinedCores = rcPartA;
	for (UnschedCores::iterator iter = rcPartB.begin(); iter != rcPartB.end(); iter++)
	{
		cCombinedCores.push_back(*iter);
	}
	return cCombinedCores;
}

void FocusRefinement::WriteUnschedCoreToFile(char axFileName[])
{
	UnschedCoreComputer cDummy(*m_pcTaskSet);
	cDummy.WriteUnschedCoreToFile(axFileName, m_cUnschedCores);
}

void FocusRefinement::ReadUnschedCoreFromFile(char axFileName[])
{
	if (strlen(axFileName))
	{
		UnschedCoreComputer cDummy(*m_pcTaskSet);
		cDummy.ReadUnschedCoreFromFile(axFileName, m_cUnschedCores);
	}
		
}

void FocusRefinement::ClearFR()
{	
	m_dObjUB = getObjUB();	
	m_dObjLB = -1e74;
	m_cFinalStatistic = IterationStatus();	
	m_dequeIterationLogs.clear();	
	m_cPriorityAssignmentSol.Clear();
	m_dequeIterationLogs.clear();
	m_cUBLinkSolution.clear();		
}

double FocusRefinement::getObjUB()
{	
	double dUB = 0;	
	try
	{
		IloEnv cSolveEnv;
		IloNumVarArray cPriorityVariables(cSolveEnv);
		CreatePriortyVariable(cPriorityVariables);
		PriorityPOSet cObjRelevantPPO;
		IloExpr cObjectiveExpr = ObjExpr(cPriorityVariables, &cObjRelevantPPO);		
		IloExpr::LinearIterator cLinIter = cObjectiveExpr.getLinearIterator();		
		while (cLinIter.ok())
		{
			dUB += max(0, cLinIter.getCoef());
			++cLinIter;
		}
		dUB += cObjectiveExpr.getConstant();		
		cObjectiveExpr.end();
		cPriorityVariables.end();
		cSolveEnv.end();		
	}
	catch (IloException& e) {
		cerr << "Concert exception caught: " << e << endl;
	}

	return dUB;
}

void FocusRefinement::AddMIPStart(PriorityPOSet & rcPPOSet, PriorityPOSet & cRelevantPO, IloNumVarArray & rcPVars, IloCplex & rcSolver)
{
	IloNumVarArray cStartVarArray(rcPVars.getEnv());
	IloNumArray cStartNumArray(rcPVars.getEnv());
	for (PriorityPOSet::iterator iter = rcPPOSet.begin(); iter != rcPPOSet.end(); iter++)
	{
		if (cRelevantPO.count(PriorityPOElement(iter->m_iHPTask, iter->m_iLPTask)))
		{
			cStartVarArray.add(getPriorityVariable(iter->m_iHPTask, iter->m_iLPTask, rcPVars));
			cStartNumArray.add(1.0);
		}
		else if (cRelevantPO.count(PriorityPOElement(iter->m_iLPTask, iter->m_iHPTask)))
		{
			cStartVarArray.add(getPriorityVariable(iter->m_iLPTask, iter->m_iHPTask, rcPVars));
			cStartNumArray.add(0.0);
		}
		else
		{
			cout << "Confront Irrelevant PPO?" << endl;
			assert(0);
		}
	}
	rcSolver.addMIPStart(cStartVarArray, cStartNumArray, IloCplex::MIPStartRepair);
	cStartVarArray.end();
}

//Lowest Feasible Priority Analyzer
LowestFeasiblePriorityAnalyzer::LowestFeasiblePriorityAnalyzer()
{

}

LowestFeasiblePriorityAnalyzer::LowestFeasiblePriorityAnalyzer(TaskSet & rcTaskSet)
	:FocusRefinement(rcTaskSet)
{
	
}


IloExpr LowestFeasiblePriorityAnalyzer::ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO /* = NULL */)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cObjectiveExpression(rcEnv);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == m_iTargetTask)	continue;
		cObjectiveExpression += getPriorityVariable(m_iTargetTask, i, rcPVars);
//		cObjectiveExpression += getPriorityVariable(i, m_iTargetTask, rcPVars);
		if (pcRelevantPPO)
		{
			pcRelevantPPO->insert(PriorityPOElement(m_iTargetTask, i));
//			pcRelevantPPO->insert(PriorityPOElement(i, m_iTargetTask));
		}
	}	
	return cObjectiveExpression;
}

void LowestFeasiblePriorityAnalyzer::AnalyzeAll(vector<int> & rvectorResult, int iDisplay)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	rvectorResult.clear();
	rvectorResult.reserve(iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{

		m_iTargetTask = i;
		FocusRefinementFast(iDisplay);
		m_cUnschedCores.clear();
		if (iDisplay)	
		{
			printf_s("Task %d lowest priority: %d\n", i, (int)(iTaskNum - 1 - round(m_dObjective)));
		}
		//rvectorResult[i] = iTaskNum - 1 - round(m_dObjective);
		rvectorResult.push_back(iTaskNum - 1 - round(m_dObjective));
	}
}









