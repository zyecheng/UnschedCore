#include "stdafx.h"
#include "RandomGenerator.h"
#include "FileWriter.h"
#include "FileReader.h"
void MyExp()
{
	int iPeriodChoice = RandomGenerator::ApproximateAnalysis0;
	Stateflow ** ppcSystems = RandomGenerator::generate_stateflow_system_for_approximate_analysis4(2, 15, 0.30, iPeriodChoice, 90);
	FileWriter::DotFileWriter(ppcSystems, 2, "StateFlowSystem");
	Stateflow ** ppcReadSystems = NULL;
	int iNum = 2;
	FileReader::DotFileReader(ppcReadSystems, iNum, 100, "StateFlowSystem");
	FileWriter::DotFileWriter(ppcReadSystems, iNum, "StateFlowSystemCopy");	
}

