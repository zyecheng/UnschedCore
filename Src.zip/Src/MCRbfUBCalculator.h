#pragma once
#include "TaskSet.h"
#include "TPCCSet.h"
class MCRbfUBCalculator
{
#define UBTYPE_PLUB	0
#define UBTYPE_LUB	1	
private:
	TaskSet * m_pcTaskSet;
	TPCCSet * m_pcTPCCSet;
	int * m_pipriorityTable;	
public:
	MCRbfUBCalculator();
	~MCRbfUBCalculator();
	void Initialize(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet);
	void setPriority(int iTaskIndex, int iPriority);
	double LORbfCalculator(int iTaskIndex, double dTotalTime);
	double PLUBCalculator(int iTaskIndex, double dTotalTime);
	double LUBCalculator(int iTaskIndex, double dTotalTime);
	bool bIsSchedulableTask(int iTaskIndex,int iUBType);
	bool bIsSchedulableAll(int iUBType);
	double AMCMaxRbfCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange);
	double AMCSepRbfCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange);
	double AMCWCSepRbfCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange);
private:
	double PLUBCalculator_Point(int iTaskIndex, double dTotalTime, double dCritiChange);		
	void CreateTable();
	void ClearTable();
	double DiscontinuityPoint(int iTaskIndex, double dTotalTime);
};

