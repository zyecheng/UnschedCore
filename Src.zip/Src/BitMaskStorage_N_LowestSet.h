#pragma once
#include "BitMask.h"
#include "MySet.h"
#include "Util.h"
class BitMaskStorage_N_LowestSet
{
public:
	typedef BitMask::DataType DataType;
	typedef MySet<BitMask, BitMask::ValueComparator > BitMaskSet;
	//typedef MultiDimensionObjectArray<BitMaskSet, 2> BitMaskSet2D;

	typedef BitMaskSet* BitMaskSetPtr;
	typedef BitMaskSetPtr* BitMaskSetPtr1D;
	typedef BitMaskSetPtr1D* BitMaskSetPtr2D;

	typedef BitMask * BitMask1D;
	typedef BitMask1D * BitMask2D;
	BitMask m_cSupSubSetQueryCertificate;
protected:
	unsigned int m_uiWidth;
	BitMaskSetPtr2D m_cStorage;
	BitMaskSet m_cSubSetResultCache;
	BitMaskSet m_cSupSetResultCache;
	BitMask2D m_cCommonSetBit;
	BitMask2D m_cTotalSetBit;
	int m_iZeroBitMask;
	vector<unsigned int> m_vectorHighestSetLB;
	vector<unsigned int> m_vectorHighestSetUB;
	vector<unsigned int> m_vectorLowestSetLB;
	vector<unsigned int> m_vectorLowestSetUB;
	vector<BitMask> m_vectorCommonSetBit;
	vector<BitMask> m_vectorTotalSetBit;
	unsigned int m_uiSize;
	unsigned int m_uiNSetLB;
	unsigned int m_uiNSetUB;


public:
	BitMaskStorage_N_LowestSet();
	~BitMaskStorage_N_LowestSet();
	void Insert(BitMask & rcBitMask);
	bool Find(BitMask & rcBitMask);
	bool ExistSubSet(BitMask & rcBitMask, int * piNAttempts = NULL, int iLimit = 0x7fffffff);
	bool ExistSupSet(BitMask & rcBitMask, int * piNAttempts = NULL, int iLimit = 0x7fffffff);
	bool ExistProperSubSet(BitMask & rcBitMask, int * piNAttempts = NULL, int iLimit = 0x7fffffff);
	bool ExistProperSupSet(BitMask & rcBitMask, int * piNAttempts = NULL, int iLimit = 0x7fffffff);
	void Initialize(unsigned int uiWidth);
	bool ExistSubSupSetMT(BitMask & rcBitMask, int iQueryType);
	int getSize()	{ return m_uiSize; }
	int SubsetHeuristicLimit();
	int SupsetHeuristicLimit();
protected:
	void CreateBitMaskSet(unsigned int iNBit, unsigned int iLowestSetBit);
	void UpdateTotalCommonSetBit(BitMask & rcBitMask);
	void UpdateBoundData(BitMask & rcBitMask);	
	
};

class BitMaskStorage_N_Longest1String_LowestSet
{
public:

	typedef BitMask::DataType DataType;
	typedef MySet<BitMask, BitMask::ValueComparator > BitMaskSet;
	struct LowestSet_Entrance;
	struct Longest1String_Entrance
	{		
		BitMaskSet * pcBitMaskSet;
		inline Longest1String_Entrance()
		{
			pcBitMaskSet = NULL;
		}	

		~Longest1String_Entrance()
		{
			if (pcBitMaskSet)
				delete pcBitMaskSet;
		}

		inline void Create()
		{
			if (pcBitMaskSet)
				delete pcBitMaskSet;
			pcBitMaskSet = new BitMaskSet();
		}
	};

	struct LowestSet_Entrance
	{
		SparseElementLinkList cElementLink;
		Longest1String_Entrance * pcEntrances;

		inline LowestSet_Entrance()
		{
			pcEntrances = NULL;			
		}

		~LowestSet_Entrance()
		{
			if (pcEntrances)
				delete [] pcEntrances;
		}

		inline void Create(int iSize)
		{
			if (pcEntrances)
				delete [] pcEntrances;
			pcEntrances = new Longest1String_Entrance[iSize];
			cElementLink.Create(iSize);
		}
	};

	struct N_Entrance
	{
		SparseElementLinkList cElementLink;
		LowestSet_Entrance * pcEntrances;
		inline N_Entrance()
		{
			pcEntrances = NULL;
		}		

		~N_Entrance()
		{
			if (pcEntrances)
				delete [] pcEntrances;
		}

		inline void Create(int iSize)
		{
			if (pcEntrances)
				delete [] pcEntrances;
			pcEntrances = new LowestSet_Entrance[iSize];
			cElementLink.Create(iSize);
		}
	};

	struct Main_Entrance
	{
		SparseElementLinkList cElementLink;
		N_Entrance * pcEntrances;
		inline Main_Entrance()
		{
			pcEntrances = NULL;
		}

		~Main_Entrance()
		{
			if (pcEntrances)
				delete [] pcEntrances;
		}

		inline void Create(int iSize)
		{
			if (pcEntrances)
				delete [] pcEntrances;
			pcEntrances = new N_Entrance[iSize];
			cElementLink.Create(iSize);
		}

		inline N_Entrance & operator [] (int iIndex)
		{
			return pcEntrances[iIndex];
		}
	};
protected:
	Main_Entrance m_cNEntrances;
	unsigned int m_uiWidth;
	unsigned int m_uiHasZeroBitMask;
	unsigned int m_uiHasFullBitMask;
	unsigned int m_uiSize;
public:
	BitMaskStorage_N_Longest1String_LowestSet();
	~BitMaskStorage_N_Longest1String_LowestSet();
	void Initialize(unsigned int uiWidth);
	void Insert(BitMask & rcBitMask);
	bool Find(BitMask & rcBitMask);
	bool ExistSupSet(BitMask & rcBitMask, int * piNAttempts = NULL);
	bool ExistSubSet(BitMask & rcBitMask, int * piNAttempts = NULL);
	void UpdateElementLink(BitMask & rcBitMask);
	int getSize()	{ return m_uiSize; }
protected:	
};