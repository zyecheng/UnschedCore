#include "stdafx.h" 
#include "TimerMS.h"
//#include <Windows.h>

TimerMS::TimerMS() {

}

TimerMS::~TimerMS() {}

void TimerMS::start() {


}

void TimerMS::end() {


}

double TimerMS::getTime() const {
	return 0;
}

void TimerMS::reset() {

}
