#pragma once
#include "TaskSet.h"
#include <ilcplex/ilocplex.h>
#include <string.h>
#include "TPCCSet.h"
#include "EncodingVariable.h"
#include "RTSchedPTree.h"
#include <map>
#include "PartialOrderSet.hpp"


class RTSchedMILP_rbf_P
{
#define MODELTYPE_LO		2
#define MODELTYPE_AMCMAX	3
protected:
	TaskSet * m_pcTaskSet;
	TPCCSet * m_pcTPCCSet;
	//IloNumVarArray m_cPriorityVariable;
	//deque<EncodingVariable> m_dequeEncodingVariables;
	map<int, int > m_mapPriorityResult;
	map<int, double> m_mapTask2ResponseTime;
	double m_dSolveCPUTime;
	double m_dSolveWallTime;
	double m_dObjective;
	bool m_bIsValidSolution;
	//IloEnv m_cCplexEnv;	
	map<int, set<int>> m_mapPODETIncomp;	
	map<int, set<int>> m_mapPODET;
	//Some Experimental Stuff	
	PartialOrderSet<int> m_cPODET;
public:
	RTSchedMILP_rbf_P();
	RTSchedMILP_rbf_P(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet);
	~RTSchedMILP_rbf_P();
	int Solve(int iModelType, int iDisplay, double dTimeout = 1e74);
	double getCPUTime();
	double getWallTime();
	double getObjective();
	void setPODET(int iTaskA, int iTaskB, bool bPO);
	int getPODETSize();
protected:
	IloNumVar & getPriorityVariable(int iTaskA, int iTaskB, IloNumVarArray & rcPVars);	
	void CreatePriortyVariable(IloNumVarArray & rcPVars);
	void CreateEncodingVariable(IloEnv & rcEnv, deque<DisjunctionEncoder> & rdequeEncoders);
	//void AnalyzePODET();
	IloExpr rbfLO(int iTaskIndex, double dTotalTime, IloNumVarArray & rcPVars);
	IloExpr rbfCC(int iTaskIndex, double dTotalTime, double dCritiChange, IloNumVarArray & rcPVars);
	void GenPriorityConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray);
	void GenPriorityConst(int i, int j, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray);
	void GenPriorityConst(int i, int j, int k, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray);
	void GenLOSchedConst(int iTaskIndex, IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void GenLOSchedConst(set<int> & rsetTasks, IloNumVarArray & rcPVars, deque<DisjunctionEncoder> & rdequeEncoders, IloRangeArray & rcRangeArray);
	void GenLOSchedConst(int iTaskIndex, set<double> & rsetTP, IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void GenHISchedConst(int iTaskIndex, IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);
	void GenHISchedConst(int iTaskIndex, set<double> & rsetTP, set<double> & rsetCC,
		IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray);	
	void GenPreDetPOConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray);
	double DetermineBigMLO(int iTaskIndex);
	double DetermineBigMHI(int iTaskIndex);
	void BuildSchedConstLO(IloNumVarArray & rcPVars, deque<DisjunctionEncoder> & rcEncoders, IloRangeArray & rcRangeArray);
	void BuildSchedConstHI(IloNumVarArray & rcPVars, deque<DisjunctionEncoder> & rcEncoders, IloRangeArray & rcRangeArray);
	void EnableSolverDisp(int iLevel, IloCplex & rcSolver);	
	virtual void setSolverParam(IloCplex & rcSolver);


	void ExtractPriorityResult(IloNumVarArray & rcPVars, IloCplex & rcSolver);
	bool VerifySchedulability(int iModelType);
	bool VerifyPriority(IloNumVarArray & rcPVars, IloCplex & rcSolver);
	int getPriorityResult(int iTaskA, int iTaskB, IloNumVarArray & rcPVars, IloCplex & rcSolver);

	void EndEncoders(deque<DisjunctionEncoder> & rdequeEncoders);
	//some experimental things	
	IloRange GenValidInequality(IloRangeArray & rcRangeArray, int iStart = 0, int iEnd = -1);	
	int CheckPODET(int iTaskA, int iTaskB);		

public:	
};


