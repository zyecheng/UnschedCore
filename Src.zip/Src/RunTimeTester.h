#pragma once

void TestFocusRefinementAMCRtb(char axDstFolder[]);
void TestFocusRefinementAMCRtbUSweep(char axDstFolder[]);
void TestFocusRefinementAMCRtbKSweep(char axDstFolder[]);
void TestFocusRefinementAMCMax(char axDstFolder[]);
void TestFocusRefinementAMCMaxUSweep(char axDstFolder[]);
void TestFocusRefinementAMCMaxKSweep(char axDstFolder[]);
void TestFocusRefinementLO(char axDstFolder[]);
void TestFocusRefinementFSMRBFSO(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSOKSweep(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementFSMRBFSOUSweep(char axDstFolder[], char axFSMFolder[]);
void TestFocusRefinementAMCRtbNKSweep(char axDstFolder[]);
void TestFocusRefinementAMCMaxUKSweep(char axDstFolder[]);
void TestMinimizeMemoryFR(char axDstFolder[]);
