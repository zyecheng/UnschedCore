#pragma once
#include "FocusRefinement.h"
#include "RTSchedMILP_rbf_P.h"
#include "SimuLinkMiniDelay.h"
#include "TPCCSet.h"

class UnschedCoreComputer_MiniMem : public UnschedCoreComputer
{
public:	
	typedef map<int, map<int, int> > Link2LinkModelTask;
private:	
	int m_iLinkModelBaseTask;	
	Link2LinkModelTask m_mapLink2PCPModelTask;
	Link2LinkModelTask m_mapLink2RTBModelTask;	
	PriorityPOSet * m_pcPPOSetForSchedTest;
	PriorityPOSet * m_pcFixedSetForSchedTest;
	set<int> m_setModelTask;
public:
	UnschedCoreComputer_MiniMem();
	UnschedCoreComputer_MiniMem(TaskSet & rcTaskSet);
	~UnschedCoreComputer_MiniMem();
	void setBaseTask(int iBaseTask)	{ m_iLinkModelBaseTask = iBaseTask; }
	int getBaseTask()	{ return m_iLinkModelBaseTask; }
	Link2LinkModelTask & getPCPModelTask()	{ return m_mapLink2PCPModelTask; }
	Link2LinkModelTask & getRTBModelTask()	{ return m_mapLink2RTBModelTask; }
	set<int> & getModelTaskSet()	{ return m_setModelTask; }
	void CorrelatePCPModelTask(int iSource, int iDestination, int iTaskIndex);
	void CorrelateRTBModelTask(int iSource, int iDestination, int iTaskIndex);
	void setLinkModelBaseTask(int iBaseTask);
	void PreSchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet);
	bool SchedTest(int iTaskIndex, TaskSetPriorityStruct & rcPriorityAssignment, void *pvExtraData);	
	bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	bool IsSchedulable(PriorityPOSet & rcPriorityPOSet, PriorityPOSet & rcFixedPOSet, TaskSetPriorityStruct & rcPriorityAssignment, PriorityPOSet & rcHinderingPOs);
	void ConvertToNormalPA(TaskSetPriorityStruct & rcPriorityAssignmentOriginal, TaskSetPriorityStruct & rcConverted);
	double ComputeBlocking(int iTaskIndex, TaskSetPriorityStruct & rcPirorityAssignment, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet);
	bool IsRTBDet(int iSource, int iDestination, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet);
	bool IsPCPDet(int iSource, int iDestination, PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet);
	void ConvertToExtendedTaskSet(TaskSetExt_LinkCritialSection & rcOriginalTaskSet, TaskSetExt_LinkCritialSection & rcConvertedTaskSet, 
		Link2LinkModelTask & rcRTBModelTask, Link2LinkModelTask & rcPCPMOdelTask, set<int> & rsetModelTaskSet, int & iBaseTask);

};

class MinimizeMemory_PFR:public FocusRefinement
{
public:
	struct CommunicationLink
	{
		int iSource;
		int iDest;
		double dMemory;
	};
	UnschedCoreComputer_MiniMem m_cUnschedCoreComputer;
	TaskSetExt_LinkCritialSection m_cExtendedTaskSet;
public:
	MinimizeMemory_PFR();
	MinimizeMemory_PFR(TaskSet & rcTaskSet);
	~MinimizeMemory_PFR();
	int ComputeUnschedCores(PriorityPOSet & rcPPOSet, PriorityPOSet & rcFixedSet, UnschedCores & rcUnschedCores, int iLimit);
	bool IsSchedulable(PriorityPOSet & rcPPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	IloExpr ObjExpr(IloNumVarArray & rcPVars, PriorityPOSet * pcRelevantPPO /* = NULL */);
	void GenExtraConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray, void * pvExtraData);
	void ConvertToExtendedTaskSet(TaskSetExt_LinkCritialSection & rcTaskSet);
	bool VerifyMinimizeMemoryResult(double dObjective, TaskSetPriorityStruct & rcPriorityAssignment);
	//bool VerifyOthers(double dObjective, PriorityPOSet & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	void GenFixedPPOSet(PriorityPOSet & rcFixedSet);
private:
	
};

class MinimizeMemory_RBF : public SimuLinkMiniDelay
{
protected:
	TPCCSet_PerDeadlines * m_pcTPCCPDSet;
	TaskSetPriorityStruct m_cResultPA;
public:
	MinimizeMemory_RBF();
	MinimizeMemory_RBF(TaskSet & rcTaskSet, TPCCSet_PerDeadlines & rcTPCCSet);
	~MinimizeMemory_RBF();
	void GenerateTPCCPD(TaskSet & rcTaskSet, TPCCSet_PerDeadlines & rcTPCCSet);
	void CreateRTBDetVars(IloNumVarArray & rcVarArray);
	void CreatePCPDetVars(IloNumVarArray & rcVarArray);
	void CreateTaskBlockVars(IloNumVarArray & rcVarArray);
	void CreateLinkBlcokVars(IloNumVarArray & rcVarArray);	
	IloNumVar & getRTBDetVars(int iSource, int iDest, IloNumVarArray & rcVarArray);
	IloNumVar & getPCPDetVars(int iSource, int iDest, IloNumVarArray & rcVarArray);	
	IloNumVar & getTaskBlockVars(int iTaskIndex, IloNumVarArray & rcVarArray);
	IloNumVar & getLinkReadBlockVar(int iSource, int iDestination, IloNumVarArray & rcVarArray);
	IloNumVar & getLinkWriteBlockVar(int iSource, int iDestination, IloNumVarArray & rcVarArray);
	void CreateTaskEncodingVariable(IloEnv & rcEnv, deque<DisjunctionEncoder> & rdequeEncoders);
	void CreateLinkEncodingVariable(IloEnv & rcEnv, deque<DisjunctionEncoder> & rdequeEncoders);
	void GenRTBPCPRelConst(IloNumVarArray & rcPCPDet, IloNumVarArray & rcRTBDet, IloRangeArray & rcConstraint);
	void GenRTBDetConst(int iSource, int iDest, IloNumVarArray & rcRTBDetVar, IloNumVarArray & rcPVar, IloNumVarArray & rcBlockVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcConst);
	void GenRTBDetConst(IloNumVarArray & rcRTBDetVar, IloNumVarArray & rcPVar, IloNumVarArray & rcBlockVars, deque<DisjunctionEncoder> & rdequeDisjunctionEncoders, IloRangeArray & rcConst);
	void GenBlockModelConst(IloNumVarArray & rcPVars, IloNumVarArray & rcPCPDetVars, IloNumVarArray & rcLinkBlcokVar, IloNumVarArray & rcTaskBlockVar, IloRangeArray & rcConst);
	void GenLOSchedConst(int iTaskIndex, set<double> & rsetTestPoint, IloNumVarArray & rcPVars, IloNumVarArray & rcBlcokVars, DisjunctionEncoder & rcDisjunctionEncoder, IloRangeArray & rcConst);	
	void GenLOSchedConst(IloNumVarArray & rcPVars, IloNumVarArray & rcBlcokVars, deque<DisjunctionEncoder> & rdequeDisjunctionEncoders, IloRangeArray & rcConst);
	IloExpr ObjExpr(IloNumVarArray & rcRTBDetVars, IloNumVarArray & rcPCPDetVars);
	int Solve(int iDisplay, double dTimeout = 1e74);
	bool VerifyRTBDet(IloNumVarArray & rcRTBDet, IloNumVarArray & rcPCPDet, IloNumVarArray & rcPVars, IloNumVarArray & rcBlockVars, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver);
	bool VerifySchedulability(IloNumVarArray & rcPCPDet, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver);
	bool VerifyObjective(IloNumVarArray & rcRTBDetVars, IloNumVarArray & rcPCPDet, IloNumVarArray & rcTaskBlockVars, IloCplex & rcSolver, TaskSetPriorityStruct & rcPriorityAssignment);
	bool VerifyLinkBlocking(IloNumVarArray & rcLinkBlockVars, IloNumVarArray & rcPCPDetVars, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver);
	bool VerifyTaskLinkBlocking(IloNumVarArray & rcTaskBlockVars, IloNumVarArray & rcLinkBlockVars, IloCplex & rcSolver);
	double ComputeBlocking(int iTaskIndex, IloNumVarArray & rcPCPDet, TaskSetPriorityStruct & rcPriorityAssignment, IloCplex & rcSolver);
	void ExtractPriorityResult(IloNumVarArray & rcPriorityVariables, IloCplex & rcSolver, TaskSetPriorityStruct & rcPriorityAssignment);
	double DetermineBigMLO(int iTaskIndex);
};

