#include "stdafx.h"
#include "EncodingVariable.h"
#include "Util.h"

extern IloEnv cEnv;
EncodingVariable::EncodingVariable()	
{
	m_pcEnv = &cEnv;
	m_cEncodingVar = IloNumVarArray(*m_pcEnv);
}

EncodingVariable::EncodingVariable(IloEnv * pcEnv)
{
	m_pcEnv = pcEnv;
	m_cEncodingVar = IloNumVarArray(*m_pcEnv);
}

EncodingVariable::~EncodingVariable()
{

}

EncodingVariable::EncodingVariable(int iRange, double dBigM)	
{
	m_pcEnv = &cEnv;
	m_cEncodingVar = IloNumVarArray(*m_pcEnv);
	m_iEncRange = iRange;
	m_iEncVarNum = ceil(log2(iRange));
	m_dBigM = dBigM;
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		m_cEncodingVar.add(IloNumVar(*m_pcEnv, 0.0, 1.0, IloNumVar::Int));
	}

}

EncodingVariable::EncodingVariable(int iRange, IloEnv * pcEnv, double dBigM)
{
	m_pcEnv = pcEnv;
	m_cEncodingVar = IloNumVarArray(*m_pcEnv);
	m_iEncRange = iRange;
	m_iEncVarNum = ceil(log2(iRange));
	m_dBigM = dBigM;
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		m_cEncodingVar.add(IloNumVar(*m_pcEnv, 0.0, 1.0, IloNumVar::Int));
	}
}

EncodingVariable::EncodingVariable(int iRange, char axIdentifier[], double dBigM)
{
	m_pcEnv = &cEnv;
	m_cEncodingVar = IloNumVarArray(*m_pcEnv);
	m_iEncRange = iRange;
	m_dBigM = dBigM;
	m_iEncVarNum = ceil(log2(iRange));
	char axBuffer[512] = { 0 };
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		sprintf(axBuffer, "%s(%d)", axIdentifier, i);
		m_cEncodingVar.add(IloNumVar(*m_pcEnv, 0.0, 1.0, IloNumVar::Int, axBuffer));
	}

}


IloExpr EncodingVariable::getEncodingExpression(int iEncIndex)
{
	IloExpr cEncExpression(*m_pcEnv);
	int iAccessIndex = 0;

	if (m_iEncRange == 0) return cEncExpression;

	my_assert(iEncIndex < m_iEncRange, "Encoding Index Exceed Predefine Range");

	for (int i = 0; i < m_iEncVarNum; i++)
	{
		if (iEncIndex & 1)
		{
			cEncExpression += (1 - m_cEncodingVar[i]) * m_dBigM;
		}
		else
		{
			cEncExpression += m_cEncodingVar[i] * m_dBigM;
		}
		iEncIndex >>= 1;
	}
	return cEncExpression;
}

IloExpr EncodingVariable::getEncodingExpression(int iEncIndex, double dBigM)
{
	IloExpr cEncExpression(*m_pcEnv);
	int iAccessIndex = 0;

	if (m_iEncRange == 0) return cEncExpression;

	my_assert(iEncIndex < m_iEncRange, "Encoding Index Exceed Predefine Range");

	for (int i = 0; i < m_iEncVarNum; i++)
	{
		if (iEncIndex & 1)
		{
			cEncExpression += (1 - m_cEncodingVar[i]) * dBigM;
		}
		else
		{
			cEncExpression += m_cEncodingVar[i] * dBigM;
		}
		iEncIndex >>= 1;
	}
	return cEncExpression;
}

IloRange EncodingVariable::getEncodingConstraint(int iRange)
{
	IloExpr cConstExpr(*m_pcEnv);
	if (iRange == -1)
		iRange = m_iEncRange;
	int iBase = 1;
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		cConstExpr += iBase * m_cEncodingVar[i];
		iBase *= 2;
	}
	return IloRange(*m_pcEnv, 0, cConstExpr, iRange - 1);
}

double EncodingVariable::getEncodingError(double dSolverError)
{
	return (double)m_iEncVarNum * m_dBigM * dSolverError;
}

void EncodingVariable::Clear()
{
	m_cEncodingVar.clear();
	m_iEncVarNum = 0;
	m_iEncRange = 0;
	m_dBigM = 0;
}

void EncodingVariable::Initialize(int iRange, double dBigM /* = 1e7 */)
{
	Clear();
	m_iEncRange = iRange;
	m_iEncVarNum = ceil(log2(iRange));
	m_dBigM = dBigM;
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		m_cEncodingVar.add(IloNumVar(*m_pcEnv, 0.0, 1.0, IloNumVar::Int));
	}
}

//Disjunction Encoder

DisjunctionEncoder::DisjunctionEncoder()
{

}

DisjunctionEncoder::~DisjunctionEncoder()
{

}

DisjunctionEncoder::DisjunctionEncoder(IloEnv & rcEnv, int iRange)
{	
	m_cEncodingVar = IloNumVarArray(rcEnv);
	m_iEncRange = iRange;
	m_iEncVarNum = ceil(log2(iRange));
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		m_cEncodingVar.add(IloNumVar(rcEnv, 0.0, 1.0, IloNumVar::Int));
	}
}

IloExpr DisjunctionEncoder::getEncodingExpression(int iEncIndex, double dBigM)
{
	IloExpr cEncExpression(m_cEncodingVar.getEnv());
	int iAccessIndex = 0;

	if (m_iEncRange == 0) return cEncExpression;

	my_assert(iEncIndex < m_iEncRange, "Encoding Index Exceed Predefine Range");

	for (int i = 0; i < m_iEncVarNum; i++)
	{
		if (iEncIndex & 1)
		{
			cEncExpression += (1 - m_cEncodingVar[i]) * dBigM;
		}
		else
		{
			cEncExpression += m_cEncodingVar[i] * dBigM;
		}
		iEncIndex >>= 1;
	}
	return cEncExpression;
}

IloRange DisjunctionEncoder::getEncodingConstraint(int iRange /* = -1 */)
{
	IloExpr cConstExpr(m_cEncodingVar.getEnv());
	if (iRange == -1)
		iRange = m_iEncRange;
	int iBase = 1;
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		cConstExpr += iBase * m_cEncodingVar[i];
		iBase *= 2;
	}
	return IloRange(m_cEncodingVar.getEnv(), 0, cConstExpr, iRange - 1);
}

IloExpr DisjunctionEncoder::getEncodingConstExpr()
{
	IloExpr cConstExpr(m_cEncodingVar.getEnv());
	int iBase = 1;
	for (int i = 0; i < m_iEncVarNum; i++)
	{
		cConstExpr += iBase * m_cEncodingVar[i];
		iBase *= 2;
	}
	return cConstExpr;
}

double DisjunctionEncoder::getEncodingError(double dSolverError, double dBigM)
{
	return (double)m_iEncVarNum * dBigM * dSolverError;
}

void DisjunctionEncoder::End()
{
	m_cEncodingVar.end();
}