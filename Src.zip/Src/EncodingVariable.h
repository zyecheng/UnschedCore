#pragma  once
#include <ilcplex/ilocplex.h>
class EncodingVariable
{
public:
	IloNumVarArray m_cEncodingVar;
	int m_iEncRange;
	int m_iEncVarNum;
	double m_dBigM;
	IloEnv * m_pcEnv;
public:
	EncodingVariable();
	~EncodingVariable();
	EncodingVariable(IloEnv * pcEnv);
	EncodingVariable(int iRange, double dBigM = 1e7);
	EncodingVariable(int iRange, IloEnv * pcEnv, double dBigM = 1e7);
	EncodingVariable(int iRange, char axIdentifier[], double dBigM = 1e7);
	IloExpr getEncodingExpression(int iEncIndex);
	IloExpr getEncodingExpression(int iEncIndex, double dBigM);
	IloRange getEncodingConstraint(int iRange = -1);
	double getEncodingError(double dSolverError);
	void Clear();
	void Initialize(int iRange, double dBigM = 1e7);	
};

class DisjunctionEncoder
{
private:
	int m_iEncRange;
	int m_iEncVarNum;
	IloNumVarArray m_cEncodingVar;
public:
	DisjunctionEncoder();
	~DisjunctionEncoder();
	DisjunctionEncoder(IloEnv & rcEnv, int iRange);
	IloExpr getEncodingExpression(int iEncIndex, double dBigM);
	IloRange getEncodingConstraint(int iRange = -1);
	IloExpr getEncodingConstExpr();
	double getEncodingError(double dSolverError, double dBigM);
	void Clear();
	void End();
};
