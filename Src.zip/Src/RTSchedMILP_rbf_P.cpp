#include "stdafx.h"
#include "RTSchedMILP_rbf_P.h"
#include <cmath>
#include <algorithm>
#include "Util.h"
#include "ResponseTimeCalculator.h"
#include "RTSchedPTree.h"
#include "Util.h"
extern set<int> setGlobalSetTemp;

RTSchedMILP_rbf_P::RTSchedMILP_rbf_P()
{
}

RTSchedMILP_rbf_P::~RTSchedMILP_rbf_P()
{		
}

RTSchedMILP_rbf_P::RTSchedMILP_rbf_P(TaskSet & rcTaskSet, TPCCSet & rcTPCCSet)		
{
	m_pcTPCCSet = &rcTPCCSet;
	m_pcTaskSet = &rcTaskSet;	
}

void RTSchedMILP_rbf_P::CreatePriortyVariable(IloNumVarArray & rcPVars)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	char axBuffer[128] = { 0 };
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = 0; j < iTaskNum; j++)
		{
			//if (i == j)	continue;
			sprintf_s(axBuffer, "p(%d, %d)", i, j);
			rcPVars.add(IloNumVar(rcEnv, 0, 1.0, IloNumVar::Int, axBuffer));
		}
	}
}

void RTSchedMILP_rbf_P::CreateEncodingVariable(IloEnv & rcEnv, deque<DisjunctionEncoder> & rdequeEncoders)
{
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	char axBuffer[128] = { 0 };
	for (int i = 0; i < iTaskNum; i++)
	{
		int iEncRange = m_pcTPCCSet->getTestPoints(i).size();
		rdequeEncoders.push_back(DisjunctionEncoder(rcEnv, iEncRange));
	}
}

void RTSchedMILP_rbf_P::GenPriorityConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray)
{	
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPVars.getEnv();
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = 0; j < iTaskNum; j++)
		{
			if (j == i)
			{
				rcRangeArray.add(IloRange(rcEnv, 0.0, rcPVars[i * iTaskNum + j], 0.0));
				continue;
			}
				
			GenPriorityConst(i, j, rcPVars, rcRangeArray);

			for (int k = 0; k < iTaskNum; k++)
			{
				if ((i == k) || (j == k))
				{
					continue;
				}
				GenPriorityConst(i, j, k, rcPVars, rcRangeArray);
			}
		}
	}
}

void RTSchedMILP_rbf_P::GenPriorityConst(int i, int j, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray)
{		
	const IloEnv & rcEnv = rcPVars.getEnv();
	rcRangeArray.add(IloRange(rcEnv, 0.0,
		getPriorityVariable(i, j, rcPVars) + getPriorityVariable(j, i, rcPVars) - 1.0,
		0.0));
	return;
}

void RTSchedMILP_rbf_P::GenPriorityConst(int i, int j, int k, IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray)
{	
	const IloEnv & rcEnv = rcPVars.getEnv();
	rcRangeArray.add(IloRange(rcEnv, -IloInfinity,
		getPriorityVariable(i, k, rcPVars) + getPriorityVariable(k, j, rcPVars) - 1.0 - getPriorityVariable(i, j, rcPVars),
		0.0));
}

void RTSchedMILP_rbf_P::GenLOSchedConst(int iTaskIndex, IloNumVarArray & rcPVars,  DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	set<double> & rsetTestPoint = m_pcTPCCSet->getTestPoints(iTaskIndex);
	GenLOSchedConst(iTaskIndex, rsetTestPoint, rcPVars, rcEncoder, rcRangeArray);
}

void RTSchedMILP_rbf_P::GenLOSchedConst(set<int> & rsetTasks, IloNumVarArray & rcPVars, deque<DisjunctionEncoder> & rdequeEncoders, IloRangeArray & rcRangeArray)
{
	for (set<int>::iterator iter = rsetTasks.begin(); iter != rsetTasks.end(); iter++)
	{
		int iTaskIndex = *iter;
		assert(iTaskIndex < m_pcTaskSet->getTaskNum());
		set<double> & rsetTestPoint = m_pcTPCCSet->getTestPoints(iTaskIndex);
		GenLOSchedConst(iTaskIndex, rsetTestPoint, rcPVars, rdequeEncoders[iTaskIndex], rcRangeArray);
	}
	
}

void RTSchedMILP_rbf_P::GenLOSchedConst(int iTaskIndex, set<double> & rsetTP, IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	const IloEnv & rcEnv = rcPVars.getEnv();
	set<double> & rsetTestPoint =rsetTP;	
	char axBuffer[128] = { 0 };
	int iEncIndex = 0;
	double dBigM = DetermineBigMLO(iTaskIndex);
	for (set<double>::iterator iter = rsetTestPoint.begin();
		iter != rsetTestPoint.end(); iter++)
	{
		sprintf_s(axBuffer, "rbfLO(%d, %.2f)", iTaskIndex, *iter);
		rcRangeArray.add(IloRange(rcEnv, -IloInfinity,
			rbfLO(iTaskIndex, *iter, rcPVars) - *iter - rcEncoder.getEncodingExpression(iEncIndex, dBigM),
			0.0, axBuffer));
		iEncIndex++;
	}
	rcRangeArray.add(rcEncoder.getEncodingConstraint());
}

void RTSchedMILP_rbf_P::GenHISchedConst(int iTaskIndex, IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		GenLOSchedConst(iTaskIndex, rcPVars, rcEncoder, rcRangeArray);
	}
	else
	{
		set<double> & rsetTestPoint = m_pcTPCCSet->getTestPoints(iTaskIndex);
		set<double> & rsetCC = m_pcTPCCSet->getCritiChanges(iTaskIndex);
		GenHISchedConst(iTaskIndex, rsetTestPoint, rsetCC, rcPVars, rcEncoder, rcRangeArray);
	}

}

void RTSchedMILP_rbf_P::GenHISchedConst(int iTaskIndex, set<double> & rsetTP, set<double> & rsetCC, 
	IloNumVarArray & rcPVars, DisjunctionEncoder & rcEncoder, IloRangeArray & rcRangeArray)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	assert(iTaskIndex < m_pcTaskSet->getTaskNum());
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	if (!pcTaskArray[iTaskIndex].getCriticality())
	{
		GenLOSchedConst(iTaskIndex, rcPVars, rcEncoder, rcRangeArray);
	}
	else
	{
		set<double> & rsetTestPoint = rsetTP;
		set<double> & rsetCC = m_pcTPCCSet->getCritiChanges(iTaskIndex);		
		char axBuffer[128] = { 0 };
		int iEncIndex = 0;
		double dBigM = DetermineBigMHI(iTaskIndex);
		for (set<double>::iterator iterTP = rsetTestPoint.begin();
			iterTP != rsetTestPoint.end(); iterTP++)
		{
			for (set<double>::iterator iterCC = rsetCC.begin();
				iterCC != rsetCC.end(); iterCC++)
			{
				if (*iterCC < *iterTP)
				{
					sprintf_s(axBuffer, "rbfCC(%d, %.2f, %.2f)", iTaskIndex, *iterTP, *iterCC);
					rcRangeArray.add(IloRange(rcEnv, -IloInfinity,
						rbfCC(iTaskIndex, *iterTP, *iterCC, rcPVars) - *iterTP - rcEncoder.getEncodingExpression(iEncIndex, dBigM),
						0.0, axBuffer));
				}
			}
			iEncIndex++;
		}
		rcRangeArray.add(rcEncoder.getEncodingConstraint());
	}
}

void RTSchedMILP_rbf_P::GenPreDetPOConst(IloNumVarArray & rcPVars, IloRangeArray & rcRangeArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	const IloEnv & rcEnv = rcPVars.getEnv();
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = 0; j < iTaskNum; j++)
		{
			if (j == i)	continue;
			int iPODET = CheckPODET(i, j);
			if (iPODET != -1)
			{
				rcRangeArray.add(IloRange(rcEnv, iPODET, getPriorityVariable(i, j, rcPVars), iPODET));
			}
		}
	}

}

IloNumVar & RTSchedMILP_rbf_P::getPriorityVariable(int iTaskA, int iTaskB, IloNumVarArray & rcPVars)
{	
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(iTaskA != iTaskB);
	int iAccessIndex = iTaskB + iTaskA * iTaskNum;
	assert(rcPVars.getSize() > iAccessIndex);
	return rcPVars[iAccessIndex];
}

IloExpr RTSchedMILP_rbf_P::rbfLO(int iTaskIndex, double dTotalTime, IloNumVarArray & rcPVars)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cAMCMaxRbfExpr(rcEnv);
	int iTaskNum = m_pcTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	cAMCMaxRbfExpr += pcTaskArray[iTaskIndex].getCLO();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
			continue;
		int iPODET = CheckPODET(i, iTaskIndex);
		int iLOInstances = ceil(dTotalTime / pcTaskArray[i].getPeriod());
		cAMCMaxRbfExpr += getPriorityVariable(i, iTaskIndex, rcPVars) *
			iLOInstances * pcTaskArray[i].getCLO();
	}
	return cAMCMaxRbfExpr;
}

IloExpr RTSchedMILP_rbf_P::rbfCC(int iTaskIndex, double dTotalTime, double dCritiChange, IloNumVarArray & rcPVars)
{
	const IloEnv & rcEnv = rcPVars.getEnv();
	IloExpr cAMCMaxRbfExpr(rcEnv);
	int iTaskNum = m_pcTaskSet->getTaskNum();
	Task * pcTaskArray = m_pcTaskSet->getTaskArrayPtr();
	cAMCMaxRbfExpr += pcTaskArray[iTaskIndex].getCHI();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (i == iTaskIndex)
			continue;
		if (pcTaskArray[i].getCriticality())
		{
			int iHIInstances = min(
				ceil((dTotalTime - dCritiChange - (pcTaskArray[i].getPeriod() - pcTaskArray[i].getDeadline())) / pcTaskArray[i].getPeriod()) + 1,
				ceil(dTotalTime / pcTaskArray[i].getPeriod())
				);
			int iLOInstances = ceil(dTotalTime / pcTaskArray[i].getPeriod()) - iHIInstances;
			int iPODET = CheckPODET(i, iTaskIndex);
			if (iPODET != -1)
			{
				cAMCMaxRbfExpr += iPODET *
					(iLOInstances * pcTaskArray[i].getCLO() + iHIInstances * pcTaskArray[i].getCHI());
			}
			else
			{
				cAMCMaxRbfExpr += getPriorityVariable(i, iTaskIndex, rcPVars) *
					(iLOInstances * pcTaskArray[i].getCLO() + iHIInstances * pcTaskArray[i].getCHI());
			}
			
		}
		else
		{			
			int iLOInstances = floor(dCritiChange / pcTaskArray[i].getPeriod()) + 1;
			cAMCMaxRbfExpr += getPriorityVariable(i, iTaskIndex, rcPVars) *
				iLOInstances * pcTaskArray[i].getCLO();
		}
	}
	return cAMCMaxRbfExpr;
}

double RTSchedMILP_rbf_P::DetermineBigMLO(int iTaskIndex)
{
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(iTaskIndex < iTaskNum);	
	double dBigM = pcTaskArray[iTaskIndex].getCLO();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (iTaskIndex == i)
			continue;
		double dN = ceil(pcTaskArray[iTaskIndex].getPeriod() / pcTaskArray[i].getPeriod());
		dBigM += dN * pcTaskArray[i].getCLO();
	}
	return dBigM;
}

double RTSchedMILP_rbf_P::DetermineBigMHI(int iTaskIndex)
{
	assert(m_pcTaskSet);
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(iTaskIndex < iTaskNum);
	double dBigM = pcTaskArray[iTaskIndex].getCHI();
	for (int i = 0; i < iTaskNum; i++)
	{
		if (iTaskIndex == i)
			continue;
		double dN = ceil(pcTaskArray[iTaskIndex].getPeriod() / pcTaskArray[i].getPeriod());
		dBigM += dN * pcTaskArray[i].getCriticality() ? pcTaskArray[i].getCHI() : pcTaskArray[i].getCLO();
	}
	return dBigM;
}

void RTSchedMILP_rbf_P::BuildSchedConstHI(IloNumVarArray & rcPVars, deque<DisjunctionEncoder> & rcEncoders, IloRangeArray & rcRangeArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(rcPVars.getSize() == iTaskNum * iTaskNum - iTaskNum);
	assert(rcEncoders.size() == iTaskNum);
	for (int i = 0; i < iTaskNum; i++)
	{
		GenHISchedConst(i, rcPVars, rcEncoders[i], rcRangeArray);
	}
}

void RTSchedMILP_rbf_P::BuildSchedConstLO(IloNumVarArray & rcPVars, deque<DisjunctionEncoder> & rcEncoders, IloRangeArray & rcRangeArray)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	assert(rcPVars.getSize() == iTaskNum * iTaskNum);
	assert(rcEncoders.size() == iTaskNum);	
	set<int> setForceAdd = {};
	//return;
	for (int i = 0; i < iTaskNum; i++)
	{		
		GenLOSchedConst(i, rcPVars, rcEncoders[i], rcRangeArray);
	}	
}

void RTSchedMILP_rbf_P::setSolverParam(IloCplex & rcSolver)
{
	rcSolver.setParam(IloCplex::Param::Emphasis::MIP, 0);
	rcSolver.setParam(IloCplex::Param::Simplex::Tolerances::Feasibility, 1e-9);
	rcSolver.setParam(IloCplex::Param::MIP::Tolerances::Integrality, 0);
	//rcSolver.setParam(IloCplex::Param::MIP::Cuts::Covers, 3);
	//rcSolver.setParam(IloCplex::Param::Emphasis::Memory, 1);	
	rcSolver.setParam(IloCplex::Param::MIP::OrderType, 0);
	
}

void RTSchedMILP_rbf_P::EnableSolverDisp(int iLevel, IloCplex & rcSolver)
{
	const IloEnv & rcEnv = rcSolver.getEnv();
	if (iLevel)
	{
		rcSolver.setParam(IloCplex::Param::MIP::Display, iLevel);
	}
	else
	{
		rcSolver.setParam(IloCplex::Param::MIP::Display, 0);
		rcSolver.setOut(rcEnv.getNullStream());
	}
}

int RTSchedMILP_rbf_P::Solve(int iModelType, int iDisplay, double dTimeout)
{

	IloEnv cSolveEnv;
	IloNumVarArray cPriorityVariables(cSolveEnv);
	deque<DisjunctionEncoder> dequeEncoders;
	CreatePriortyVariable(cPriorityVariables);
	CreateEncodingVariable(cSolveEnv, dequeEncoders);

	IloRangeArray cConst(cSolveEnv);
	BuildSchedConstLO(cPriorityVariables, dequeEncoders, cConst);
	GenPriorityConst(cPriorityVariables, cConst);


	IloModel cModel(cSolveEnv);
	cModel.add(cConst);	

	IloCplex cSolver(cModel);
	
	EnableSolverDisp(iDisplay, cSolver);
	setSolverParam(cSolver);
	
	//cSolver.exportModel("A:\\FVM2.sav");

	m_dSolveCPUTime = getCPUTimeStamp();
	m_dSolveWallTime = cSolver.getCplexTime();
	bool bStatus = cSolver.solve();
	m_dSolveCPUTime = getCPUTimeStamp() - m_dSolveCPUTime;
	m_dSolveWallTime = cSolver.getCplexTime() - m_dSolveWallTime;

	int iRetStatus = 0;
	if (bStatus)
	{
		assert(VerifyPriority(cPriorityVariables, cSolver));
		ExtractPriorityResult(cPriorityVariables, cSolver);		
		assert(VerifySchedulability(iModelType));
		m_bIsValidSolution = true;				
	}
	

	{
		m_bIsValidSolution = false;
		if (cSolver.getCplexStatus() == cSolver.Optimal)
			iRetStatus = 1;
		else if (cSolver.getCplexStatus() == cSolver.AbortTimeLim)
			iRetStatus = -1;
		else if (cSolver.getCplexStatus() == cSolver.Infeasible)
			iRetStatus = 0;
		else
			iRetStatus = 0;
	}
	
	cSolver.end();
	cModel.end();
	cConst.end();		
	cSolveEnv.end();
	return iRetStatus;
}

int RTSchedMILP_rbf_P::getPriorityResult(int iTaskA, int iTaskB, IloNumVarArray & rcPVars, IloCplex & rcSolver)
{	
	IloNumVar & rcPriorityVariable = getPriorityVariable(iTaskA, iTaskB, rcPVars);
	return (int)round(rcSolver.getValue(rcPriorityVariable));
}

void RTSchedMILP_rbf_P::ExtractPriorityResult(IloNumVarArray & rcPVars, IloCplex & rcSolver)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	m_mapPriorityResult.clear();
	for (int i = 0; i < iTaskNum; i++)
	{
		int iPriority = 0;
		for (int j = 0; j < iTaskNum; j++)
		{
			if (i == j) continue;
			iPriority += getPriorityResult(j, i, rcPVars, rcSolver);
		}
		m_mapPriorityResult[i] = iPriority;
	}
	m_dObjective = rcSolver.getObjValue();
}

bool RTSchedMILP_rbf_P::VerifyPriority(IloNumVarArray & rcPVars, IloCplex & rcSolver)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	for (int i = 0; i < iTaskNum; i++)
	{
		for (int j = 0; j < iTaskNum; j++)
		{
			if (i == j) continue;
			if ((getPriorityResult(i, j, rcPVars, rcSolver) + getPriorityResult(j, i, rcPVars, rcSolver) != 1))
			{
				cout << getPriorityResult(i, j, rcPVars, rcSolver) << " " << getPriorityResult(j, i, rcPVars, rcSolver) << endl;
				return false;
			}

			for (int k = 0; k < iTaskNum; k++)
			{
				if ((i == k) || (j == k))
				{
					continue;
				}

				if (getPriorityResult(i, k, rcPVars, rcSolver) == 1 && getPriorityResult(k, j, rcPVars, rcSolver) == 1)
				{
					if (getPriorityResult(i, j, rcPVars, rcSolver) != 1)
					{
						cout << getPriorityResult(i, k, rcPVars, rcSolver) << " " << getPriorityResult(k, j, rcPVars, rcSolver) << " " << getPriorityResult(i, j, rcPVars, rcSolver) << endl;
						return false;
					}
				}

				if (!(getPriorityResult(i, k, rcPVars, rcSolver) + getPriorityResult(k, j, rcPVars, rcSolver) - 1.0 <= getPriorityResult(i, j, rcPVars, rcSolver)))
				{
					cout << getPriorityResult(i, k, rcPVars, rcSolver) << " " << getPriorityResult(k, j, rcPVars, rcSolver) << " " << getPriorityResult(i, j, rcPVars, rcSolver) << endl;
					return false;
				}
					
			}
		}
	}
	return true;
}

bool RTSchedMILP_rbf_P::VerifySchedulability(int iModelType)
{
	GET_TASKSET_NUM_PTR(m_pcTaskSet, iTaskNum, pcTaskArray);
	ResponseTimeCalculator cRTCalc;
	cRTCalc.Initialize(*m_pcTaskSet);
	for (int i = 0; i < iTaskNum; i++)
	{
		cRTCalc.setPrioirty(i, m_mapPriorityResult[i]);
	}
	int iType = 0;
	switch (iModelType)
	{
	case MODELTYPE_AMCMAX:
		iType = RTCALC_AMCMAX;
		break;
	case MODELTYPE_LO:
		iType = RTCALC_LO;
		break;
	default:
		break;
	}
	cRTCalc.Calculate(iType);
	for (int i = 0; i < iTaskNum; i++)
	{
		m_mapTask2ResponseTime[i] = cRTCalc.getResponseTime(i);
	}	
	
	return !cRTCalc.getDeadlineMiss();
}

double RTSchedMILP_rbf_P::getCPUTime()
{
	return m_dSolveCPUTime;
}

double RTSchedMILP_rbf_P::getWallTime()
{
	return m_dSolveWallTime;
}

double RTSchedMILP_rbf_P::getObjective()
{
	return m_dObjective;
}

void RTSchedMILP_rbf_P::setPODET(int iTaskA, int iTaskB, bool bPO)
{
	if (bPO)
	{
		//m_mapPODETIncomp[iTaskA].insert(iTaskB);
		assert(m_cPODET.setPartialOrder(iTaskA, iTaskB));
	}
	else
	{
		assert(m_cPODET.setPartialOrder(iTaskB, iTaskA));
		//m_mapPODETIncomp[iTaskB].insert(iTaskA);
	}

}

int RTSchedMILP_rbf_P::CheckPODET(int iTaskA, int iTaskB)
{
	//return -1;
	return m_cPODET.getPartialOrder(iTaskA, iTaskB);
	if (m_mapPODET.count(iTaskA) == 1)
	{
		if (m_mapPODET[iTaskA].count(iTaskB) == 1)
			return 1;
	}

	if (m_mapPODET.count(iTaskB) == 1)
	{
		if (m_mapPODET[iTaskB].count(iTaskA) == 1)
			return 0;
	}
	return -1;
}

int RTSchedMILP_rbf_P::getPODETSize()
{
	return m_cPODET.getPartialOrderSize();
}

void RTSchedMILP_rbf_P::EndEncoders(deque<DisjunctionEncoder> & rdequeEncoders)
{
	for (deque<DisjunctionEncoder>::iterator iter = rdequeEncoders.begin(); iter != rdequeEncoders.end(); iter++)
	{
		iter->End();
	}
}

//Some experimental stuff
IloRange RTSchedMILP_rbf_P::GenValidInequality(IloRangeArray & rcRangeArray,int iStart, int iEnd)
{
	const IloEnv & rcEnv = rcRangeArray.getEnv();
	int iSize = rcRangeArray.getSize();
	iEnd = (iEnd == -1) ? iSize - 1 : iEnd;
	iEnd = min(iSize - 1, iEnd);
	IloExpr cExpr(rcEnv);
	double dLB = 0;
	double dUB = 0;
	for (int i = 0; i <= iEnd; i++)
	{
		cExpr += rcRangeArray[i].getExpr();
		dUB += rcRangeArray[i].getUB();
		dLB += rcRangeArray[i].getLB();
	}
	return IloRange(rcEnv, dLB, cExpr, dUB);
}

