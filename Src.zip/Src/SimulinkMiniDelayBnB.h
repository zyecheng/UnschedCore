#pragma once
#include "TaskSet.h"
#include "PartialOrderSet.hpp"
#include "RTSchedPTree.h"
class SimulinkMiniDelayBnB
{
public:
	class SimulinkMiniDelayBnB_Link
	{
	public:
		int m_iSource;
		int m_iDestination;
		double m_dDelayCost;
		double m_dMemoryCost;
	public:
		SimulinkMiniDelayBnB_Link();
		SimulinkMiniDelayBnB_Link(int iSource, int iDestination, double dDelayCost, double dMemoryCost);
		~SimulinkMiniDelayBnB_Link();
		friend bool operator < (const SimulinkMiniDelayBnB_Link & rcLHS, const SimulinkMiniDelayBnB_Link & rcRHS);
	};
protected:
	TaskSet * m_pcTaskSet;
	set<SimulinkMiniDelayBnB_Link> m_setLHLinks;
	PartialOrderSet<int> m_cPOSet;
	double m_dBestDelay;
	double m_dBestMemory;
	TaskSetPriorityStruct m_cBestPriorityAssignment;
	double m_dTimeout;
	double m_dTimeStart;
	double m_dTimeElapsed;
	double m_dThreadCPUTime;
	int m_iStatus;
	int m_iRecursionN;
	int m_iDisplay;
public:
	SimulinkMiniDelayBnB();
	SimulinkMiniDelayBnB(TaskSet & rcTaskSet);
	~SimulinkMiniDelayBnB();
	void Run(int iDisplay, double dTimeout = 1e74);
	int getStatus()	{ return m_iStatus; }
	bool setPartialOrder(int iTaskA, int iTaskB);
	PartialOrderSet<int> & getPOSet()	{ return m_cPOSet; }
	double getTimeElpased()	{ return m_dTimeElapsed; }
	void setBestDelay(double dDelay);
	void DisplayFlippableLink();
	void WriteStatisticFile(const char axFileName[]);
	virtual double getWorstDelay();
protected:
	virtual void InitializeLinkData();
	void DelayRecur(set<SimulinkMiniDelayBnB_Link>::iterator iterCurrLink, double dDelay, double dMemoryCost, PartialOrderSet<int> & rcPOSet);	
	virtual double CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct);		
	virtual bool IsSchedulable(PartialOrderSet<int> & rcPOSet, double dMemoryCost, TaskSetPriorityStruct & rcPriorityAssignment);
	int IsSchedulableRecur(int iPriority, double dMemoryCost, PartialOrderSet<int> & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	bool ExistUnassignedHPTask(int iTaskIndex, PartialOrderSet<int> & rcPOSet, TaskSetPriorityStruct & rcPriorityAssignment);
	double EstimateMemoryCost(int iTaskIndex, double dResponseTime, TaskSetPriorityStruct & rcPriorityAssignment);	
	double EstimateDelayCost(TaskSetPriorityStruct & rcPriorityAssignment);
};


class SimulinkMiniDelayBnB_AMCMax : public SimulinkMiniDelayBnB
{
protected:
	UnschedCoreComputer_AMCMax m_cUnschedCore;
public:
	SimulinkMiniDelayBnB_AMCMax();
	SimulinkMiniDelayBnB_AMCMax(TaskSet & rcTaskSet);
	~SimulinkMiniDelayBnB_AMCMax();
private:	
	virtual double CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct);
};

class SimulinkMiniDelayBnB_AMCRtb : public SimulinkMiniDelayBnB
{
protected:
	UnschedCoreComputer_AMCRtb m_cUnschedCore;
public:
	SimulinkMiniDelayBnB_AMCRtb();
	SimulinkMiniDelayBnB_AMCRtb(TaskSet & rcTaskSet);
	~SimulinkMiniDelayBnB_AMCRtb();
private:
	virtual double CalcResponseTime(int iTaskIndex, TaskSetPriorityStruct & rcPriorityStruct);
};

