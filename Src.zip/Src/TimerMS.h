/* \file TimerMS.h
*  this file implements a TimerMS class to count the runtime. 
*  \author Chao Peng
*  
*  Changes
*  ------
*  14-Sept-2015 : initial revision (CP)
*
*/

#ifndef TimerMS_H_
#define TimerMS_H_

#include <windows.h>

/* \brief A TimerMS class implements microsecond-level TimerMS
 * From http://blog.csdn.net/hoya5121/article/details/3778487
 */
class TimerMS {
public:
	typedef long long LARGE_INTEGER;
	TimerMS();
	~TimerMS();

	void start();
	void end();
	// return time in second
	double getTime() const;

private:
	LARGE_INTEGER m_i64CPUFreq;
	LARGE_INTEGER m_i64Begin;
	LARGE_INTEGER m_i64End;
	void reset();
};

#endif
